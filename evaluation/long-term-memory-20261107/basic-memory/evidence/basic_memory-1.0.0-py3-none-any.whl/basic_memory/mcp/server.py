"""
Basic Memory FastMCP server.
"""

import time
from contextlib import asynccontextmanager

from fastmcp import FastMCP
from fastmcp.server.transforms import Visibility
from loguru import logger
from sqlalchemy import text
from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

from basic_memory import db
from basic_memory.api.container import ApiContainer, installed_container
from basic_memory.cli.auth import CLIAuth
from basic_memory.index.note_content_materialization import drain_pending_materializations
from basic_memory.db import scoped_session
from basic_memory.index.local_schedulers import drain_background_tasks
from basic_memory.mcp.client_info import MCPClientInfoMiddleware
from basic_memory.mcp.container import McpContainer, installed_container as installed_mcp_container
from basic_memory.mcp.empty_results import EmptyListResultMiddleware
from basic_memory.read_cache import ReadCacheUnavailable
from basic_memory.read_cache.redis import RedisReadCache
from basic_memory.read_cache.lifecycle import open_redis_read_cache
from basic_memory.services.initialization import initialize_app
import logfire

PROJECT_DELETE_TAG = "project-delete"


def set_project_delete_visibility(server: FastMCP, enabled: bool) -> None:
    """Show or hide bm_project_delete.

    The last visibility mark appended wins, so this is safe
    to call at import, at each lifespan start, and in tests.
    """
    server.add_transform(Visibility(enabled, tags={PROJECT_DELETE_TAG}))


async def _log_embedding_status(session_maker: async_sessionmaker[AsyncSession]) -> None:
    """Log a clear summary of semantic embedding status at startup."""
    try:
        async with scoped_session(session_maker) as session:
            entity_count = (
                await session.execute(text("SELECT COUNT(*) FROM entity"))
            ).scalar() or 0
            chunk_count = (
                await session.execute(text("SELECT COUNT(*) FROM search_vector_chunks"))
            ).scalar() or 0
            embedding_count = (
                await session.execute(text("SELECT COUNT(*) FROM search_vector_embeddings_rowids"))
            ).scalar() or 0

        if entity_count == 0:
            logger.info("Semantic embeddings: no entities yet")
        elif embedding_count == 0:
            logger.warning(
                f"Semantic embeddings: EMPTY — {entity_count} entities have no embeddings. "
                "Run 'bm reindex --embeddings' to build them."
            )
        else:
            logger.info(
                f"Semantic embeddings: {embedding_count} embeddings "
                f"across {chunk_count} chunks for {entity_count} entities"
            )
    except Exception as exc:
        logger.debug(f"Could not check embedding status at startup: {exc}")


async def _invalidate_persisted_read_cache(read_cache: RedisReadCache) -> RedisReadCache | None:
    """Retire every entry that may predate this process.

    Files can change while no server is running, and a project can be deleted by
    a process that had no cache open. Advancing the global epoch retires both,
    including entries of projects that no longer exist.
    """
    try:
        await read_cache.reset_all()
    except ReadCacheUnavailable as error:
        # Trigger: Redis cannot retire persisted entries at startup.
        # Why: reusing any prior entry could hide an offline file edit until TTL expiry.
        # Outcome: disable caching for this lifespan and serve only authoritative reads.
        logger.error(
            "Standalone Redis read cache disabled because startup invalidation was unavailable",
            error=str(error),
        )
        return None

    return read_cache


@asynccontextmanager
async def lifespan(app: FastMCP):
    """Lifecycle manager for the MCP server.

    Handles:
    - Database initialization and migrations
    - Local file watching via WatchCoordinator (if enabled and not in cloud mode)
    - Proper cleanup on shutdown
    """
    # --- Composition Root ---
    # Create container and read config (single point of config access)
    container = McpContainer.create()
    config = container.config

    # Trigger: the enable_project_delete config flag (off by default).
    # Why: deleting a project removes it for every client; only the user turns it on.
    # Outcome: bm_project_delete is listed only then.
    set_project_delete_visibility(app, config.enable_project_delete)

    standalone_redis_url = None if container.mode.is_cloud else config.redis_url

    async with open_redis_read_cache(
        standalone_redis_url,
        max_connections=config.redis_max_connections,
    ) as read_cache:
        container.read_cache = read_cache
        api_container = ApiContainer(config=config, mode=container.mode, read_cache=read_cache)

        # Local MCP requests use FastAPI through ASGITransport without entering its lifespan.
        # Installing the same container keeps request reads and watcher invalidation on one cache.
        with installed_mcp_container(container), installed_container(api_container):
            with logfire.span(
                "mcp.lifecycle.startup",
                entrypoint="mcp",
                mode=container.mode.name.lower(),
                default_project=config.default_project,
            ):
                logger.info(f"Starting Basic Memory MCP server (mode={container.mode.name})")
                logger.info(
                    f"Config: database_backend={config.database_backend.value}, "
                    f"default_project={config.default_project}"
                )
                logger.info(
                    f"Semantic search: provider={config.semantic_embedding_provider}, "
                    f"model={config.semantic_embedding_model}, "
                    f"dimensions={config.semantic_embedding_dimensions or 'auto'}, "
                    f"batch_size={config.semantic_embedding_batch_size}, "
                    f"document_prefix_set={bool(config.semantic_embedding_document_prefix)}, "
                    f"query_prefix_set={bool(config.semantic_embedding_query_prefix)}"
                )

                # Log configured projects with their routing mode
                for name, entry in config.projects.items():
                    default = " (default)" if name == config.default_project else ""
                    logger.info(
                        f"Project: {name} -> {entry.path} [mode={entry.mode.value}]{default}"
                    )

                # Check cloud auth status (local file check, no network call)
                auth = CLIAuth(client_id=config.cloud_client_id, authkit_domain=config.cloud_domain)
                tokens = auth.load_tokens()
                if tokens is not None:
                    if not auth.is_token_valid(tokens):
                        expires_at = tokens.get("expires_at", 0)
                        expired_ago = int(time.time() - expires_at)
                        logger.warning(
                            f"Cloud token expired {expired_ago}s ago - may need 'bm cloud login'"
                        )
                    else:
                        logger.info("Cloud: authenticated (OAuth token valid)")

                if config.cloud_api_key:
                    logger.info("Cloud: API key configured")

                # Track if we created the engine (vs test fixtures providing it)
                # This prevents disposing an engine provided by test fixtures when
                # multiple Client connections are made in the same test
                engine_was_none = db._engine is None

                # Initialize app (runs migrations, reconciles projects)
                await initialize_app(container.config)

                if read_cache is not None:
                    read_cache = await _invalidate_persisted_read_cache(read_cache)
                    container.read_cache = read_cache
                    api_container.read_cache = read_cache

                # Log embedding status so it's easy to spot in the logs
                if db._session_maker is not None:
                    await _log_embedding_status(db._session_maker)

                # Create and start local watch coordinator (lifecycle centralized in coordinator)
                watch_coordinator = container.create_watch_coordinator()
                await watch_coordinator.start()

            try:
                yield
            finally:
                # Shutdown - coordinator handles clean task cancellation
                with logfire.span(
                    "mcp.lifecycle.shutdown",
                    entrypoint="mcp",
                    mode=container.mode.name.lower(),
                ):
                    logger.debug("Shutting down Basic Memory MCP server")

                    await watch_coordinator.stop()

                    # A local note write returns 202 before its markdown file is written;
                    # shutdown can land while that materialization (and the vector sync /
                    # relation resolution it schedules) is still queued in the in-process
                    # pool. Drain both queues before the engine closes so an accepted
                    # write is never lost — mirrors the API lifespan shutdown.
                    await drain_pending_materializations()
                    await drain_background_tasks()

                    # Only shutdown DB if we created it (not if test fixture provided it)
                    if engine_was_none:
                        await db.shutdown_db()
                        logger.debug("Database connections closed")
                    else:  # pragma: no cover
                        logger.debug("Skipping DB shutdown - engine provided externally")


# A newly-connected model only sees the server `instructions` for free — everything else
# (the ai_assistant_guide resource, tool descriptions) requires it to choose to fetch. Without
# this, a client that connects to an empty knowledge base has nothing telling it what Basic
# Memory is or that a first note is worth offering, and it stays idle. The framing is
# offer-not-act on purpose: orient, then *offer* a first note, but never write one unprompted so
# power-user / coding sessions stay unobtrusive.
BASIC_MEMORY_INSTRUCTIONS = (
    "Basic Memory is the user's personal knowledge base: Markdown notes that persist "
    "across conversations and that both the user and their AI assistants can read and write.\n\n"
    "When a request may draw on the user's notes, use bm_search or "
    'bm_project(command="recent", project="...") before answering from memory. No recent activity does not '
    "prove a project is empty. If the knowledge base is empty, explain the shared-memory loop "
    "and offer a useful first note with bm_write; wait for agreement before writing. Do not write unprompted.\n\n"
    "Use bm_list for one folder, bm_find for recursive names or frontmatter inventories, "
    "bm_search for ranked retrieval or matching lines, and bm_read for note and file content. "
    "bm_read supports bounded lines, sections, and token budgets. Follow relations with "
    "bm_context. Read before editing with bm_edit; use the returned checksum to guard changes. "
    "bm_write creates notes and explicitly overwrites them; bm_edit never creates missing notes. "
    "Use returned paths for subsequent reads and writes.\n\n"
    'bm_project(command="list") discovers projects, grouped by workspace. Pass a project name, '
    "workspace/project, or external UUID through the required project parameter on note, "
    "folder, context and schema calls. A qualified path must agree with project. "
    "Search requires project, projects, or all_projects=true. "
    "Calls do not remember a previous project selection.\n\n"
    "The installed tool schemas are authoritative. Most tools default to text; bm_context "
    'defaults to JSON. Use output_format="json" when consuming structured fields. Failures '
    "are tool errors, not empty successful results. Follow pagination and continuation fields. "
    'Call bm_man(page="bm-search(3)") for details, or read memory://man for the manual index. '
    "Read memory://ai_assistant_guide for a fuller guide. With a web or fetch tool, fetch "
    "https://docs.basicmemory.com/llms.txt first, then only the relevant linked /raw/...md page."
)

mcp = FastMCP(
    name="Basic Memory",
    instructions=BASIC_MEMORY_INSTRUCTIONS,
    lifespan=lifespan,
)
mcp.add_middleware(MCPClientInfoMiddleware())
mcp.add_middleware(EmptyListResultMiddleware())
