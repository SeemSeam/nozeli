"""Dependency injection for basic-memory.

This package provides FastAPI dependencies organized by feature:
- config: Application configuration
- db: Database/session management
- projects: Project resolution and config
- repositories: Data access layer
- services: Business logic layer
- importers: Import functionality

For backwards compatibility, all dependencies are re-exported from this module.
New code should import from specific submodules to reduce coupling.
"""

# Re-export everything for backwards compatibility
# Eventually, callers should import from specific submodules

from basic_memory.deps.config import (
    get_app_config,
    AppConfigDep,
)

from basic_memory.deps.db import (
    get_engine_factory,
    EngineFactoryDep,
    get_session_maker,
    SessionMakerDep,
    get_session,
    SessionDep,
)

from basic_memory.deps.projects import (
    get_project_repository,
    ProjectRepositoryDep,
    validate_project_external_id,
    ProjectExternalIdPathDep,
    get_project_config_v2_external,
    ProjectConfigV2ExternalDep,
)

from basic_memory.deps.read_cache import (
    get_read_cache,
    ReadCacheDep,
)

from basic_memory.deps.repositories import (
    get_entity_repository_v2_external,
    EntityRepositoryV2ExternalDep,
    get_observation_repository_v2_external,
    ObservationRepositoryV2ExternalDep,
    get_relation_repository_v2_external,
    RelationRepositoryV2ExternalDep,
    get_memory_time_index_repository_v2_external,
    MemoryTimeIndexRepositoryV2ExternalDep,
    get_search_repository_v2_external,
    SearchRepositoryV2ExternalDep,
)

from basic_memory.deps.services import (
    get_entity_parser_v2_external,
    EntityParserV2ExternalDep,
    get_markdown_processor_v2_external,
    MarkdownProcessorV2ExternalDep,
    get_file_service_v2_external,
    FileServiceV2ExternalDep,
    get_entity_vector_sync_scheduler,
    EntityVectorSyncSchedulerDep,
    get_relation_resolution_scheduler,
    RelationResolutionSchedulerDep,
    get_project_index_scheduler,
    ProjectIndexSchedulerDep,
    get_project_index_command,
    ProjectIndexCommandDep,
    get_search_reindex_scheduler,
    SearchReindexSchedulerDep,
    get_search_service_v2_external,
    SearchServiceV2ExternalDep,
    get_note_content_query_service,
    NoteContentQueryServiceDep,
    get_note_content_mutation_service,
    NoteContentMutationServiceDep,
    SchemaValidationObserverDep,
    get_note_content_materialization_provider,
    NoteContentMaterializationProviderDep,
    get_directory_delete_service,
    DirectoryDeleteServiceDep,
    get_link_resolver_v2_external,
    LinkResolverV2ExternalDep,
    get_entity_service_v2_external,
    EntityServiceV2ExternalDep,
    get_context_service_v2_external,
    ContextServiceV2ExternalDep,
    get_index_file_executor_v2_external,
    IndexFileExecutorV2ExternalDep,
    get_project_index_runner,
    ProjectIndexRunnerDep,
    get_project_index_observer,
    ProjectIndexObserverDep,
    ProjectReadinessServiceDep,
    get_project_service,
    ProjectServiceDep,
    get_directory_service_v2_external,
    DirectoryServiceV2ExternalDep,
)

from basic_memory.deps.importers import (
    get_chatgpt_importer_v2_external,
    ChatGPTImporterV2ExternalDep,
    get_claude_conversations_importer_v2_external,
    ClaudeConversationsImporterV2ExternalDep,
    get_claude_projects_importer_v2_external,
    ClaudeProjectsImporterV2ExternalDep,
    get_memory_json_importer_v2_external,
    MemoryJsonImporterV2ExternalDep,
)

__all__ = [
    # Config
    "get_app_config",
    "AppConfigDep",
    # Database
    "get_engine_factory",
    "EngineFactoryDep",
    "get_session_maker",
    "SessionMakerDep",
    "get_session",
    "SessionDep",
    # Projects
    "get_project_repository",
    "ProjectRepositoryDep",
    "validate_project_external_id",
    "ProjectExternalIdPathDep",
    "get_project_config_v2_external",
    "ProjectConfigV2ExternalDep",
    # Read cache
    "get_read_cache",
    "ReadCacheDep",
    # Repositories
    "get_entity_repository_v2_external",
    "EntityRepositoryV2ExternalDep",
    "get_observation_repository_v2_external",
    "ObservationRepositoryV2ExternalDep",
    "get_relation_repository_v2_external",
    "RelationRepositoryV2ExternalDep",
    "get_memory_time_index_repository_v2_external",
    "MemoryTimeIndexRepositoryV2ExternalDep",
    "get_search_repository_v2_external",
    "SearchRepositoryV2ExternalDep",
    # Services
    "get_entity_parser_v2_external",
    "EntityParserV2ExternalDep",
    "get_markdown_processor_v2_external",
    "MarkdownProcessorV2ExternalDep",
    "get_file_service_v2_external",
    "FileServiceV2ExternalDep",
    "get_entity_vector_sync_scheduler",
    "EntityVectorSyncSchedulerDep",
    "get_relation_resolution_scheduler",
    "RelationResolutionSchedulerDep",
    "get_project_index_scheduler",
    "ProjectIndexSchedulerDep",
    "get_project_index_command",
    "ProjectIndexCommandDep",
    "get_search_reindex_scheduler",
    "SearchReindexSchedulerDep",
    "get_search_service_v2_external",
    "SearchServiceV2ExternalDep",
    "get_note_content_query_service",
    "NoteContentQueryServiceDep",
    "get_note_content_mutation_service",
    "NoteContentMutationServiceDep",
    "SchemaValidationObserverDep",
    "get_note_content_materialization_provider",
    "NoteContentMaterializationProviderDep",
    "get_directory_delete_service",
    "DirectoryDeleteServiceDep",
    "get_link_resolver_v2_external",
    "LinkResolverV2ExternalDep",
    "get_entity_service_v2_external",
    "EntityServiceV2ExternalDep",
    "get_context_service_v2_external",
    "ContextServiceV2ExternalDep",
    "get_index_file_executor_v2_external",
    "IndexFileExecutorV2ExternalDep",
    "get_project_index_runner",
    "ProjectIndexRunnerDep",
    "get_project_index_observer",
    "ProjectIndexObserverDep",
    "ProjectReadinessServiceDep",
    "get_project_service",
    "ProjectServiceDep",
    "get_directory_service_v2_external",
    "DirectoryServiceV2ExternalDep",
    # Importers
    "get_chatgpt_importer_v2_external",
    "ChatGPTImporterV2ExternalDep",
    "get_claude_conversations_importer_v2_external",
    "ClaudeConversationsImporterV2ExternalDep",
    "get_claude_projects_importer_v2_external",
    "ClaudeProjectsImporterV2ExternalDep",
    "get_memory_json_importer_v2_external",
    "MemoryJsonImporterV2ExternalDep",
]
