"""Pure export values and Markdown rendering; never renders live Wiki bytes."""

from dataclasses import dataclass
from datetime import datetime
from pathlib import PurePosixPath
from urllib.parse import quote
from uuid import UUID

from markdown_it import MarkdownIt
from markdown_it.rules_inline import StateInline
import yaml

from basic_memory.file_utils import has_frontmatter, parse_frontmatter
from basic_memory.markdown.entity_parser import (
    _coerce_to_string,
    normalize_frontmatter_value,
    parse,
)
from basic_memory.markdown.path_links import (
    is_path_target,
    resolve_project_path,
)
from basic_memory.markdown.plugins import _is_escaped
from basic_memory.repository.entity_repository import file_path_alias
from basic_memory.services.bulk_link_resolver import RelationTargetReference
from basic_memory.services.link_resolver import normalize_link_text
from basic_memory.utils import (
    build_canonical_permalink,
    build_permalink_resolution_candidates,
    generate_permalink,
)

from basic_memory.okf.validation import Document, parse_document
from basic_memory.yaml_policy import SimpleSafeDumper


class ExportDumper(SimpleSafeDumper):
    """Retain YAML mapping order while making unordered sets deterministic."""


def represent_set(dumper: ExportDumper, values: set[object]) -> yaml.nodes.MappingNode:
    ordered = sorted(values, key=lambda value: yaml.safe_dump(value, sort_keys=True))
    return dumper.represent_mapping("tag:yaml.org,2002:set", [(value, None) for value in ordered])


ExportDumper.add_representer(set, represent_set)


def has_unordered_values(value: object) -> bool:
    """Identity strings cannot use hash-dependent representations of nested sets."""
    if isinstance(value, set):
        return True
    if isinstance(value, dict):
        return any(has_unordered_values(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(has_unordered_values(item) for item in value)
    return False


@dataclass(frozen=True)
class ExportFile:
    path: str
    content: bytes


@dataclass(frozen=True)
class RecordedChange:
    position: int
    path: str
    operation: str
    accepted_at: datetime


@dataclass(frozen=True)
class ExportSnapshot:
    project: str
    files: tuple[ExportFile, ...]
    changes: tuple[RecordedChange, ...] = ()
    permalinks_include_project: bool = True


def markdown_link(label: str, path: str, fragment: str = "") -> str:
    escaped = label.replace("\\", "\\\\").replace("[", "\\[").replace("]", "\\]")
    # Fold only Markdown line breaks; splitlines() would also eat U+2028/U+2029,
    # which MarkdownIt keeps as inline text.
    escaped = " ".join(escaped.replace("\r\n", "\n").replace("\r", "\n").split("\n"))
    href = quote(path, safe="/")
    if fragment:
        href += "#" + quote(fragment, safe="")
    return f"[{escaped}]({href})"


def convert_wikilinks(
    body: str,
    source: str,
    targets: dict[str, str],
    project: str,
    *,
    include_project: bool = True,
    ambiguous_aliases: frozenset[str] = frozenset(),
    permalinks: dict[str, str] | None = None,
    title_targets: dict[str, str] | None = None,
) -> str:
    """Normalize export line endings to LF and rewrite only prose wikilink spans."""
    body = body.replace("\r\n", "\n").replace("\r", "\n")
    project = generate_permalink(project)
    replacements: list[tuple[int, int, str]] = []
    inline_source = ""
    path_aliases: dict[str, list[str]] = {}
    for path in sorted(set(targets.values())):
        path_aliases.setdefault(file_path_alias(path), []).append(path)

    def wikilink(state: StateInline, silent: bool) -> bool:
        start = state.pos
        if not state.src.startswith("[[", start):
            return False
        # Image labels use a nested source with different offsets; keep them literal.
        if silent or state.linkLevel or state.src != inline_source:
            return False
        depth = 1
        end = start + 2
        while end < len(state.src) - 1:
            # Escaped brackets belong to the target, matching the canonical scanner.
            if _is_escaped(state.src, end):
                end += 1
                continue
            pair = state.src[end : end + 2]
            if pair == "[[":
                depth += 1
            elif pair == "]]":
                depth -= 1
                if depth == 0:
                    break
            end += 2 if pair in {"[[", "]]"} else 1
        if depth:
            return False
        raw = state.src[start + 2 : end]
        target, alias = normalize_link_text(raw)
        target, _, fragment = target.partition("#")
        # The canonical parser records no relation for [[]]; keep it as prose.
        if not target and not fragment:
            return False
        label = alias or target or fragment
        reference = RelationTargetReference.parse(target)
        if reference.explicitly_qualified:
            prefix, remainder = reference.project_path()
            # Explicit foreign-project references cannot bind to this bundle's aliases.
            if prefix is None or generate_permalink(prefix) != project:
                return False
            target = remainder
        # External IDs outrank semantic aliases but are not carried by filesystem bytes.
        # Keep their references literal rather than binding to a lower-priority name.
        try:
            UUID(target)
        except ValueError:
            pass
        else:
            return False
        # Network-path URIs would turn unresolved file identities into external links.
        if target.startswith("//"):
            return False
        rooted = target.startswith("/")
        resolved = None
        # Trigger: an unqualified ./ or ../ path wikilink.
        # Why: the graph resolves path targets as exact files relative to the source
        #   note, with no extension, title, permalink or alias guesses
        #   (BulkLinkResolutionSnapshot.resolve). A project-qualified target routes
        #   through the qualifier first and resolves from the project root instead.
        #   Wikilink paths are literal, so they skip Markdown href filtering.
        # Outcome: the export links that exact path, a broken link when it is absent.
        relative = (
            resolve_project_path(target, source)
            if not rooted and not reference.explicitly_qualified and is_path_target(target)
            else None
        )
        if relative is not None:
            replacements.append((start, end + 2, markdown_link(label, relative, fragment)))
            state.push("text", "", 0).content = raw
            state.pos = end + 2
            return True
        # Dot segments that climb past the project root, or sit in a qualified or bare
        # identity, name no file; keep the reference literal rather than letting URI
        # normalization invent an edge.
        if ".." in PurePosixPath(target).parts:
            return False
        # Bare slash-bearing targets such as nested/a are identities, not paths: the
        # graph resolves them by permalink, title, then project-root path, never
        # against the source folder.
        if not rooted and resolved is None and permalinks:
            # Semantic addresses precede title/path aliases, even when they look like filenames.
            for candidate in build_permalink_resolution_candidates(
                target, project, include_project
            ):
                if target in ambiguous_aliases and candidate != target:
                    break
                if candidate in permalinks:
                    resolved = permalinks[candidate]
                    break
        if not rooted and resolved is None and title_targets:
            resolved = title_targets.get(target)
        if not rooted and resolved is None:
            resolved = targets.get(target)
        if (
            not rooted
            and resolved is None
            and (
                target not in ambiguous_aliases
                or "/" in target
                or target.casefold().endswith(".md")
            )
        ):
            # Forgiving filename spelling is a last resort after exact identities.
            path = target if target.casefold().endswith(".md") else target + ".md"
            matches = path_aliases.get(file_path_alias(path), [])
            if len(matches) == 1:
                resolved = matches[0]
        # A missing target stays a broken link, not a guessed edge to another concept.
        # Rooted links already name exact portable file paths; never infer an extension.
        href = target if rooted else "/" + (resolved or target or source)
        replacements.append((start, end + 2, markdown_link(label, href, fragment)))
        state.push("text", "", 0).content = raw
        state.pos = end + 2
        return True

    parser = MarkdownIt()
    parser.inline.ruler.before("link", "okf_wikilink", wikilink)
    # MarkdownIt substitutes U+FFFD for NUL one-for-one, preserving source offsets.
    lines = body.replace("\0", "\ufffd").split("\n")
    line_offsets = [0]
    for line in lines:
        line_offsets.append(line_offsets[-1] + len(line) + 1)
    document_replacements: list[tuple[int, int, str]] = []
    # Each inline block is parsed separately: backticks in another paragraph must
    # not turn this paragraph into code. Map token text back past list/quote prefixes.
    environment: dict[str, object] = {}
    for token in MarkdownIt().parse(body, environment):
        if token.type != "inline" or not token.map or "[[" not in token.content:
            continue
        replacements.clear()
        inline_source = token.content
        # Retain document references so link labels remain existing Markdown links.
        parser.parseInline(token.content, environment)
        if not replacements:
            continue
        offsets: list[int] = []
        first, last = token.map
        source_line = first
        for text in token.content.split("\n"):
            # MarkdownIt expands continuation indentation tabs. Match the text
            # after indentation while keeping replacement endpoints in raw bytes.
            stripped = text.lstrip(" \t")
            indentation = len(text) - len(stripped)
            column = -1
            while source_line < last:
                column = lines[source_line].find(stripped)
                if column >= 0:
                    break
                source_line += 1
            if source_line == last:
                raise ValueError(f"{source}: cannot locate wikilink source span")
            offset = line_offsets[source_line] + column
            offsets.extend([offset] * indentation)
            offsets.extend(range(offset, offset + len(text) - indentation + 1))
            source_line += 1
        for start, end, replacement in replacements:
            document_replacements.append((offsets[start], offsets[end - 1] + 1, replacement))
    for start, end, replacement in reversed(document_replacements):
        body = body[:start] + replacement + body[end:]

    return body


def render_bundle(snapshot: ExportSnapshot) -> tuple[ExportFile, ...]:
    """Preserve frontmatter and prose; attach only semantics lost by link conversion."""
    targets: dict[str, str] = {}
    permalinks: dict[str, str] = {}
    title_targets: dict[str, str] = {}
    ambiguous: set[str] = set()
    documents: dict[str, Document] = {}
    titles: dict[str, str] = {}
    note_types: dict[str, str] = {}
    for file in snapshot.files:
        if PurePosixPath(file.path).suffix != ".md":
            continue
        content = file.content.decode("utf-8")
        document = parse_document(content, source=True)
        # Malformed notes can retain an indexed identity absent from their moved file.
        # A filesystem snapshot cannot infer that identity safely.
        if has_frontmatter(content) and not document.has_frontmatter:
            raise ValueError(f"{file.path}: repair malformed frontmatter before export")
        documents[file.path] = document
        # Resolve using BM's normalized title, but retain authored YAML values in output.
        source_metadata = (
            parse_frontmatter(file.content.decode("utf-8")) if document.has_frontmatter else {}
        )
        for field in ("title", "type"):
            if has_unordered_values(source_metadata.get(field)):
                raise ValueError(f"{file.path}: {field} cannot contain an unordered YAML set")
        title = _coerce_to_string(normalize_frontmatter_value(source_metadata.get("title")))
        title = title if title and title != "None" else PurePosixPath(file.path).stem
        titles[file.path] = title
        note_type = source_metadata.get("type")
        note_types[file.path] = (
            _coerce_to_string(normalize_frontmatter_value(note_type))
            if note_type is not None
            else "note"
        )
        permalink = normalize_frontmatter_value(source_metadata.get("permalink"))
        if not isinstance(permalink, str) or not permalink:
            permalink = build_canonical_permalink(
                snapshot.project, file.path, include_project=snapshot.permalinks_include_project
            )
        if isinstance(permalink, str) and permalink:
            # Offline files can violate the indexed uniqueness rule; never choose a winner.
            if permalink in permalinks:
                raise ValueError(
                    f"{file.path}: duplicate permalink {permalink!r} also declared by "
                    f"{permalinks[permalink]}"
                )
            permalinks[permalink] = file.path
    # Resources use their full filename as the canonical indexed title.
    for file in snapshot.files:
        title = titles.get(file.path, PurePosixPath(file.path).name)
        if title in title_targets and title_targets[title] != file.path:
            ambiguous.add(title)
        else:
            title_targets[title] = file.path
    for alias in ambiguous:
        title_targets.pop(alias)
    # Relative path resolution uses exact file identities, separate from semantic names.
    targets.update({file.path: file.path for file in snapshot.files})

    output: list[ExportFile] = []
    directories = {PurePosixPath(".")}
    for file in snapshot.files:
        path = PurePosixPath(file.path)
        directories.update(path.parents)
        if path.suffix != ".md":
            output.append(file)
            continue
        document = documents[file.path]
        metadata = dict(document.metadata)
        metadata["type"] = note_types[file.path]
        metadata.setdefault("tags", [])
        semantic_setting = metadata.get("bm_parse_semantics")
        parse_semantics = not (
            semantic_setting is False
            or (isinstance(semantic_setting, str) and semantic_setting.lower() == "false")
        )
        if parse_semantics:
            semantics = parse(document.body)
            # Observation syntax remains intact and is documented by the profile.
            # Typed relation metadata is needed because a standard link is untyped.
            relations = [relation.model_dump() for relation in semantics.relations]
        else:
            relations = []
        existing = metadata.get("bm", {})
        if not isinstance(existing, dict) or "okf_export" in existing:
            raise ValueError(f"{file.path}: bm.okf_export extension collision")
        metadata["bm"] = {
            **existing,
            "okf_export": {"version": 1, "relations": relations},
        }
        # A graph-silent note (bm_parse_semantics: false) keeps its [[...]] text as
        # authored; rewriting it would invent edges the graph never recorded.
        body = document.body.replace("\r\n", "\n").replace("\r", "\n")
        if parse_semantics:
            body = convert_wikilinks(
                body,
                file.path,
                targets,
                snapshot.project,
                include_project=snapshot.permalinks_include_project,
                ambiguous_aliases=frozenset(ambiguous),
                permalinks=permalinks,
                title_targets=title_targets,
            )
        content = "---\n" + yaml.dump(
            metadata, Dumper=ExportDumper, allow_unicode=True, sort_keys=False
        )
        content += "---\n" + body
        output.append(ExportFile(file.path, content.encode("utf-8")))

    for directory in sorted(directories):
        index_path = str(directory / "index.md")
        lines = ['---\nokf_version: "0.2"\n---\n'] if directory == PurePosixPath(".") else []
        lines.append("# " + (snapshot.project if str(directory) == "." else directory.name) + "\n")
        # Index entries are for people, so order them case-insensitively
        # ("coffee" before "Espresso"); the raw path breaks casefold ties so the
        # output stays deterministic (#1635).
        for file in sorted(snapshot.files, key=lambda file: (file.path.casefold(), file.path)):
            path = PurePosixPath(file.path)
            if path.parent == directory:
                label = titles.get(file.path, path.stem)
                lines.append("- " + markdown_link(label, path.name))
        for child in sorted(directories, key=lambda child: (str(child).casefold(), str(child))):
            if child != directory and child.parent == directory:
                lines.append("- " + markdown_link(child.name, child.name + "/index.md"))
        output.append(ExportFile(index_path, ("\n".join(lines) + "\n").encode("utf-8")))

    log = [
        "# Recorded Basic Memory history\n",
        "Best-effort accepted changes recorded by Basic Memory. "
        "File materialization may lag recorded acceptance. Offline edits are not reconstructed.\n",
    ]
    day = ""
    for change in sorted(
        snapshot.changes, key=lambda change: (change.accepted_at, change.position), reverse=True
    ):
        change_day = change.accepted_at.date().isoformat()
        if change_day != day:
            log.append(f"\n## {change_day}\n")
            day = change_day
        log.append(f"- {change.operation}: {markdown_link(change.path, '/' + change.path)}")
    output.append(ExportFile("log.md", ("\n".join(log) + "\n").encode("utf-8")))
    return tuple(sorted(output, key=lambda file: file.path))
