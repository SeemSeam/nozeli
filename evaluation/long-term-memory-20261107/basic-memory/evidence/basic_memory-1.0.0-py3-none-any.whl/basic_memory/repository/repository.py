"""Base repository implementation."""

from typing import Optional, Any, Sequence, TypeVar, List, Dict, cast

from loguru import logger
from sqlalchemy import (
    select,
    func,
    Select,
    Executable,
    inspect,
    Result,
    and_,
    delete,
    update as sqlalchemy_update,
)
from sqlalchemy.engine import CursorResult
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.interfaces import LoaderOption
from sqlalchemy.sql.elements import ColumnElement

from basic_memory.models import Base

T = TypeVar("T", bound=Base)

# SQLite caps the number of bound parameters per statement (999 on builds older
# than 3.32.0), so id-list queries must stay below that floor. 500 leaves
# headroom for additional binds (e.g. the project_id filter) while keeping the
# number of round-trips low.
SELECT_BY_IDS_CHUNK_SIZE = 500


class Repository[T: Base]:
    """Base repository implementation with explicit caller-owned sessions."""

    def __init__(
        self,
        Model: type[T],
        project_id: Optional[int] = None,
    ):
        self.project_id = project_id
        if Model:
            self.Model = Model
            self.mapper = inspect(self.Model).mapper
            self.primary_key: ColumnElement[Any] = self.mapper.primary_key[0]
            self.valid_columns = [column.key for column in self.mapper.columns]
            # Check if this model has a project_id column
            self.has_project_id = "project_id" in self.valid_columns

    def _set_project_id_if_needed(self, model: T) -> None:
        """Set project_id on model if needed and available."""
        if (
            self.has_project_id
            and self.project_id is not None
            and getattr(model, "project_id", None) is None
        ):
            setattr(model, "project_id", self.project_id)

    def get_model_data(self, entity_data):
        model_data = {
            k: v for k, v in entity_data.items() if k in self.valid_columns and v is not None
        }
        return model_data

    def _add_project_filter[RowT: tuple[Any, ...]](self, query: Select[RowT]) -> Select[RowT]:
        """Add project_id filter to query if applicable.

        Args:
            query: The SQLAlchemy query to modify

        Returns:
            Updated query with project filter if applicable
        """
        if self.has_project_id and self.project_id is not None:
            query = query.filter(getattr(self.Model, "project_id") == self.project_id)
        return query

    async def select_by_id(self, session: AsyncSession, entity_id: int) -> Optional[T]:
        """Select an entity by ID using an existing session."""
        query = (
            select(self.Model)
            .filter(self.primary_key == entity_id)
            .options(*self.get_load_options())
        )
        # Add project filter if applicable
        query = self._add_project_filter(query)

        result = await session.execute(query)
        return result.scalars().one_or_none()

    async def select_by_ids(self, session: AsyncSession, ids: List[int]) -> Sequence[T]:
        """Select multiple entities by IDs using an existing session.

        Queries in chunks so callers can pass arbitrarily large id lists
        without hitting SQLite's bound-parameter limit (issue #1045).
        """
        results: list[T] = []
        for start in range(0, len(ids), SELECT_BY_IDS_CHUNK_SIZE):
            chunk = ids[start : start + SELECT_BY_IDS_CHUNK_SIZE]
            query = (
                select(self.Model)
                .where(self.primary_key.in_(chunk))
                .options(*self.get_load_options())
            )
            # Add project filter if applicable
            query = self._add_project_filter(query)

            result = await session.execute(query)
            results.extend(result.scalars().all())
        return results

    async def add(self, session: AsyncSession, model: T) -> T:
        """
        Add a model to the repository. This will also add related objects
        :param session: the caller-owned session to use
        :param model: the model to add
        :return: the added model instance
        """
        # Set project_id if applicable and not already set
        self._set_project_id_if_needed(model)

        session.add(model)
        await session.flush()

        # Query within same session
        found = await self.select_by_id(session, model.id)  # pyright: ignore [reportAttributeAccessIssue]
        if found is None:  # pragma: no cover
            logger.error(
                "Failed to retrieve model after add",
                model_type=self.Model.__name__,
                model_id=model.id,  # pyright: ignore
            )
            raise ValueError(
                f"Can't find {self.Model.__name__} with ID {model.id} after session.add"  # pyright: ignore
            )
        return found

    async def add_all(self, session: AsyncSession, models: List[T]) -> Sequence[T]:
        """
        Add a list of models to the repository. This will also add related objects
        :param session: the caller-owned session to use
        :param models: the models to add
        :return: the added models instances
        """
        # set the project id if not present in models
        for model in models:
            self._set_project_id_if_needed(model)

        session.add_all(models)
        await session.flush()

        # Query within same session
        return await self.select_by_ids(session, [m.id for m in models])  # pyright: ignore [reportAttributeAccessIssue]

    async def add_all_no_return(self, session: AsyncSession, models: List[T]) -> int:
        """Insert models without reloading them afterward."""
        if not models:
            return 0

        for model in models:
            self._set_project_id_if_needed(model)

        session.add_all(models)
        await session.flush()
        logger.debug(f"Added {len(models)} {self.Model.__name__} records")
        return len(models)

    def select(self, *entities: Any) -> Select[Any]:
        """Create a new SELECT statement.

        Returns:
            A SQLAlchemy Select object configured with the provided entities
            or this repository's model if no entities provided.
        """
        if not entities:
            entities = (self.Model,)
        query = select(*entities)

        # Add project filter if applicable
        return self._add_project_filter(query)

    async def find_all(
        self,
        session: AsyncSession,
        skip: int = 0,
        limit: Optional[int] = None,
        use_load_options: bool = True,
    ) -> Sequence[T]:
        """Fetch records from the database with pagination.

        Args:
            session: The caller-owned session to use
            skip: Number of records to skip
            limit: Maximum number of records to return
            use_load_options: Whether to apply eager loading options (default: True)
        """
        logger.debug(f"Finding all {self.Model.__name__} (skip={skip}, limit={limit})")

        query = select(self.Model).offset(skip)

        # Only apply load options if requested
        if use_load_options:
            query = query.options(*self.get_load_options())

        # Add project filter if applicable
        query = self._add_project_filter(query)

        if limit:
            query = query.limit(limit)

        result = await session.execute(query)

        items = result.scalars().all()
        logger.debug(f"Found {len(items)} {self.Model.__name__} records")
        return items

    async def find_by_id(self, session: AsyncSession, entity_id: Any) -> Optional[T]:
        """Fetch an entity by its unique identifier."""
        logger.debug(f"Finding {self.Model.__name__} by ID: {entity_id}")
        return await self.select_by_id(session, entity_id)

    async def find_by_ids(self, session: AsyncSession, ids: List[Any]) -> Sequence[T]:
        """Fetch multiple entities by their identifiers in a single query."""
        logger.debug(f"Finding {self.Model.__name__} by IDs: {ids}")
        return await self.select_by_ids(session, ids)

    async def find_one(self, session: AsyncSession, query: Select[tuple[T]]) -> Optional[T]:
        """Execute a query and retrieve a single record."""
        # add in load options
        query = query.options(*self.get_load_options())
        result = await self.execute_query(session, query)
        entity = result.scalars().one_or_none()

        if entity:
            logger.trace(f"Found {self.Model.__name__}: {getattr(entity, 'id', None)}")
        else:
            logger.trace(f"No {self.Model.__name__} found")
        return entity

    async def create(self, session: AsyncSession, data: dict[str, Any]) -> T:
        """Create a new record from a model instance."""
        logger.debug(f"Creating {self.Model.__name__} from entity_data: {data}")
        # Only include valid columns that are provided in entity_data
        model_data = self.get_model_data(data)

        # Add project_id if applicable and not already provided
        if self.has_project_id and self.project_id is not None and "project_id" not in model_data:
            model_data["project_id"] = self.project_id

        model = self.Model(**model_data)
        session.add(model)
        await session.flush()

        return_instance = await self.select_by_id(session, model.id)  # pyright: ignore [reportAttributeAccessIssue]
        if return_instance is None:  # pragma: no cover
            logger.error(
                "Failed to retrieve model after create",
                model_type=self.Model.__name__,
                model_id=model.id,  # pyright: ignore
            )
            raise ValueError(
                f"Can't find {self.Model.__name__} with ID {model.id} after session.add"  # pyright: ignore
            )
        return return_instance

    async def create_all(
        self, session: AsyncSession, data_list: List[dict[str, Any]]
    ) -> Sequence[T]:
        """Create multiple records in a single transaction."""
        logger.debug(f"Bulk creating {len(data_list)} {self.Model.__name__} instances")

        # Only include valid columns that are provided in entity_data
        model_list = []
        for d in data_list:
            model_data = self.get_model_data(d)

            # Add project_id if applicable and not already provided
            if (
                self.has_project_id
                and self.project_id is not None
                and "project_id" not in model_data
            ):
                model_data["project_id"] = self.project_id  # pragma: no cover

            model_list.append(self.Model(**model_data))

        session.add_all(model_list)
        await session.flush()

        return await self.select_by_ids(session, [model.id for model in model_list])  # pyright: ignore [reportAttributeAccessIssue]

    async def update(
        self,
        session: AsyncSession,
        entity_id: Any,
        entity_data: dict[str, Any] | T,
    ) -> Optional[T]:
        """Update an entity with the given data."""
        logger.debug(f"Updating {self.Model.__name__} {entity_id} with data: {entity_data}")
        entity = await self.select_by_id(session, entity_id)
        if entity is None:
            logger.debug(f"No {self.Model.__name__} found to update: {entity_id}")
            return None

        if isinstance(entity_data, dict):
            update_data = cast(dict[str, Any], entity_data)
            for key in self.valid_columns:
                if key in update_data:
                    setattr(entity, key, update_data[key])

        elif isinstance(entity_data, self.Model):
            for column in self.valid_columns:
                setattr(entity, column, getattr(entity_data, column))

        await session.flush()
        await session.refresh(entity)

        logger.debug(f"Updated {self.Model.__name__}: {entity_id}")
        return await self.select_by_id(session, entity.id)  # pyright: ignore [reportAttributeAccessIssue]

    async def update_fields(
        self, session: AsyncSession, entity_id: Any, entity_data: dict[str, Any]
    ) -> bool:
        """Update columns without reloading the model graph afterward."""
        update_data = {k: v for k, v in entity_data.items() if k in self.valid_columns}
        if not update_data:
            return True

        conditions = [self.primary_key == entity_id]
        if self.has_project_id and self.project_id is not None:
            conditions.append(getattr(self.Model, "project_id") == self.project_id)

        result = cast(
            CursorResult[Any],
            await session.execute(
                sqlalchemy_update(self.Model).where(and_(*conditions)).values(**update_data)
            ),
        )
        return result.rowcount > 0

    async def delete(self, session: AsyncSession, entity_id: int) -> bool:
        """Delete an entity from the database."""
        logger.debug(f"Deleting {self.Model.__name__}: {entity_id}")
        entity = await self.select_by_id(session, entity_id)
        if entity is None:
            logger.debug(f"No {self.Model.__name__} found to delete: {entity_id}")
            return False

        await session.delete(entity)
        await session.flush()

        logger.debug(f"Deleted {self.Model.__name__}: {entity_id}")
        return True

    async def delete_by_ids(self, session: AsyncSession, ids: List[int]) -> int:
        """Delete records matching given IDs."""
        logger.debug(f"Deleting {self.Model.__name__} by ids: {ids}")
        conditions = [self.primary_key.in_(ids)]

        # Add project_id filter if applicable
        if self.has_project_id and self.project_id is not None:  # pragma: no cover
            conditions.append(getattr(self.Model, "project_id") == self.project_id)

        query = delete(self.Model).where(and_(*conditions))
        result = cast(CursorResult[Any], await session.execute(query))
        logger.debug(f"Deleted {result.rowcount} records")
        return result.rowcount

    async def delete_by_fields(self, session: AsyncSession, **filters: Any) -> bool:
        """Delete records matching given field values."""
        logger.debug(f"Deleting {self.Model.__name__} by fields: {filters}")
        conditions = [getattr(self.Model, field) == value for field, value in filters.items()]

        # Add project_id filter if applicable
        if self.has_project_id and self.project_id is not None:
            conditions.append(getattr(self.Model, "project_id") == self.project_id)

        query = delete(self.Model).where(and_(*conditions))
        result = cast(CursorResult[Any], await session.execute(query))
        deleted = result.rowcount > 0
        logger.debug(f"Deleted {result.rowcount} records")
        return deleted

    async def count(self, session: AsyncSession, query: Executable | None = None) -> int:
        """Count entities in the database table."""
        if query is None:
            query = select(func.count()).select_from(self.Model)
            # Add project filter if applicable
            if isinstance(query, Select) and self.has_project_id and self.project_id is not None:
                query = query.where(
                    getattr(self.Model, "project_id") == self.project_id
                )  # pragma: no cover

        result = await session.execute(query)
        scalar = result.scalar()
        count = scalar if scalar is not None else 0
        logger.debug(f"Counted {count} {self.Model.__name__} records")
        return count

    async def execute_query(
        self,
        session: AsyncSession,
        query: Executable,
        params: Optional[Dict[str, Any]] = None,
        use_query_options: bool = True,
    ) -> Result[Any]:
        """Execute a query asynchronously."""

        query = query.options(*self.get_load_options()) if use_query_options else query
        logger.trace(f"Executing query: {query}, params: {params}")
        result = await session.execute(query, params)
        return result

    def get_load_options(self) -> List[LoaderOption]:
        """Get list of loader options for eager loading relationships.
        Override in subclasses to specify what to load."""
        return []
