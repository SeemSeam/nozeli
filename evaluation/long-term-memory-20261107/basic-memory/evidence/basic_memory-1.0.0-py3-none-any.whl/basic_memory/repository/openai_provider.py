"""OpenAI-based embedding provider for cloud or API-backed semantic indexing."""

from __future__ import annotations

import asyncio
import os
from typing import Any
from urllib.parse import urlparse

from basic_memory.repository.embedding_provider import unit_normalized
from basic_memory.repository.semantic_errors import SemanticDependenciesMissingError


# api.openai.com returns unit vectors, so vectors it produced never need re-embedding.
OFFICIAL_OPENAI_HOST = "api.openai.com"


def effective_openai_base_url(api_base: str | None) -> str | None:
    """Return the endpoint the OpenAI SDK will call: the setting, else OPENAI_BASE_URL."""
    return api_base or os.environ.get("OPENAI_BASE_URL") or None


def openai_embedding_identity(*, model_name: str, dimensions: int, api_base: str | None) -> str:
    """Return the stored-vector identity for an OpenAI-compatible embedding setup.

    Vectors are unit-normalized since #1862. api.openai.com always returned unit
    vectors, so its identity is unchanged and nothing re-embeds. A custom endpoint
    may have stored unnormalized vectors that match nothing; a new identity makes
    the next index pass re-embed them.
    """
    if api_base is None or urlparse(api_base).hostname == OFFICIAL_OPENAI_HOST:
        return f"{model_name}:{dimensions}"
    return f"{model_name}:{dimensions}:unit-normalized"


class OpenAIEmbeddingProvider:
    """Embedding provider backed by OpenAI's embeddings API."""

    def __init__(
        self,
        model_name: str = "text-embedding-3-small",
        *,
        batch_size: int = 64,
        request_concurrency: int = 4,
        dimensions: int = 1536,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.model_name = model_name
        self.dimensions = dimensions
        self.batch_size = batch_size
        self.request_concurrency = request_concurrency
        self._api_key = api_key
        self._base_url = base_url
        self._timeout = timeout
        self._client: Any | None = None
        self._client_lock = asyncio.Lock()

    def runtime_log_attrs(self) -> dict[str, int]:
        """Return the request fan-out knobs that shape API embedding batches."""
        return {
            "provider_batch_size": self.batch_size,
            "request_concurrency": self.request_concurrency,
        }

    def identity_key(self) -> str:
        """Return the embedding semantics that should invalidate stored vectors."""
        return openai_embedding_identity(
            model_name=self.model_name,
            dimensions=self.dimensions,
            api_base=effective_openai_base_url(self._base_url),
        )

    async def _get_client(self) -> Any:
        if self._client is not None:
            return self._client

        async with self._client_lock:
            if self._client is not None:
                return self._client

            try:
                from openai import AsyncOpenAI
            except ImportError as exc:  # pragma: no cover - covered via monkeypatch tests
                raise SemanticDependenciesMissingError(
                    "OpenAI dependency is missing. "
                    "Install/update basic-memory to include semantic dependencies: "
                    "pip install -U basic-memory"
                ) from exc

            api_key = self._api_key or os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise SemanticDependenciesMissingError(
                    "OpenAI embedding provider requires OPENAI_API_KEY."
                )

            self._client = AsyncOpenAI(
                api_key=api_key,
                base_url=self._base_url,
                timeout=self._timeout,
            )
            return self._client

    async def embed_documents(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []

        client = await self._get_client()
        batches = [
            texts[start : start + self.batch_size]
            for start in range(0, len(texts), self.batch_size)
        ]
        batch_vectors: list[list[list[float]] | None] = [None] * len(batches)
        semaphore = asyncio.Semaphore(self.request_concurrency)

        async def embed_batch(batch_index: int, batch: list[str]) -> None:
            async with semaphore:
                response = await client.embeddings.create(
                    model=self.model_name,
                    input=batch,
                )

            vectors_by_index: dict[int, list[float]] = {}
            for item in response.data:
                response_index = int(item.index)
                if response_index in vectors_by_index:
                    raise RuntimeError(
                        "OpenAI embedding response returned duplicate vector indexes."
                    )
                # OpenAI returns unit vectors; other OpenAI-compatible endpoints may not (#1862).
                vectors_by_index[response_index] = unit_normalized(
                    [float(value) for value in item.embedding]
                )

            ordered_vectors: list[list[float]] = []
            for index in range(len(batch)):
                vector = vectors_by_index.get(index)
                if vector is None:
                    raise RuntimeError(
                        "OpenAI embedding response is missing expected vector index."
                    )
                ordered_vectors.append(vector)

            batch_vectors[batch_index] = ordered_vectors

        await asyncio.gather(
            *(embed_batch(batch_index, batch) for batch_index, batch in enumerate(batches))
        )

        all_vectors: list[list[float]] = []
        for vectors in batch_vectors:
            if vectors is None:
                raise RuntimeError("OpenAI embedding batch did not produce vectors.")
            all_vectors.extend(vectors)

        if all_vectors and len(all_vectors[0]) != self.dimensions:
            raise RuntimeError(
                f"Embedding model returned {len(all_vectors[0])}-dimensional vectors "
                f"but provider was configured for {self.dimensions} dimensions."
            )
        return all_vectors

    async def embed_query(self, text: str) -> list[float]:
        vectors = await self.embed_documents([text])
        return vectors[0] if vectors else [0.0] * self.dimensions
