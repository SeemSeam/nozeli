"""LiteLLM-based embedding provider for semantic indexing.

Routes embedding requests to 100+ providers (OpenAI, Anthropic, Google, Azure,
Bedrock, Cohere, etc.) via the litellm SDK. No proxy server needed.

Model strings use the ``provider/model`` format, e.g.
``openai/text-embedding-3-small``, ``cohere/embed-english-v3.0``,
``azure/my-embedding-deployment``.

See https://docs.litellm.ai/docs/embedding/supported_embedding for all
supported embedding models.
"""

from __future__ import annotations

import asyncio
import os
from importlib import import_module
from typing import Any

from basic_memory.repository.embedding_provider import unit_normalized
from basic_memory.repository.semantic_errors import SemanticDependenciesMissingError


def _default_input_types(model_name: str) -> tuple[str | None, str | None]:
    """Return role-specific LiteLLM input_type defaults for known asymmetric models."""
    normalized = model_name.strip().lower()

    # Cohere v3 embeddings require search_document/search_query to distinguish
    # index-time passages from retrieval-time queries. LiteLLM supports both
    # direct Cohere model names and provider-prefixed forms.
    cohere_v3 = (
        normalized.startswith("cohere/")
        or normalized.startswith("bedrock/cohere.")
        or normalized.startswith("cohere.")
        or normalized.startswith("embed-")
    ) and "-v3" in normalized
    if cohere_v3:
        return "search_document", "search_query"

    # NVIDIA retrieval embeddings use passage/query roles. The provider prefix
    # is part of LiteLLM's model routing, so this stays narrowly scoped.
    if normalized.startswith("nvidia_nim/"):
        return "passage", "query"

    return None, None


def _should_forward_dimensions(model_name: str, forward_dimensions: bool | None) -> bool:
    """Return whether configured dimensions should be sent to LiteLLM."""
    if forward_dimensions is not None:
        return forward_dimensions

    normalized = model_name.strip().lower()

    # Trigger: `dimensions` is both the Basic Memory vector schema size and a
    # provider-side output-size request parameter in LiteLLM.
    # Why: fixed-size models such as Cohere v3 still need the schema value for
    # validation, but LiteLLM maps the request parameter to provider fields they
    # reject. Only send it for model families that clearly support output-size
    # control.
    # Outcome: OpenAI/Azure text-embedding-3 reductions work, while fixed-size
    # providers keep dimensions local to Basic Memory.
    return "text-embedding-3" in normalized


def litellm_embedding_identity(
    *,
    model_name: str,
    dimensions: int,
    document_input_type: str | None,
    query_input_type: str | None,
    forward_dimensions: bool | None,
) -> str:
    """Return the LiteLLM request semantics that invalidate stored vectors."""
    resolved_document_input_type = document_input_type or "-"
    resolved_query_input_type = query_input_type or "-"
    resolved_forward_dimensions = str(
        _should_forward_dimensions(model_name, forward_dimensions)
    ).lower()
    return (
        f"{model_name}:{dimensions}:"
        f"document_input_type={resolved_document_input_type}:"
        f"query_input_type={resolved_query_input_type}:"
        f"forward_dimensions={resolved_forward_dimensions}"
    )


def _import_litellm() -> Any:
    """Import LiteLLM without letting its import-time dotenv hook read cwd secrets."""
    # Constraint: LiteLLM 1.85.0 loads .env files at import time when
    # LITELLM_MODE defaults to DEV. Basic Memory intentionally does not load
    # arbitrary cwd .env files, so set the production mode before importing
    # unless the caller already made an explicit LiteLLM choice.
    os.environ.setdefault("LITELLM_MODE", "PRODUCTION")

    try:
        litellm = import_module("litellm")
    except ImportError as exc:
        raise SemanticDependenciesMissingError(
            "LiteLLM embeddings and reranking need the optional SDK. "
            "Install basic-memory[litellm], for example with "
            '`uv tool install --force "basic-memory[litellm]" --prerelease=allow --python 3.14` or '
            '`pip install "basic-memory[litellm]"`. '
            "Include any other extras you use in the same specification. "
            "For Homebrew-managed installations, launch an isolated process with "
            '`uvx --python 3.14 --prerelease=allow --from "basic-memory[litellm]" bm` '
            "instead of the Cellar executable."
        ) from exc

    return litellm


class LiteLLMEmbeddingProvider:
    """Embedding provider backed by the litellm SDK."""

    def __init__(
        self,
        model_name: str = "openai/text-embedding-3-small",
        *,
        batch_size: int = 64,
        request_concurrency: int = 4,
        dimensions: int = 1536,
        api_key: str | None = None,
        api_base: str | None = None,
        timeout: float = 30.0,
        document_input_type: str | None = None,
        query_input_type: str | None = None,
        forward_dimensions: bool | None = None,
    ) -> None:
        self.model_name = model_name
        self.dimensions = dimensions
        self.batch_size = batch_size
        self.request_concurrency = request_concurrency
        self._api_key = api_key
        self._api_base = api_base
        self._timeout = timeout
        default_document_input_type, default_query_input_type = _default_input_types(model_name)
        self.document_input_type = document_input_type or default_document_input_type
        self.query_input_type = query_input_type or default_query_input_type
        self.forward_dimensions = forward_dimensions

    def runtime_log_attrs(self) -> dict[str, Any]:
        """Return provider-specific runtime settings suitable for startup logs."""
        attrs: dict[str, Any] = {
            "provider_batch_size": self.batch_size,
            "request_concurrency": self.request_concurrency,
        }
        if self.document_input_type:
            attrs["document_input_type"] = self.document_input_type
        if self.query_input_type:
            attrs["query_input_type"] = self.query_input_type
        if self.forward_dimensions is not None:
            attrs["forward_dimensions"] = self.forward_dimensions
        return attrs

    def identity_key(self) -> str:
        """Return the embedding semantics that should invalidate stored vectors."""
        return litellm_embedding_identity(
            model_name=self.model_name,
            dimensions=self.dimensions,
            document_input_type=self.document_input_type,
            query_input_type=self.query_input_type,
            forward_dimensions=self.forward_dimensions,
        )

    async def _embed(self, texts: list[str], *, input_type: str | None) -> list[list[float]]:
        if not texts:
            return []

        litellm = _import_litellm()

        batches = [
            texts[start : start + self.batch_size]
            for start in range(0, len(texts), self.batch_size)
        ]
        batch_vectors: list[list[list[float]] | None] = [None] * len(batches)
        semaphore = asyncio.Semaphore(self.request_concurrency)

        async def embed_batch(batch_index: int, batch: list[str]) -> None:
            async with semaphore:
                params: dict[str, Any] = {
                    "model": self.model_name,
                    "input": batch,
                    "drop_params": True,
                    "timeout": self._timeout,
                }
                if _should_forward_dimensions(self.model_name, self.forward_dimensions):
                    params["dimensions"] = self.dimensions
                if self._api_key:
                    params["api_key"] = self._api_key
                if self._api_base is not None:
                    params["api_base"] = self._api_base
                if input_type:
                    params["input_type"] = input_type

                response = await litellm.aembedding(**params)

            vectors_by_index: dict[int, list[float]] = {}
            for item in response.data:
                if isinstance(item, dict):
                    response_index = int(item["index"])
                    embedding = item["embedding"]
                else:
                    response_index = int(item.index)
                    embedding = item.embedding
                if response_index in vectors_by_index:
                    raise RuntimeError(
                        "LiteLLM embedding response returned duplicate vector indexes."
                    )
                vectors_by_index[response_index] = [float(v) for v in embedding]

            ordered_vectors: list[list[float]] = []
            for index in range(len(batch)):
                vector = vectors_by_index.get(index)
                if vector is None:
                    raise RuntimeError(
                        "LiteLLM embedding response is missing expected vector index."
                    )
                ordered_vectors.append(vector)

            batch_vectors[batch_index] = ordered_vectors

        await asyncio.gather(
            *(embed_batch(batch_index, batch) for batch_index, batch in enumerate(batches))
        )

        all_vectors: list[list[float]] = []
        for vectors in batch_vectors:
            if vectors is None:
                raise RuntimeError("LiteLLM embedding batch did not produce vectors.")
            all_vectors.extend(vectors)

        # LiteLLM routes to many backends (Cohere, Vertex, Bedrock, etc.), and not
        # all of them return unit vectors.
        normalized = [unit_normalized(vector) for vector in all_vectors]

        if normalized and len(normalized[0]) != self.dimensions:
            raise RuntimeError(
                f"Embedding model returned {len(normalized[0])}-dimensional vectors "
                f"but provider was configured for {self.dimensions} dimensions."
            )
        return normalized

    async def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return await self._embed(texts, input_type=self.document_input_type)

    async def embed_query(self, text: str) -> list[float]:
        vectors = await self._embed([text], input_type=self.query_input_type)
        return vectors[0] if vectors else [0.0] * self.dimensions
