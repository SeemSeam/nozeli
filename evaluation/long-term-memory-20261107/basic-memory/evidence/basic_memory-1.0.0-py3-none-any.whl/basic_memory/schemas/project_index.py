"""Pydantic schemas for project-index route responses."""

from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

from basic_memory.schemas.project_readiness import ProjectIndexReadiness

if TYPE_CHECKING:
    from basic_memory.index.project_indexing import ProjectIndexObservation
    from basic_memory.indexing.project_index_coordinator import ProjectIndexCoordinatorResult


class ProjectIndexObservedFileResponse(BaseModel):
    """One project file observed by the project-index runtime."""

    path: str = Field(description="Project-relative file path")
    checksum: str | None = Field(default=None, description="Observed storage checksum")
    size: int | None = Field(default=None, description="Observed storage object size in bytes")


class ProjectIndexStatusResponse(BaseModel):
    """Current project-index observation for a local project.

    ``total_files`` is a live filesystem count and says nothing about what was
    indexed; ``readiness`` is the part a caller waits on (#1414).
    """

    total_files: int = Field(description="Number of files observed for project indexing")
    observed_files: tuple[ProjectIndexObservedFileResponse, ...] = Field(
        description="Files observed by the project-index runtime"
    )
    readiness: ProjectIndexReadiness = Field(
        description="Whether the index can be trusted, and what each stage still owes"
    )

    @classmethod
    def from_observation(
        cls,
        observation: "ProjectIndexObservation",
        readiness: ProjectIndexReadiness,
    ) -> "ProjectIndexStatusResponse":
        return cls(
            total_files=observation.total_files,
            observed_files=tuple(
                ProjectIndexObservedFileResponse(
                    path=file.path,
                    checksum=file.checksum,
                    size=file.size,
                )
                for file in observation.observed_files
            ),
            readiness=readiness,
        )


class ProjectIndexRunResponse(BaseModel):
    """Summary of one project-index coordinator run."""

    total_files: int = Field(description="Number of files discovered for indexing")
    enqueued_files: int = Field(description="Number of files submitted to child index work")
    enqueued_batches: int = Field(description="Number of child index batches submitted")
    deleted_files: int = Field(description="Number of orphaned indexed files deleted")

    @classmethod
    def from_result(cls, result: "ProjectIndexCoordinatorResult") -> "ProjectIndexRunResponse":
        return cls(
            total_files=result.total_files,
            enqueued_files=result.enqueued_files,
            enqueued_batches=result.enqueued_batches,
            deleted_files=result.deleted_files,
        )
