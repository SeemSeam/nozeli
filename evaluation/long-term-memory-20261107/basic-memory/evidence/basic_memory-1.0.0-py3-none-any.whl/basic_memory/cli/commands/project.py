"""Command module for basic-memory project management."""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, NoReturn

import typer
from loguru import logger
from rich.console import Console, Group
from rich.markup import escape
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from basic_memory.cli.app import app
from basic_memory.cli.auth import CLIAuth
from basic_memory.cli.commands.cloud.api_client import CloudAPIError, make_api_request
from basic_memory.cli.commands.cloud.mount_api import get_mount_info
from basic_memory.cli.commands.cloud.project_sync import (
    _has_cloud_credentials,
    _require_cloud_credentials,
)
from basic_memory.cli.commands.cloud.rclone_commands import (
    SyncProject,
    project_ls,
)
from basic_memory.cli.commands.command_utils import (
    get_project_info,
    run_with_cleanup,
)
from basic_memory.cli.commands.db import index_project_and_report_readiness, run_reindex_command
from basic_memory.cli.commands.routing import force_routing, validate_routing_flags
from basic_memory.config import BasicMemoryConfig, ConfigManager, ProjectEntry, ProjectMode
from basic_memory.mcp.async_client import get_client, resolve_configured_workspace
from basic_memory.mcp.clients import ProjectClient
from basic_memory.schemas.cloud import (
    CloudProjectIndexStatus,
    CloudTenantIndexStatusResponse,
    ProjectVisibility,
    WorkspaceInfo,
    format_workspace_choices,
    format_workspace_selection_choices,
    workspace_matches_identifier,
)
from basic_memory.schemas.project_info import ProjectItem, ProjectList
from basic_memory.schemas.v2 import ProjectResolveResponse
from basic_memory.utils import generate_permalink, normalize_project_path, shell_command
from basic_memory.cli.markup import literal

console = Console()

# Create a project subcommand
project_app = typer.Typer(help="Manage multiple Basic Memory projects")
app.add_typer(project_app, name="project")


def format_path(path: str) -> str:
    """Format a path for display, using ~ for home directory."""
    home = str(Path.home())
    if path.startswith(home):
        return path.replace(home, "~", 1)  # pragma: no cover
    return path


def make_bar(value: int, max_value: int, width: int = 40) -> Text:
    """Create a horizontal bar chart element using Unicode blocks."""
    if max_value == 0:
        return Text("░" * width, style="dim")
    filled = max(1, round(value / max_value * width)) if value > 0 else 0
    bar = Text()
    bar.append("█" * filled, style="cyan")
    bar.append("░" * (width - filled), style="dim")
    return bar


def _uses_cloud_project_info_route(project_name: str, *, local: bool, cloud: bool) -> bool:
    """Return whether project info should attempt cloud augmentation."""
    if local:
        return False
    if cloud:
        return True

    config_manager = ConfigManager()
    resolved_name, _ = config_manager.get_project(project_name)
    effective_name = resolved_name or project_name
    return config_manager.config.get_project_mode(effective_name) == ProjectMode.CLOUD


def _resolve_cloud_status_workspace_id(project_name: str) -> str:
    """Resolve the tenant/workspace for cloud index status lookup."""
    config_manager = ConfigManager()
    config = config_manager.config

    if not _has_cloud_credentials(config):
        raise RuntimeError(
            "Cloud credentials not found. Run `bm cloud api-key save <key>` or `bm cloud login` first."
        )

    configured_name, _ = config_manager.get_project(project_name)
    effective_name = configured_name or project_name

    workspace_id = resolve_configured_workspace(config=config, project_name=effective_name)
    if workspace_id is not None:
        return workspace_id

    workspace_id = _resolve_workspace_id(config, None)
    if workspace_id is not None:
        return workspace_id

    raise RuntimeError(
        f"Cloud workspace could not be resolved for project '{effective_name}'. "
        "Set a project workspace with `bm project set-cloud --workspace ...` or configure a "
        "default workspace with `bm cloud workspace set-default ...`."
    )


async def _resolve_cloud_status_workspace_id_async(project_name: str) -> str:
    """Resolve the tenant/workspace for cloud index status lookup in async contexts."""
    config_manager = ConfigManager()
    config = config_manager.config

    if not _has_cloud_credentials(config):
        raise RuntimeError(
            "Cloud credentials not found. Run `bm cloud api-key save <key>` or `bm cloud login` first."
        )

    configured_name, _ = config_manager.get_project(project_name)
    effective_name = configured_name or project_name

    workspace_id = resolve_configured_workspace(config=config, project_name=effective_name)
    if workspace_id is not None:
        return workspace_id

    from basic_memory.mcp.project_context import get_available_workspaces

    workspaces = await get_available_workspaces()
    if len(workspaces) == 1:
        return workspaces[0].tenant_id

    raise RuntimeError(
        f"Cloud workspace could not be resolved for project '{effective_name}'. "
        "Set a project workspace with `bm project set-cloud --workspace ...` or configure a "
        "default workspace with `bm cloud workspace set-default ...`."
    )


def _match_cloud_index_status_project(
    project_name: str, projects: list[CloudProjectIndexStatus]
) -> CloudProjectIndexStatus | None:
    """Match the requested project against the tenant index-status payload."""
    exact_match = next(
        (project for project in projects if project.project_name == project_name), None
    )
    if exact_match is not None:
        return exact_match

    project_permalink = generate_permalink(project_name)
    permalink_matches = [
        project
        for project in projects
        if generate_permalink(project.project_name) == project_permalink
    ]
    if len(permalink_matches) == 1:
        return permalink_matches[0]

    return None


def _format_cloud_index_status_error(error: Exception) -> str:
    """Convert cloud lookup failures into concise user-facing text."""
    if isinstance(error, CloudAPIError):
        detail_message: str | None = None
        detail = error.detail.get("detail")
        if isinstance(detail, str):
            detail_message = detail
        elif isinstance(detail, dict):
            if isinstance(detail.get("message"), str):
                detail_message = detail["message"]
            elif isinstance(detail.get("detail"), str):
                detail_message = detail["detail"]

        if error.status_code and detail_message:
            return f"HTTP {error.status_code}: {detail_message}"
        if error.status_code:
            return f"HTTP {error.status_code}"

    return str(error)


async def _fetch_cloud_project_index_status(project_name: str) -> CloudProjectIndexStatus:
    """Fetch cloud index freshness for one project from the admin tenant endpoint."""
    workspace_id = await _resolve_cloud_status_workspace_id_async(project_name)
    host_url = ConfigManager().config.cloud_host.rstrip("/")

    try:
        response = await make_api_request(
            method="GET",
            url=f"{host_url}/admin/tenants/{workspace_id}/index-status",
        )
    except typer.Exit as exc:
        if exc.exit_code not in (None, 0):
            raise RuntimeError(
                "Cloud credentials not found. Run `bm cloud api-key save <key>` or "
                "`bm cloud login` first."
            ) from exc
        raise

    tenant_status = CloudTenantIndexStatusResponse.model_validate(response.json())
    if tenant_status.error:
        raise RuntimeError(tenant_status.error)

    project_status = _match_cloud_index_status_project(project_name, tenant_status.projects)
    if project_status is None:
        raise RuntimeError(
            f"Project '{project_name}' was not found in workspace index status "
            f"for tenant '{workspace_id}'."
        )

    return project_status


def _load_cloud_project_index_status(
    project_name: str,
) -> tuple[CloudProjectIndexStatus | None, str | None]:
    """Best-effort wrapper around the cloud index freshness lookup."""
    try:
        return run_with_cleanup(_fetch_cloud_project_index_status(project_name)), None
    except Exception as exc:
        return None, _format_cloud_index_status_error(exc)


def _build_cloud_index_status_section(
    cloud_index_status: CloudProjectIndexStatus | None,
    cloud_index_status_error: str | None,
) -> Table | None:
    """Render the optional Cloud Index Status block for rich project info."""
    if cloud_index_status is None and cloud_index_status_error is None:
        return None

    table = Table.grid(padding=(0, 2))
    table.add_column("property", style="cyan")
    table.add_column("value", style="green")

    table.add_row("[bold]Cloud Index Status[/bold]", "")

    if cloud_index_status_error is not None:
        table.add_row("[yellow]●[/yellow] Warning", f"[yellow]{cloud_index_status_error}[/yellow]")
        return table

    if cloud_index_status is None:
        return table

    table.add_row("Files", str(cloud_index_status.current_file_count))
    table.add_row(
        "Note content",
        f"{cloud_index_status.note_content_synced}/{cloud_index_status.current_file_count}",
    )
    table.add_row(
        "Search",
        f"{cloud_index_status.total_indexed_entities}/{cloud_index_status.current_file_count}",
    )
    table.add_row("Embeddable", str(cloud_index_status.embeddable_indexed_entities))
    table.add_row(
        "Vectorized",
        (
            f"{cloud_index_status.total_entities_with_chunks}/"
            f"{cloud_index_status.embeddable_indexed_entities}"
        ),
    )

    if cloud_index_status.reindex_recommended:
        table.add_row("[yellow]●[/yellow] Status", "[yellow]Reindex recommended[/yellow]")
        if cloud_index_status.reindex_reason:
            table.add_row("Reason", f"[yellow]{cloud_index_status.reindex_reason}[/yellow]")
    else:
        table.add_row("[green]●[/green] Status", "[green]Up to date[/green]")

    return table


def _normalize_project_visibility(visibility: str | None) -> ProjectVisibility:
    """Normalize CLI visibility input to the cloud API contract."""
    if visibility is None:
        return "workspace"

    normalized = visibility.strip().lower()
    if normalized == "workspace" or normalized == "shared":
        return normalized

    # "private" was accepted here while the cloud has no such tier, so users
    # were told their project was private when the whole team could see it (#1343).
    raise ValueError("Invalid visibility. Expected one of: workspace, shared.")


def _resolve_workspace_id(config, workspace: str | None) -> str | None:
    """Resolve a workspace name, slug, type, or tenant_id to a tenant_id."""
    from basic_memory.mcp.project_context import (
        get_available_workspaces,
    )

    if workspace is not None:
        workspaces = run_with_cleanup(get_available_workspaces())
        matches = [ws for ws in workspaces if workspace_matches_identifier(ws, workspace)]
        if not matches:
            console.print(f"[red]Error: Workspace '{literal(workspace)}' not found[/red]")
            if workspaces:
                console.print(
                    f"[dim]Available:\n{literal(format_workspace_choices(workspaces))}[/dim]"
                )
            raise typer.Exit(1)
        if len(matches) > 1:
            console.print(
                f"[red]Error: Workspace '{literal(workspace)}' matches multiple workspaces.[/red]"
            )
            console.print(
                "[dim]Choose one of these matching workspaces by slug:\n"
                f"{literal(format_workspace_selection_choices(matches))}[/dim]"
            )
            raise typer.Exit(1)
        return matches[0].tenant_id

    if config.default_workspace:
        return config.default_workspace

    try:
        workspaces = run_with_cleanup(get_available_workspaces())
        if len(workspaces) == 1:
            return workspaces[0].tenant_id
    except Exception as exc:
        # Workspace resolution is optional until a command needs a specific tenant.
        logger.debug("Workspace resolution failed: {}", exc)

    return None


@project_app.command("list")
def list_projects(
    local: bool = typer.Option(False, "--local", help="Force local routing for this command"),
    cloud: bool = typer.Option(False, "--cloud", help="Force cloud API routing"),
    workspace: str = typer.Option(
        None,
        "--workspace",
        help="Cloud workspace name, slug, type, or tenant_id",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
) -> None:
    """List Basic Memory projects from local and (when available) cloud."""
    try:
        validate_routing_flags(local, cloud)
    except ValueError as e:
        console.print(f"[red]Error: {literal(e)}[/red]")
        raise typer.Exit(1)

    async def _list_projects(ws: str | None = None):
        async with get_client(workspace=ws) as client:
            return await ProjectClient(client).list_projects()

    try:
        config = ConfigManager().config
        workspace_filter = workspace
        workspace_filter_requested = workspace_filter is not None

        local_result: ProjectList | None = None
        cloud_results: list[tuple[WorkspaceInfo | None, ProjectList]] = []
        available_cloud_workspaces: list[WorkspaceInfo] = []
        cloud_error: Exception | None = None
        cloud_workspace_error: Exception | None = None
        failed_cloud_workspaces: list[tuple[WorkspaceInfo, Exception]] = []

        def _fetch_cloud_workspace_results() -> tuple[
            list[tuple[WorkspaceInfo | None, ProjectList]],
            list[WorkspaceInfo],
            Exception | None,
            list[tuple[WorkspaceInfo, Exception]],
        ]:
            from basic_memory.mcp.project_context import (
                get_available_workspaces,
            )

            try:
                workspaces = run_with_cleanup(get_available_workspaces())
            except Exception as exc:
                fallback_workspace = workspace_filter or config.default_workspace
                return (
                    [(None, run_with_cleanup(_list_projects(fallback_workspace)))],
                    [],
                    exc,
                    [],
                )

            selected_workspaces = workspaces
            if workspace_filter is not None:
                matches = [
                    ws for ws in workspaces if workspace_matches_identifier(ws, workspace_filter)
                ]
                if not matches:
                    console.print(
                        f"[red]Error: Workspace '{literal(workspace_filter)}' not found[/red]"
                    )
                    if workspaces:
                        console.print(
                            f"[dim]Available:\n{literal(format_workspace_choices(workspaces))}[/dim]"
                        )
                    raise typer.Exit(1)
                if len(matches) > 1:
                    console.print(
                        f"[red]Error: Workspace '{literal(workspace_filter)}' matches multiple workspaces.[/red]"
                    )
                    console.print(
                        "[dim]Choose one of these matching workspaces by slug:\n"
                        f"{literal(format_workspace_selection_choices(matches))}[/dim]"
                    )
                    raise typer.Exit(1)
                selected_workspaces = matches

            if not selected_workspaces:
                return [], workspaces, None, []

            results: list[tuple[WorkspaceInfo | None, ProjectList]] = []
            failed_workspaces: list[tuple[WorkspaceInfo, Exception]] = []
            for cloud_workspace in selected_workspaces:
                try:
                    results.append(
                        (
                            cloud_workspace,
                            run_with_cleanup(_list_projects(cloud_workspace.tenant_id)),
                        )
                    )
                except Exception as exc:
                    failed_workspaces.append((cloud_workspace, exc))

            if not results and failed_workspaces:
                raise failed_workspaces[0][1]

            return results, workspaces, None, failed_workspaces

        if cloud:
            with console.status("[bold blue]Fetching cloud projects...", spinner="dots"):
                with force_routing(cloud=True):
                    (
                        cloud_results,
                        available_cloud_workspaces,
                        cloud_workspace_error,
                        failed_cloud_workspaces,
                    ) = _fetch_cloud_workspace_results()
        elif local:
            with force_routing(local=True):
                local_result = run_with_cleanup(_list_projects())
        else:
            # Default behavior: always show local projects first.
            with force_routing(local=True):
                local_result = run_with_cleanup(_list_projects())

            if _has_cloud_credentials(config):
                try:
                    with console.status("[bold blue]Fetching cloud projects...", spinner="dots"):
                        with force_routing(cloud=True):
                            (
                                cloud_results,
                                available_cloud_workspaces,
                                cloud_workspace_error,
                                failed_cloud_workspaces,
                            ) = _fetch_cloud_workspace_results()
                except typer.Exit:
                    raise
                except Exception as exc:  # pragma: no cover
                    cloud_error = exc

        table = Table(title="Basic Memory Projects")
        table.add_column("Name", style="cyan")
        table.add_column("Local Path", style="yellow", no_wrap=True, overflow="fold")
        table.add_column("Cloud Path", style="green")
        table.add_column("Workspace", style="green")
        table.add_column("CLI Route", style="blue")
        table.add_column("MCP", style="blue")
        table.add_column("Sync", style="green")
        table.add_column("Default", style="magenta")

        row_names_by_key: dict[tuple[str | None, str], str] = {}
        local_projects_by_permalink: dict[str, ProjectItem] = {}
        cloud_projects_by_key: dict[tuple[str | None, str], ProjectItem] = {}
        cloud_workspaces_by_key: dict[tuple[str | None, str], WorkspaceInfo | None] = {}

        if local_result:
            for project in local_result.projects:
                permalink = generate_permalink(project.name)
                local_projects_by_permalink[permalink] = project

        for cloud_workspace, cloud_result in cloud_results:
            workspace_key = cloud_workspace.tenant_id if cloud_workspace else None
            for project in cloud_result.projects:
                permalink = generate_permalink(project.name)
                row_key = (workspace_key, permalink)
                row_names_by_key[row_key] = project.name
                cloud_projects_by_key[row_key] = project
                cloud_workspaces_by_key[row_key] = cloud_workspace

        cloud_permalinks = {permalink for _, permalink in cloud_projects_by_key}
        for permalink, project in local_projects_by_permalink.items():
            if permalink not in cloud_permalinks:
                row_names_by_key[(None, permalink)] = project.name

        cloud_keys_by_permalink: dict[str, list[tuple[str | None, str]]] = {}
        for row_key in cloud_projects_by_key:
            cloud_keys_by_permalink.setdefault(row_key[1], []).append(row_key)

        configured_names_by_permalink = {
            generate_permalink(project_name): project_name for project_name in config.projects
        }

        # Trigger: a project in config.projects was surfaced by neither query — the
        #   cloud branch is skipped without credentials, and a cloud-mode project is
        #   not returned by the local query.
        # Why: without a fallback such a project is invisible in `bm project list`,
        #   yet `bm project add` reads the DB and reports it already exists (#1003).
        #   The two commands must agree on whether a configured project exists.
        # Outcome: seed a local-keyed row from config so the project still renders;
        #   the row-building logic below derives its display from the config entry.
        # Constraint: only fill from config for the default combined view. Explicit
        #   --local, --cloud, and --workspace listings are deliberately scoped, so
        #   configured projects must not leak into them.
        if not local and local_result is not None and not workspace_filter_requested:
            seeded_permalinks = {permalink for _, permalink in row_names_by_key}
            for permalink, project_name in configured_names_by_permalink.items():
                if permalink not in seeded_permalinks:
                    row_names_by_key[(None, permalink)] = project_name

        def _workspace_priority(row_key: tuple[str | None, str]) -> tuple[bool, int, str, str]:
            """Prefer the user's default/personal workspace when a project is duplicated."""
            workspace = cloud_workspaces_by_key.get(row_key)
            if workspace is None:
                return (True, 2, "", row_key[0] or "")
            workspace_type_rank = 0 if workspace.workspace_type == "personal" else 1
            return (
                not workspace.is_default,
                workspace_type_rank,
                workspace.name.casefold(),
                row_key[0] or "",
            )

        def _select_attached_row_key(
            permalink: str, entry: ProjectEntry | None
        ) -> tuple[str | None, str] | None:
            """Choose the single row that owns local config/default/sync state."""
            cloud_keys = cloud_keys_by_permalink.get(permalink, [])
            if not cloud_keys:
                return (None, permalink)

            preferred_workspace_ids: list[str] = []
            if entry and entry.workspace_id:
                preferred_workspace_ids.append(entry.workspace_id)
            if config.default_workspace and config.default_workspace not in preferred_workspace_ids:
                preferred_workspace_ids.append(config.default_workspace)
            default_cloud_workspace = next(
                (item for item in available_cloud_workspaces if item.is_default),
                None,
            )
            if (
                default_cloud_workspace
                and default_cloud_workspace.tenant_id not in preferred_workspace_ids
            ):
                preferred_workspace_ids.append(default_cloud_workspace.tenant_id)

            for workspace_id in preferred_workspace_ids:
                for row_key in cloud_keys:
                    if row_key[0] == workspace_id:
                        return row_key

            if workspace_filter_requested and preferred_workspace_ids:
                # A filtered list can exclude the workspace that owns local config state.
                # In that case, do not attach local/default/sync state to another workspace row.
                return None

            default_workspace_keys = [
                row_key
                for row_key in cloud_keys
                if (row_workspace := cloud_workspaces_by_key.get(row_key)) is not None
                and row_workspace.is_default
            ]
            if len(default_workspace_keys) == 1:
                return default_workspace_keys[0]

            if len(cloud_keys) == 1:
                return cloud_keys[0]

            return sorted(cloud_keys, key=_workspace_priority)[0]

        attached_row_by_permalink: dict[str, tuple[str | None, str] | None] = {}
        for permalink in set(local_projects_by_permalink) | set(configured_names_by_permalink):
            configured_name = configured_names_by_permalink.get(permalink)
            local_project = local_projects_by_permalink.get(permalink)
            entry_name = configured_name or (local_project.name if local_project else None)
            entry = config.projects.get(entry_name) if entry_name else None
            attached_row_by_permalink[permalink] = _select_attached_row_key(permalink, entry)

        # --- Build unified project list ---
        project_rows: list[dict[str, Any]] = []
        sorted_row_keys = sorted(
            row_names_by_key,
            key=lambda key: (row_names_by_key[key], key[0] or ""),
        )
        for row_key in sorted_row_keys:
            _, permalink = row_key
            project_name = row_names_by_key[row_key]
            is_attached_row = attached_row_by_permalink.get(permalink) == row_key
            local_project = local_projects_by_permalink.get(permalink) if is_attached_row else None
            cloud_project = cloud_projects_by_key.get(row_key)
            cloud_workspace = cloud_workspaces_by_key.get(row_key)
            configured_name = configured_names_by_permalink.get(permalink)
            configured_entry = (
                config.projects.get(configured_name)
                if configured_name
                else config.projects.get(project_name)
            )
            entry = configured_entry if is_attached_row else None

            local_path = ""
            if local_project is not None:
                local_path = format_path(normalize_project_path(local_project.path))
            elif entry and entry.local_sync_path:
                local_path = format_path(entry.local_sync_path)
            elif entry and entry.mode == ProjectMode.LOCAL and entry.path:
                local_path = format_path(normalize_project_path(entry.path))

            # Clear local path for cloud-mode projects — only local projects
            # should display a local path
            if entry and entry.mode == ProjectMode.CLOUD:
                local_path = ""

            cloud_path = ""
            if cloud_project is not None:
                cloud_path = normalize_project_path(cloud_project.path)

            if local:
                cli_route = "local (flag)"
            elif cloud:
                cli_route = "cloud (flag)"
            elif entry:
                cli_route = entry.mode.value
            elif cloud_project is not None and local_project is None:
                cli_route = ProjectMode.CLOUD.value
            else:
                cli_route = ProjectMode.LOCAL.value

            default_permalink = (
                generate_permalink(config.default_project) if config.default_project else None
            )
            is_default = bool(is_attached_row and permalink == default_permalink)

            # Show workspace name (type) for cloud-sourced projects
            cloud_ws_name = cloud_workspace.name if cloud_workspace else None
            cloud_ws_type = cloud_workspace.workspace_type if cloud_workspace else None

            # Push/pull works on every workspace type (rclone on Personal, WebDAV
            # on Team), so a local sync path is usable everywhere. The JSON keys
            # stay for scripts that read them; the Personal-only mirror commands
            # (sync/bisync) were removed in 1.0 (#1845).
            sync_supported = True
            sync_reason = None
            local_usage = "sync-supported"
            has_sync = bool(is_attached_row and entry and entry.local_sync_path)
            # Determine MCP transport based on project routing mode
            if entry and entry.mode == ProjectMode.CLOUD:
                mcp_transport = "https"
            elif entry is None and cloud_project is not None:
                mcp_transport = "https"
            else:
                mcp_transport = "stdio"

            # display_name is a human label for private UUID-named projects (e.g., "My Project").
            # Keep "name" as the canonical identifier for scripting/JSON consumers;
            # the Rich table uses display_name when available.
            display_name = (
                cloud_project.display_name if cloud_project and cloud_project.display_name else None
            )
            row_data = {
                "name": project_name,
                "permalink": permalink,
                "local_path": local_path,
                "cloud_path": cloud_path,
                "cli_route": cli_route,
                "mcp_stdio": mcp_transport,
                "sync": has_sync,
                "sync_supported": sync_supported,
                "sync_reason": sync_reason,
                "local_usage": local_usage,
                "is_default": is_default,
            }
            if display_name:
                row_data["display_name"] = display_name
            if cloud_project is not None and cloud_ws_name:
                row_data["workspace"] = cloud_ws_name
                if cloud_ws_type:
                    row_data["workspace_type"] = cloud_ws_type

            project_rows.append(row_data)

        # --- JSON output ---
        if json_output:
            print(json.dumps({"projects": project_rows}, indent=2, default=str))
            return

        # --- Rich table output ---
        for row_data in project_rows:
            sync_display = "[X]" if row_data["sync"] else ""
            table.add_row(
                row_data.get("display_name") or row_data["name"],
                row_data["local_path"],
                row_data["cloud_path"],
                row_data.get("workspace", "")
                + (f" ({row_data['workspace_type']})" if row_data.get("workspace_type") else ""),
                row_data["cli_route"],
                row_data["mcp_stdio"],
                sync_display,
                "[X]" if row_data["is_default"] else "",
            )

        console.print(table)
        if cloud_error is not None:
            console.print(
                f"[yellow]Cloud project discovery failed: {literal(cloud_error)}[/yellow]"
            )
            console.print(
                "[dim]Showing local projects only. "
                "Run 'bm cloud login' or 'bm cloud api-key save <key>' if this is a credentials issue.[/dim]"
            )
        if cloud_workspace_error is not None:
            console.print(
                f"[yellow]Cloud workspace discovery failed: {literal(cloud_workspace_error)}[/yellow]"
            )
            console.print(
                "[dim]Showing cloud projects from the configured/default workspace only.[/dim]"
            )
        for failed_workspace, error in failed_cloud_workspaces:
            console.print(
                f"[yellow]Cloud project discovery failed for workspace "
                f"{literal(failed_workspace.name)}: {literal(error)}[/yellow]"
            )
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error listing projects: {literal(str(e))}[/red]")
        raise typer.Exit(1)


def command_hint(*parts: str) -> str:
    """Render a runnable command for display inside Rich markup.

    The single place CLI output builds a copy-pasteable command. Two things have
    to happen and neither is optional: `shell_command` quotes each argument so a
    value containing a space survives being pasted back, and `escape` keeps a
    value containing `[` from being read as Rich markup. Interpolating a command
    by hand skips both.
    """
    return escape(shell_command(*parts))


def _add_command_hint(name: str, local_sync_path: str | None, workspace: str | None) -> str:
    """Rebuild the `bm project add` invocation that recovers this cloud project.

    Printed as a remedy, so it has to be the command that actually re-runs the
    failed step -- including the flags whose absence would change what it does.
    The workspace is the *resolved* id rather than whatever the caller typed: it
    may have been auto-selected, and pinning it makes the retry land on the same
    workspace even if the default moves in between.
    """
    parts = ["bm", "project", "add", name, "--cloud"]
    if workspace:
        parts += ["--workspace", workspace]
    if local_sync_path:
        parts += ["--local-path", local_sync_path]
    return command_hint(*parts)


def _resolve_existing_project(
    name: str,
    *,
    local: bool,
    cloud: bool,
    workspace: str | None,
) -> ProjectResolveResponse | None:
    """Return the project if it already exists and is visible, else None.

    Asked as an explicit resolve rather than by matching the creation error's
    text: whether the project exists is a question only the server can answer,
    and its phrasing of a conflict is not a contract.
    """

    async def _resolve() -> ProjectResolveResponse:
        async with get_client(workspace=workspace) as client:
            return await ProjectClient(client).resolve_project(name)

    try:
        with force_routing(local=local, cloud=cloud):
            return run_with_cleanup(_resolve())
    except Exception as probe_error:
        # Trigger: the probe itself could not answer (404, auth, network).
        # Why: it exists only to decide whether adoption is safe, and a failed
        #   probe is not evidence that the project exists.
        # Outcome: report no match; the caller then surfaces the original
        #   creation error, so nothing is masked by this swallow.
        logger.debug(f"Existence probe for '{name}' failed: {probe_error}")
        return None


def _abort_after_project_created(
    name: str,
    *,
    step: str,
    remedy: str,
    error: Exception,
    retry_add_after_repair: bool = False,
) -> NoReturn:
    """Report a failure that happened after the project row became durable.

    The default contract states that the project was created and a blind re-run
    will refuse with "already exists". When ``retry_add_after_repair`` is true,
    the failed step prevented local registration, so repairing it makes re-running
    the command safe: the existing adoption path finishes registration instead of
    creating a second project. In either case, the remedy must fit the project's
    mode and repair the step that actually failed (#1440 review).

    The project is deliberately not rolled back: the row is the user's, and
    deleting it to tidy up an error message would discard what they asked for.
    """
    # A typer.Exit carries no message of its own -- the failing step already
    # printed one (the reindex pass does) -- so only the state and remedy are
    # missing. Anything else still needs its message shown.
    detail = "" if isinstance(error, typer.Exit) else f": {error}"
    console.print(
        f"[yellow]Project '{literal(name)}' was created, but {literal(step)} failed{literal(detail)}[/yellow]"
    )
    if retry_add_after_repair:
        console.print(f"Fix the failed step before re-running 'bm project add'. {remedy}")
    else:
        console.print(
            f"Do not re-run 'bm project add' — '{literal(name)}' already exists. {remedy}"
        )
    raise typer.Exit(1)


@project_app.command("add")
def add_project(
    name: str = typer.Argument(..., help="Name of the project"),
    path: str = typer.Argument(
        None, help="Path to the project directory (required for local mode)"
    ),
    local_path: str = typer.Option(
        None, "--local-path", help="Local sync path for cloud mode (optional)"
    ),
    workspace: str = typer.Option(
        None,
        "--workspace",
        help="Cloud workspace name, slug, type, or tenant_id (cloud mode only)",
    ),
    visibility: str = typer.Option(
        None,
        "--visibility",
        help="Cloud project visibility: workspace (everyone in the workspace) or shared (invite-only)",
    ),
    set_default: bool = typer.Option(False, "--default", help="Set as default project"),
    no_wait: bool = typer.Option(
        False,
        "--no-wait",
        help="Register the project without indexing it; reads stay empty until you index",
    ),
    local: bool = typer.Option(
        False, "--local", help="Force local API routing (ignore cloud mode)"
    ),
    cloud: bool = typer.Option(False, "--cloud", help="Force cloud API routing"),
) -> None:
    """Add a new project, indexing its existing files.

    A local project is indexed before this command returns, so its notes are
    searchable immediately. Pass --no-wait to skip that for a large directory
    you would rather index later.

    Use --local to force local routing when cloud mode is enabled.
    Use --cloud to force cloud routing when cloud mode is disabled.

    Cloud mode examples:\n
        bm project add research                           # No local sync\n
        bm project add research --local-path ~/docs       # With local sync\n
        bm project add research --cloud --visibility shared\n
        bm project add research --cloud --workspace my-team --visibility shared\n

    Local mode example:\n
        bm project add research ~/Documents/research
    """
    try:
        validate_routing_flags(local, cloud)
    except ValueError as e:
        console.print(f"[red]Error: {literal(e)}[/red]")
        raise typer.Exit(1)

    config = ConfigManager().config

    # Determine effective mode: default local, cloud only when explicitly requested.
    effective_cloud_mode = cloud and not local
    resolved_workspace_id: str | None = None

    # Resolve local sync path early (needed for both cloud and local mode)
    local_sync_path: str | None = None
    if local_path:
        local_sync_path = Path(os.path.abspath(os.path.expanduser(local_path))).as_posix()

    if effective_cloud_mode:
        _require_cloud_credentials(config)
        try:
            resolved_visibility = _normalize_project_visibility(visibility)
        except ValueError as e:
            console.print(f"[red]Error: {literal(e)}[/red]")
            raise typer.Exit(1)
        resolved_workspace_id = _resolve_workspace_id(config, workspace)
        # Cloud mode: path auto-generated from name, local sync is optional

        async def _add_project():
            async with get_client(workspace=resolved_workspace_id) as client:
                data = {
                    "name": name,
                    "path": generate_permalink(name),
                    "local_sync_path": local_sync_path,
                    "set_default": set_default,
                    "visibility": resolved_visibility,
                }
                return await ProjectClient(client).create_project(data)
    else:
        if workspace is not None:
            console.print("[red]Error: --workspace is only supported in cloud mode[/red]")
            raise typer.Exit(1)
        if visibility is not None:
            console.print("[red]Error: --visibility is only supported in cloud mode[/red]")
            raise typer.Exit(1)
        # Local mode: path is required
        if path is None:
            console.print("[red]Error: path argument is required in local mode[/red]")
            raise typer.Exit(1)

        # Resolve to absolute path
        resolved_path = Path(os.path.abspath(os.path.expanduser(path))).as_posix()

        async def _add_project():
            async with get_client() as client:
                data = {"name": name, "path": resolved_path, "set_default": set_default}
                return await ProjectClient(client).create_project(data)

    # --- Create the project, or adopt one that already exists remotely ---
    # Trigger: creation fails, and the project already exists where it was being
    #   created while this machine's config has no entry for it.
    # Why: that is precisely the state a failed `save_config` leaves behind, and
    #   every route out of it was closed -- `set-cloud` refuses a name absent from
    #   config, and re-running `add` refused because the remote project existed
    #   (#1440 review). Two rounds of picking a better remedy string could not fix
    #   that, because the problem was a state with no recovery, not the wording.
    # Outcome: re-running the command the user already ran finishes whatever did
    #   not complete, so any failure after remote creation but before the config
    #   write self-heals on a retry, including steps added later.
    try:
        with force_routing(local=local, cloud=cloud):
            result = run_with_cleanup(_add_project())
        console.print(f"[green]{literal(result.message)}[/green]")
    except Exception as create_error:
        # Only "remote exists, config missing" may proceed. A name already in
        # this machine's config is genuinely added, so a creation failure there
        # is a real conflict -- a local re-add under a different path, say --
        # and adopting would silently ignore the path the caller asked for.
        # Read from the snapshot taken before this command touched anything:
        # ConfigManager caches by file mtime, so a failed save leaves its
        # in-memory mutation visible to a later read within the same process.
        already_configured = name in config.projects
        existing = (
            None
            if already_configured
            else _resolve_existing_project(
                name, local=local, cloud=cloud, workspace=resolved_workspace_id
            )
        )
        if existing is None:
            console.print(f"[red]Error adding project: {literal(str(create_error))}[/red]")
            raise typer.Exit(1)
        console.print(
            f"[green]Project '{literal(name)}' already exists at {literal(existing.path)}; "
            f"adopting it into this machine's config.[/green]"
        )

    # --- Post-creation steps ---
    # Each step below runs after the project row is durable, so each carries its
    # own remedy: a fixed one sent cloud projects to `bm project index`, which the
    # local-only reindex path refuses outright and which could not have repaired a
    # config write or a mkdir anyway (#1440 review). Local and cloud steps are
    # mutually exclusive on `effective_cloud_mode`, so a local add can only ever
    # reach the indexing remedy.
    if not effective_cloud_mode:
        # Trigger: a local project was registered and the caller did not opt out.
        # Why: registration alone leaves every read surface reporting an empty
        #   project while the notes sit unindexed on disk, and there is no
        #   daemon-reachability probe to delegate to -- so index inline, the
        #   same way MCP's bm_project(command="create") already does (#1414).
        # Outcome: the project's existing notes are queryable when this returns.
        try:
            with force_routing(local=local, cloud=cloud):
                if no_wait:
                    # Trigger: the caller asked not to wait.
                    # Why: readiness comes from the status route, whose observer
                    #   walks the project and checksums every file -- and a brand
                    #   new project has no indexed stats to reuse, so every byte
                    #   is read. That is the scan `--no-wait` exists to avoid, on
                    #   exactly the large directories it exists for (#1440 review).
                    # Outcome: name the state from what registering already knows,
                    #   and leave measuring it to the command that is asked for it.
                    console.print(
                        "[yellow]Skipped indexing (--no-wait).[/yellow] "
                        f"Files on disk are not searchable yet — run "
                        f"[green]{command_hint('bm', 'project', 'index', name)}[/green], and check with "
                        f"[green]{command_hint('bm', 'status', '--project', name, '--json')}[/green]."
                    )
                else:
                    run_with_cleanup(index_project_and_report_readiness(name))
        except Exception as e:
            _abort_after_project_created(
                name,
                step="indexing it",
                remedy=(
                    f"Index it with [green]{command_hint('bm', 'project', 'index', name)}[/green], "
                    f"then check with "
                    f"[green]{command_hint('bm', 'status', '--project', name, '--json')}[/green]."
                ),
                error=e,
            )
    else:
        if local_sync_path:
            try:
                Path(local_sync_path).mkdir(parents=True, exist_ok=True)
            except Exception as e:
                # The routing entry must not name a path that failed validation:
                # config loading creates every absolute project path, so saving
                # this value would make every later CLI command fail (#1441).
                _abort_after_project_created(
                    name,
                    step=f"creating the local sync directory {local_sync_path}",
                    remedy=(
                        f"Create it yourself (or fix its permissions), then run this same "
                        f"command again: "
                        f"[green]{_add_command_hint(name, local_sync_path, resolved_workspace_id)}[/green]. "
                        f"It will adopt the project that already exists rather than create a "
                        f"second one."
                    ),
                    error=e,
                    retry_add_after_repair=True,
                )

        # Trigger: local config needs enough metadata to route future commands back to cloud.
        # Why: explicit workspace selection and local sync state should persist across CLI sessions.
        # Outcome: cloud-backed projects keep cloud mode, workspace_id, and optional local sync path.
        if local_sync_path or resolved_workspace_id:
            try:
                entry = config.projects.get(name)
                if entry:
                    entry.mode = ProjectMode.CLOUD
                    if local_sync_path:
                        entry.path = local_sync_path
                        entry.local_sync_path = local_sync_path
                    if resolved_workspace_id:
                        entry.workspace_id = resolved_workspace_id
                else:
                    # Project may not be in local config yet (cloud-only add)
                    config.projects[name] = ProjectEntry(
                        path=local_sync_path or "",
                        mode=ProjectMode.CLOUD,
                        local_sync_path=local_sync_path,
                        workspace_id=resolved_workspace_id,
                    )
                # `save_config` swallows write failures for its best-effort
                # callers and reports them by return value, so this has to look
                # rather than wait to be raised at (#1440 review).
                write_error = ConfigManager().save_config(config)
                if write_error is not None:
                    raise write_error
            except Exception as e:
                # The remote project exists; only this machine's routing entry is
                # missing. `set-cloud` cannot repair that — it refuses a name that
                # is absent from config, which is exactly this state — so the
                # remedy is to fix the write and re-run this command, which now
                # adopts the existing project instead of failing on it.
                _abort_after_project_created(
                    name,
                    step="saving its cloud routing to local config",
                    remedy=(
                        f"The project exists in the cloud — only this machine's config "
                        f"({ConfigManager().config_file}) could not be written. Fix that file "
                        f"(permissions or disk space), then run this same command again: "
                        f"[green]{_add_command_hint(name, local_sync_path, resolved_workspace_id)}[/green]. "
                        f"It will adopt the project that already exists rather than create a "
                        f"second one."
                    ),
                    error=e,
                )

        # Save local sync path to config if in cloud mode
        if local_sync_path:
            console.print(
                f"\n[green]Local sync path configured: {literal(local_sync_path)}[/green]"
            )
            # Push/pull is the transfer workflow on every workspace.
            # Mirrors `bm cloud sync-setup`.
            console.print("\nNext steps:")
            console.print(
                f"  1. Preview a pull: "
                f"{command_hint('bm', 'cloud', 'pull', '--name', name, '--dry-run')}"
            )
            console.print(
                f"  2. Fetch from cloud: {command_hint('bm', 'cloud', 'pull', '--name', name)}"
            )
            console.print(
                f"  3. Upload local changes: {command_hint('bm', 'cloud', 'push', '--name', name)}"
            )


@project_app.command("index")
def index_project_command(
    name: str = typer.Argument(..., help="Name of the project to index"),
) -> None:
    """Index a project's files so its notes become searchable.

    Builds the search index and, when semantic search is enabled, the embeddings.
    Same as `bm reindex --project <name>`.
    """
    # A named alias for `bm reindex --project <name>`, calling the same
    # implementation rather than restating its flags (#1414). It covers embeddings
    # as well as the search index: this is the command that `project add` and
    # `bm status` name as the remedy for a not-yet-indexed project, so it has to
    # reach the ready state they promise. A search-only pass would leave the
    # embeddings stage pending and the advice self-defeating.
    #
    # It deliberately does not pass `--full`. Running the advertised remedy
    # repeatedly has to converge, and `--full` cannot: it clears every project
    # vector before the sync runs, so a note with more chunks than one shard has
    # its completed shard deleted and is deferred again on every run, leaving the
    # embeddings stage permanently short of IDLE (#1440 review). The incremental
    # path is what the sharding design expects -- it skips chunks that are already
    # current and picks up where the last pass stopped, so repeated runs finish the
    # note. A never-indexed project still gets everything indexed, because change
    # detection sees every file as new. `bm reindex --full` remains available for
    # rebuilding derived state that is believed corrupt.
    #
    # `run_reindex_command` still drops embeddings with an explanation when
    # semantic search is disabled, exactly as a bare `bm reindex` does.
    run_reindex_command(embeddings=True, search=True, full=False, project=name)


@project_app.command("remove")
def remove_project(
    name: str = typer.Argument(..., help="Name of the project to remove"),
    delete_notes: bool = typer.Option(
        False,
        "--delete-notes",
        help=(
            "Delete a local project's files from disk. Cloud projects always delete "
            "their cloud files."
        ),
    ),
    delete_local_files: bool = typer.Option(
        False,
        "--delete-local-files",
        help="Cloud projects only: also delete the local sync directory on this machine",
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Delete a cloud project without a confirmation prompt"
    ),
    local: bool = typer.Option(
        False, "--local", help="Force local API routing (ignore cloud mode)"
    ),
    cloud: bool = typer.Option(False, "--cloud", help="Force cloud API routing"),
) -> None:
    """Remove a project.

    Removing a local project stops tracking it; its files stay on disk unless
    you pass --delete-notes.

    Removing a cloud project always deletes its files from cloud storage. They
    can be recovered only from a cloud snapshot (`bm cloud snapshot list`). You
    are asked to confirm first; pass --yes to skip the prompt in scripts. A
    local sync directory is kept unless you pass --delete-local-files.

    Use --local to force local routing when cloud mode is enabled.
    Use --cloud to force cloud routing when cloud mode is disabled.
    """
    try:
        validate_routing_flags(local, cloud)
    except ValueError as e:
        console.print(f"[red]Error: {literal(e)}[/red]")
        raise typer.Exit(1)

    # A display name and its permalink address the same entry, and the API
    # accepts either, so resolve the config key the same permalink-aware way.
    config_manager = ConfigManager()
    config = config_manager.config
    entry_name, _ = config_manager.get_project(name)
    entry = config.projects.get(entry_name) if entry_name else None
    route_name = entry_name or name

    # The delete is cloud-routed on an explicit --cloud, or when per-project
    # routing sends it there: a cloud-mode entry, or a name with no local entry
    # at all (get_client treats unknown projects as cloud-only). Local-artifact
    # cleanup and the file-deletion policy must follow the route the delete
    # actually takes, not just the flag.
    cloud_routed = not local and (cloud or config.get_project_mode(route_name) == ProjectMode.CLOUD)

    # Trigger: --delete-local-files on a delete that goes to the local API.
    # Why: the flag names the local copy of a cloud project; on a local project
    #   it would silently overlap --delete-notes, so the intent is unclear.
    # Outcome: fail before anything is deleted.
    if delete_local_files and not cloud_routed:
        console.print(
            "[red]Error: --delete-local-files applies only to cloud projects. "
            "Use --delete-notes to delete a local project's files.[/red]"
        )
        raise typer.Exit(1)

    local_path_config = None
    if cloud_routed and entry is not None and entry.local_sync_path:
        local_path_config = entry.local_sync_path

    # Trigger: the delete goes to the cloud.
    # Why: the cloud service always deletes a project's files on delete
    #   (basic-memory-cloud#2117); files kept under a deleted project were
    #   unreachable, so there is no "keep cloud files" option. The only way back
    #   is a snapshot restore, and the user should hear that before, not after.
    # Outcome: explain what will be deleted and what is kept, then require a
    #   yes unless --yes was passed. Declining exits without deleting anything.
    if cloud_routed:
        console.print(
            f"[yellow]Removing cloud project '{literal(name)}' permanently deletes all of its files "
            "in cloud storage. They can be recovered only from a cloud snapshot "
            "(`bm cloud snapshot list`).[/yellow]"
        )
        if local_path_config and delete_local_files:
            console.print(
                f"[yellow]The local sync directory {literal(local_path_config)} will also be "
                "deleted.[/yellow]"
            )
        elif local_path_config:
            console.print(f"The local sync directory {literal(local_path_config)} will be kept.")
        if not yes and not typer.confirm(f"Delete cloud project '{name}' and its cloud files?"):
            console.print("[yellow]Remove cancelled - nothing deleted[/yellow]")
            raise typer.Exit(0)

    # Local deletes keep the caller's choice; cloud deletes always ask the
    # service to delete files so the request matches what the server does.
    request_delete_notes = True if cloud_routed else delete_notes

    async def _remove_project():
        # Resolve workspace so cloud-only projects auto-route without --cloud
        ws = None
        if entry and entry.workspace_id:
            ws = entry.workspace_id
        elif config.default_workspace:
            ws = config.default_workspace

        async with get_client(project_name=route_name, workspace=ws) as client:
            project_client = ProjectClient(client)
            # Convert name to permalink for efficient resolution
            project_permalink = generate_permalink(name)
            target_project = await project_client.resolve_project(project_permalink)
            return await project_client.delete_project(
                target_project.external_id, delete_notes=request_delete_notes
            )

    try:
        # Remove project from cloud/API
        with force_routing(local=local, cloud=cloud):
            result = run_with_cleanup(_remove_project())
        console.print(f"[green]{literal(result.message)}[/green]")
        if cloud_routed:
            console.print(_cloud_file_delete_message(result.file_delete_status))

        # Trigger: the entry is a cloud-mode routing entry (written by
        # `project add --cloud` or `set-cloud`). An explicit --cloud alone is only
        # a routing override — a same-named local project keeps its entry.
        # Why: the local API removes its own config entry, but a cloud delete
        # never touches local config, so the routing stub outlived the project:
        # list-projects kept reporting it as a local project at "/", a second
        # `remove` routed to the cloud again and got "not found", and `add`
        # refused the name as taken (#1340).
        # Outcome: the stub goes with the project — persisted before the fallible
        # filesystem cleanups below, so a failed rmtree cannot leave the remote
        # project deleted and the stub alive. The default project is the one
        # entry config must keep, so it is only scrubbed of sync state and the
        # user is told how to retire it. An explicit --local hands the delete to
        # the local service, which removes the config entry itself.
        if (
            not local
            and entry is not None
            and entry_name is not None
            and entry.mode == ProjectMode.CLOUD
        ):
            if config.default_project == entry_name:
                entry.local_sync_path = None
                entry.bisync_initialized = False
                entry.last_sync = None
                console.print(
                    f"[yellow]'{literal(entry_name)}' is still the default project in local config. "
                    "Choose another with `bm project default <name> --local`, then run "
                    f"`{command_hint('bm', 'project', 'remove', entry_name, '--local')}` to drop this entry.[/yellow]"
                )
            else:
                del config.projects[entry_name]
            config_manager.save_config(config)

        # Trigger: a cloud project with a local sync directory.
        # Why: that directory is the user's own copy; deleting it is a separate
        #   decision from deleting the cloud files, so only --delete-local-files
        #   removes it.
        # Outcome: the directory is deleted or kept, and the output says which.
        if local_path_config:
            local_dir = Path(local_path_config)
            if delete_local_files and local_dir.exists():
                import shutil

                shutil.rmtree(local_dir)
                console.print(
                    f"[green]Removed local sync directory: {literal(local_path_config)}[/green]"
                )
            elif local_dir.exists():
                console.print(f"[yellow]Local files kept at {literal(local_path_config)}[/yellow]")

    except Exception as e:
        # str() of httpx transport errors is often empty (#1034) — never print a blank error.
        console.print(f"[red]Error removing project: {literal(str(e) or repr(e))}[/red]")
        raise typer.Exit(1)


def _cloud_file_delete_message(
    status: Literal["pending", "skipped", "complete", "failed"] | None,
) -> str:
    """Describe the cloud file deletion without overstating backend completion."""
    if status == "complete":
        return "[green]Cloud files deleted.[/green]"
    if status == "pending":
        return "[green]Cloud file deletion queued.[/green]"
    if status == "failed":
        return "[red]Cloud file deletion failed; some cloud files may remain.[/red]"
    if status == "skipped":
        return (
            "[yellow]The cloud service reported file deletion as skipped; "
            "cloud files may remain.[/yellow]"
        )
    return "[yellow]The cloud service did not report a file deletion status.[/yellow]"


@project_app.command("default")
def set_default_project(
    name: str = typer.Argument(..., help="Name of the project to set as CLI default"),
    local: bool = typer.Option(
        False, "--local", help="Force local API routing (required in cloud mode)"
    ),
) -> None:
    """Set the default project used as fallback when no project is specified.

    In cloud mode, use --local to modify the local configuration.
    """

    async def _set_default():
        # Resolve workspace so cloud-only projects auto-route without flags
        config = ConfigManager().config
        entry = config.projects.get(name)
        ws = None
        if entry and entry.workspace_id:
            ws = entry.workspace_id
        elif config.default_workspace:
            ws = config.default_workspace

        async with get_client(project_name=name, workspace=ws) as client:
            project_client = ProjectClient(client)
            # Convert name to permalink for efficient resolution
            project_permalink = generate_permalink(name)
            target_project = await project_client.resolve_project(project_permalink)
            return await project_client.set_default(target_project.external_id)

    try:
        with force_routing(local=local):
            result = run_with_cleanup(_set_default())
        console.print(f"[green]{literal(result.message)}[/green]")
    except Exception as e:
        console.print(f"[red]Error setting default project: {literal(str(e))}[/red]")
        raise typer.Exit(1)


@project_app.command("move")
def move_project(
    name: str = typer.Argument(..., help="Name of the project to move"),
    new_path: str = typer.Argument(..., help="New absolute path for the project"),
) -> None:
    """Move a local project to a new filesystem location.

    This command only applies to local projects — it updates the project's
    configured path in the local database.
    """
    # Resolve to absolute path
    resolved_path = Path(os.path.abspath(os.path.expanduser(new_path))).as_posix()

    async def _move_project():
        async with get_client() as client:
            project_client = ProjectClient(client)
            project_info = await project_client.resolve_project(name)
            return await project_client.update_project(
                project_info.external_id, {"path": resolved_path}
            )

    try:
        with force_routing(local=True):
            result = run_with_cleanup(_move_project())
        console.print(f"[green]{literal(result.message)}[/green]")

        # Show important file movement reminder
        console.print()  # Empty line for spacing
        console.print(
            Panel(
                "[bold red]IMPORTANT:[/bold red] Project configuration updated successfully.\n\n"
                "[yellow]You must manually move your project files from the old location to:[/yellow]\n"
                f"[cyan]{resolved_path}[/cyan]\n\n"
                "[dim]Basic Memory has only updated the configuration - your files remain in their original location.[/dim]",
                title="Manual File Movement Required",
                border_style="yellow",
                expand=False,
            )
        )

    except Exception as e:
        console.print(f"[red]Error moving project: {literal(str(e))}[/red]")
        raise typer.Exit(1)


async def _detach_local_project_row(app_config: BasicMemoryConfig, name: str) -> bool:
    """Drop the project's row from the local index DB.

    Trigger: `bm project set-cloud` is making a project cloud-only.
    Why: the local row is what causes `_merge_workspace_projects` to report
         `source: "local+cloud"` after the toggle (#680). Removing it
         forces the merged listing to honor the user's chosen mode.
    Outcome: returns True if a row was deleted, False if there was
         nothing to clean up. On-disk note files are not touched.
    """
    from basic_memory import db
    from basic_memory.repository import ProjectRepository

    _, session_maker = await db.get_or_create_db(
        db_path=app_config.database_path,
        db_type=db.DatabaseType.FILESYSTEM,
    )
    try:
        repo = ProjectRepository()
        async with db.scoped_session(session_maker) as session:
            existing = await repo.get_by_name(session, name)
            if existing is None:
                return False
            await repo.delete(session, existing.id)
            return True
    finally:
        # CLI-only: safe to tear down the global DB singleton here since
        # set-cloud/set-local never run inside a long-lived MCP/API server.
        await db.shutdown_db()


async def _attach_local_project_row(app_config: BasicMemoryConfig, name: str, path: str) -> None:
    """Ensure the project has a row in the local index DB at the given path.

    Trigger: `bm project set-local` is making a previously cloud-only
        project local again.
    Why: without a row in the local DB, every local-side tool (`list`,
        `info`, sync, indexing) would skip this project.
    Outcome: a row is created if missing, or its path is updated to match
        the new local home if it already exists. On-disk files are not
        touched — the caller is responsible for ensuring the directory
        exists.
    """
    from basic_memory import db
    from basic_memory.repository import ProjectRepository

    _, session_maker = await db.get_or_create_db(
        db_path=app_config.database_path,
        db_type=db.DatabaseType.FILESYSTEM,
    )
    try:
        repo = ProjectRepository()
        async with db.scoped_session(session_maker) as session:
            existing = await repo.get_by_name(session, name)
            if existing is None:
                await repo.create(
                    session,
                    {
                        "name": name,
                        "path": path,
                        "permalink": generate_permalink(name),
                        "is_active": True,
                    },
                )
                return
            if existing.path != path:
                await repo.update_path(session, existing.id, path)
    finally:
        # CLI-only: safe to tear down the global DB singleton here since
        # set-cloud/set-local never run inside a long-lived MCP/API server.
        await db.shutdown_db()


@project_app.command("set-cloud")
def set_cloud(
    name: str = typer.Argument(..., help="Name of the project to route through cloud"),
    workspace: str = typer.Option(
        None,
        "--workspace",
        help="Cloud workspace name, slug, type, or tenant_id to associate with this project",
    ),
) -> None:
    """Set a project to cloud mode (route through cloud API).

    Requires either an API key or an active OAuth session.

    Use --workspace to associate a specific workspace with this project.
    If omitted, uses the default workspace (if set) or auto-selects when
    only one workspace is available.

    This is a one-way cutover: the project's row in the local index DB is
    removed and the local path in config is cleared so the project's
    configured state is purely cloud. On-disk note files are preserved —
    the caller can keep, archive, or delete them as they see fit. To
    return to local mode use `bm project set-local <name> --local-path
    <path>`.

    Examples:
      bm project set-cloud research --workspace my-team
      bm project set-cloud research --workspace 11111111-...
      bm project set-cloud research   # uses default workspace
    """

    config_manager = ConfigManager()
    config = config_manager.config

    # Validate project exists in config
    if name not in config.projects:
        console.print(f"[red]Error: Project '{literal(name)}' not found in config[/red]")
        raise typer.Exit(1)

    # Validate credentials: API key or OAuth session
    has_api_key = bool(config.cloud_api_key)
    has_oauth = False
    if not has_api_key:
        auth = CLIAuth(client_id=config.cloud_client_id, authkit_domain=config.cloud_domain)
        has_oauth = auth.load_tokens() is not None

    if not has_api_key and not has_oauth:
        console.print("[red]Error: No cloud credentials found[/red]")
        console.print("[dim]Run 'bm cloud api-key save <key>' or 'bm cloud login' first[/dim]")
        raise typer.Exit(1)

    resolved_workspace_id = _resolve_workspace_id(config, workspace)

    # Drop the local DB row first so the user-visible state stays consistent
    # even if the config save below raises for some reason. Idempotent: a
    # second `set-cloud` simply finds no row and returns False.
    previous_path = config.projects[name].path
    detached = run_with_cleanup(_detach_local_project_row(config, name))

    config.set_project_mode(name, ProjectMode.CLOUD)
    if resolved_workspace_id:
        config.projects[name].workspace_id = resolved_workspace_id
    # Clear the local path and sync metadata: the source of truth for this
    # project is now the cloud. A leftover local_sync_path would read as a local
    # copy and let reconciliation recreate the row this cutover just dropped.
    config.projects[name].path = ""
    config.projects[name].local_sync_path = None
    config.projects[name].bisync_initialized = False
    config.projects[name].last_sync = None
    config_manager.save_config(config)

    console.print(f"[green]Project '{literal(name)}' set to cloud mode[/green]")
    if resolved_workspace_id:
        console.print(f"[dim]Workspace: {literal(resolved_workspace_id)}[/dim]")
    if detached and previous_path:
        console.print(
            f"[dim]Local index entry removed. Files at {literal(previous_path)} are preserved on disk.[/dim]"
        )
    console.print("[dim]MCP tools and CLI commands for this project will route through cloud[/dim]")


@project_app.command("set-local")
def set_local(
    name: str = typer.Argument(..., help="Name of the project to revert to local mode"),
    local_path: str = typer.Option(
        None,
        "--local-path",
        help=(
            "Local filesystem path for this project. Required unless the project "
            "was previously local and its prior path is still in config."
        ),
    ),
) -> None:
    """Revert a project to local mode (use in-process ASGI transport).

    Recreates the project's row in the local index DB and clears any
    associated cloud workspace. If the project was previously local and
    its prior path is still in config (e.g. an older version that didn't
    blank `path` on `set-cloud`), `--local-path` may be omitted and that
    path will be reused.

    Examples:
      bm project set-local research --local-path ~/Documents/research
      bm project set-local research                 # reuse prior path
    """
    config_manager = ConfigManager()
    config = config_manager.config

    # Validate project exists in config
    if name not in config.projects:
        console.print(f"[red]Error: Project '{literal(name)}' not found in config[/red]")
        raise typer.Exit(1)

    entry = config.projects[name]
    candidate = local_path or entry.path
    if not candidate:
        console.print(
            f"[red]Error: --local-path is required for '{literal(name)}' "
            "(no previous local path is recorded)[/red]"
        )
        raise typer.Exit(1)

    resolved_path = Path(os.path.abspath(os.path.expanduser(candidate))).as_posix()

    # Recreate the local DB row. Idempotent: if the row exists with the
    # same path it's a no-op; if it exists at a stale path the path is
    # updated. The directory itself is not auto-created — the user is
    # expected to know whether they want to start a fresh project tree
    # or point at an existing one.
    run_with_cleanup(_attach_local_project_row(config, name, resolved_path))

    config.set_project_mode(name, ProjectMode.LOCAL)
    config.projects[name].workspace_id = None
    config.projects[name].path = resolved_path
    config_manager.save_config(config)

    console.print(f"[green]Project '{literal(name)}' set to local mode[/green]")
    console.print(f"[dim]Path: {literal(resolved_path)}[/dim]")
    console.print("[dim]MCP tools and CLI commands for this project will use local transport[/dim]")


@project_app.command("ls")
def ls_project_command(
    name: str = typer.Option(..., "--name", help="Project name to list files from"),
    path: str = typer.Argument(None, help="Path within project (optional)"),
    local: bool = typer.Option(False, "--local", help="List files from local project instance"),
    cloud: bool = typer.Option(False, "--cloud", help="List files from cloud project instance"),
) -> None:
    """List files in a project.

    Examples:
      bm project ls --name research
      bm project ls --name research --local
      bm project ls --name research --cloud
      bm project ls --name research subfolder
    """
    try:
        validate_routing_flags(local, cloud)
    except ValueError as e:
        console.print(f"[red]Error: {literal(e)}[/red]")
        raise typer.Exit(1)

    # Determine routing: explicit flags take precedence, otherwise check project mode
    if cloud or local:
        use_cloud_route = cloud and not local
    else:
        config = ConfigManager().config
        project_mode = config.get_project_mode(name)
        use_cloud_route = project_mode == ProjectMode.CLOUD

    def _list_local_files(project_path: str, subpath: str | None = None) -> list[str]:
        project_root = Path(normalize_project_path(project_path)).expanduser().resolve()
        target_dir = project_root

        if subpath:
            requested = Path(subpath)
            if requested.is_absolute():
                raise ValueError("Path must be relative to the project root")
            target_dir = (project_root / requested).resolve()
            if not target_dir.is_relative_to(project_root):
                raise ValueError("Path must stay within the project root")

        if not target_dir.exists():
            raise ValueError(f"Path not found: {target_dir}")
        if not target_dir.is_dir():
            raise ValueError(f"Path is not a directory: {target_dir}")

        files: list[str] = []
        for file_path in sorted(target_dir.rglob("*")):
            if file_path.is_file():
                size = file_path.stat().st_size
                relative = file_path.relative_to(project_root).as_posix()
                files.append(f"{size:10d} {relative}")

        return files

    try:
        # Get project info
        async def _get_project():
            async with get_client() as client:
                projects_list = await ProjectClient(client).list_projects()
                for proj in projects_list.projects:
                    if generate_permalink(proj.name) == generate_permalink(name):
                        return proj
                return None

        if use_cloud_route:
            config = ConfigManager().config
            _require_cloud_credentials(config)

            tenant_info = run_with_cleanup(get_mount_info())
            bucket_name = tenant_info.bucket_name

            with force_routing(cloud=True):
                project_data = run_with_cleanup(_get_project())
            if not project_data:
                console.print(f"[red]Error: Project '{literal(name)}' not found[/red]")
                raise typer.Exit(1)

            sync_project = SyncProject(
                name=project_data.name,
                path=normalize_project_path(project_data.path),
            )
            files = project_ls(sync_project, bucket_name, path=path)
            target_label = "CLOUD"
        else:
            with force_routing(local=True):
                project_data = run_with_cleanup(_get_project())
            if not project_data:
                console.print(f"[red]Error: Project '{literal(name)}' not found[/red]")
                raise typer.Exit(1)

            # For cloud-mode projects accessed with --local, use local_sync_path
            # (the actual local directory) instead of project_data.path from the API
            local_dir = project_data.path
            if local:
                entry = ConfigManager().config.projects.get(name)
                if entry and entry.local_sync_path:
                    local_dir = entry.local_sync_path

            files = _list_local_files(local_dir, path)
            target_label = "LOCAL"

        if files:
            heading = f"\n[bold]Files in {name} ({target_label})"
            if path:
                heading += f"/{path}"
            heading += ":[/bold]"
            console.print(heading)
            for file in files:
                console.print(f"  {literal(file)}")
            console.print(f"\n[dim]Total: {len(files)} files[/dim]")
        else:
            prefix = f"[yellow]No files found in {name} ({target_label})"
            console.print(prefix + (f"/{path}" if path else "") + "[/yellow]")

    except Exception as e:
        console.print(f"[red]Error: {literal(e)}[/red]")
        raise typer.Exit(1)


@project_app.command("info")
def display_project_info(
    name: str = typer.Argument(..., help="Name of the project"),
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
    local: bool = typer.Option(
        False, "--local", help="Force local API routing (ignore cloud mode)"
    ),
    cloud: bool = typer.Option(False, "--cloud", help="Force cloud API routing"),
):
    """Display detailed information and statistics about the current project.

    Use --local to force local routing when cloud mode is enabled.
    Use --cloud to force cloud routing when cloud mode is disabled.
    """
    try:
        validate_routing_flags(local, cloud)
    except ValueError as e:
        console.print(f"[red]Error: {literal(e)}[/red]")
        raise typer.Exit(1)

    try:
        # Get project info
        with force_routing(local=local, cloud=cloud):
            info = run_with_cleanup(get_project_info(name))

        cloud_index_status: CloudProjectIndexStatus | None = None
        cloud_index_status_error: str | None = None
        if _uses_cloud_project_info_route(info.project_name, local=local, cloud=cloud):
            cloud_index_status, cloud_index_status_error = _load_cloud_project_index_status(
                info.project_name
            )

        if json_output:
            output = info.model_dump()
            output["cloud_index_status"] = (
                cloud_index_status.model_dump() if cloud_index_status is not None else None
            )
            output["cloud_index_status_error"] = cloud_index_status_error
            print(json.dumps(output, indent=2, default=str))
        else:
            # --- Left column: Knowledge Graph stats ---
            left = Table.grid(padding=(0, 2))
            left.add_column("metric", style="cyan")
            left.add_column("value", style="green", justify="right")

            left.add_row("[bold]Knowledge Graph[/bold]", "")
            left.add_row("Entities", str(info.statistics.total_entities))
            left.add_row("Observations", str(info.statistics.total_observations))
            left.add_row("Relations", str(info.statistics.total_relations))
            left.add_row("Unresolved", str(info.statistics.total_unresolved_relations))
            left.add_row("Isolated", str(info.statistics.isolated_entities))

            # --- Right column: Embeddings ---
            right = Table.grid(padding=(0, 2))
            right.add_column("property", style="cyan")
            right.add_column("value", style="green")

            right.add_row("[bold]Embeddings[/bold]", "")
            if info.embedding_status:
                es = info.embedding_status
                if es.vector_runtime_available:
                    right.add_row("[green]●[/green] Semantic Search", "Enabled")
                else:
                    right.add_row(
                        "[yellow]●[/yellow] Semantic Search",
                        "Unavailable: sqlite-vec cannot load here, keyword-only",
                    )
                if es.embedding_provider:
                    right.add_row("  Provider", es.embedding_provider)
                if es.embedding_model:
                    right.add_row("  Model", es.embedding_model)
                # Embedding coverage bar. Entities with no search row have no
                # vectors either, so they count against coverage (#1826).
                coverage_total = es.total_indexed_entities + es.entities_missing_search_rows
                # Without a vector runtime there is no coverage to show; the
                # search-index gap is reported in the status line instead.
                if es.vector_runtime_available and coverage_total > 0:
                    coverage_bar = make_bar(
                        es.total_entities_with_chunks,
                        coverage_total,
                        width=20,
                    )
                    count_text = Text(
                        f" {es.total_entities_with_chunks}/{coverage_total}",
                        style="green",
                    )
                    bar_with_count = Text.assemble("  Indexed  ", coverage_bar, count_text)
                    right.add_row(bar_with_count, "")
                right.add_row("  Chunks", str(es.total_chunks))
                if es.reindex_recommended:
                    right.add_row(
                        "[yellow]●[/yellow] Status",
                        "[yellow]Reindex recommended[/yellow]",
                    )
                    if es.reindex_reason:
                        right.add_row("  Reason", f"[yellow]{es.reindex_reason}[/yellow]")
                else:
                    right.add_row("[green]●[/green] Status", "[green]Up to date[/green]")

            # --- Compose two-column layout (content-sized, NOT Layout) ---
            columns = Table.grid(padding=(0, 4), expand=False)
            columns.add_row(left, right)

            cloud_section = _build_cloud_index_status_section(
                cloud_index_status, cloud_index_status_error
            )

            # --- Note Types bar chart (top 5 by count) ---
            bars_section = None
            if info.statistics.note_types:
                sorted_types = sorted(
                    info.statistics.note_types.items(), key=lambda x: x[1], reverse=True
                )
                top_types = sorted_types[:5]
                max_count = top_types[0][1] if top_types else 1

                bars = Table.grid(padding=(0, 2), expand=False)
                bars.add_column("type", style="cyan", width=16, justify="right")
                bars.add_column("bar")
                bars.add_column("count", style="green", justify="right")

                for note_type, count in top_types:
                    bars.add_row(note_type, make_bar(count, max_count), str(count))

                remaining = len(sorted_types) - len(top_types)
                bars_section = Group(
                    "[bold]Note Types[/bold]",
                    bars,
                    f"[dim]+{remaining} more types[/dim]" if remaining > 0 else "",
                )

            # --- Footer ---
            current_time = (
                datetime.fromisoformat(str(info.system.timestamp))
                if isinstance(info.system.timestamp, str)
                else info.system.timestamp
            )
            footer = (
                f"[dim]{format_path(info.project_path)}  "
                f"default: {info.default_project}  "
                f"{current_time.strftime('%Y-%m-%d %H:%M')}[/dim]"
            )

            # --- Assemble dashboard ---
            parts: list[Table | Group | str] = [columns, ""]
            if cloud_section is not None:
                parts.extend([cloud_section, ""])
            if bars_section:
                parts.extend([bars_section, ""])
            parts.append(footer)
            body = Group(*parts)

            console.print(
                Panel(
                    body,
                    title=f"[bold]{info.project_name}[/bold]",
                    subtitle=f"Basic Memory {info.system.version}",
                    expand=False,
                )
            )

    except typer.Exit:
        raise
    except Exception as e:  # pragma: no cover
        typer.echo(f"Error getting project info: {e}", err=True)
        raise typer.Exit(1)
