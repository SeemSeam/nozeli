"""utility functions for commands"""

import asyncio
from typing import Optional, TypeVar, Coroutine, Any

import typer

from rich.console import Console
from rich.markup import escape

from basic_memory.config import ConfigManager
from basic_memory.mcp.async_client import get_client
from basic_memory.mcp.clients import ProjectClient
from basic_memory.mcp.project_context import get_active_project
from basic_memory.utils import shell_command
from basic_memory.cli.markup import literal

console = Console()

T = TypeVar("T")


def run_with_cleanup(coro: Coroutine[Any, Any, T]) -> T:
    """Run an async coroutine with proper database cleanup.

    This helper ensures database connections are cleaned up before the
    event loop closes, preventing process hangs in CLI commands.

    Args:
        coro: The coroutine to run

    Returns:
        The result of the coroutine
    """
    # Deferred: basic_memory.db pulls SQLAlchemy + Alembic, which must not load
    # at CLI import time — only when a command actually runs (#886).
    from basic_memory import db
    from basic_memory.index.note_content_materialization import drain_pending_materializations
    from basic_memory.index.local_schedulers import drain_background_tasks

    async def _with_cleanup() -> T:
        try:
            return await coro
        finally:
            # Drain queued source-of-truth file writes before the loop closes:
            # local writes accept and materialize off the request path, so a
            # one-shot client would otherwise exit before the markdown file is
            # written (the API already reported the note accepted).
            await drain_pending_materializations()
            # Then the follow-up work those writes scheduled (vector sync,
            # relation resolution): cancelling it at loop close would leave
            # semantic search and inbound wikilinks stale until a later reindex.
            await drain_background_tasks()
            await db.shutdown_db()

    return asyncio.run(_with_cleanup())


def project_or_default(project: str | None) -> str:
    """The --project value, or the configured default project for a command that needs one.

    The bm_* tools take a required project. A person at a shell has a default project
    in config, and every other `bm` command already uses it. The value passes through
    unchanged, so 'workspace/project' and project ids route the way the tools route them.
    """
    if project is not None:
        return project
    default_project = ConfigManager().config.default_project
    # Trigger: no --project and no default project in config.
    # Why: the bm_* tools have no project fallback of their own in 1.0.
    # Outcome: a clear error instead of a tool call with no project.
    if default_project is None:
        typer.echo("Error: no default project is set; pass --project.", err=True)
        raise typer.Exit(1)
    return default_project


async def run_project_index(
    project: Optional[str] = None,
    force_full: bool = False,
    run_in_background: bool = True,
):
    """Run project indexing via API endpoint.

    Args:
        project: Optional project name
        force_full: If True, force a full scan bypassing watermark optimization
        run_in_background: If True, return immediately; if False, wait for completion
    """
    # Deferred: ToolError lives in FastMCP's runtime, which must not load at CLI startup (#886).
    from fastmcp.exceptions import ToolError

    # Resolve default project so get_client() can route per-project
    project = project or ConfigManager().default_project

    try:
        async with get_client(project_name=project) as client:
            project_item = await get_active_project(client, project, None)
            project_client = ProjectClient(client)
            data = await project_client.index(
                project_item.external_id,
                force_full=force_full,
                run_in_background=run_in_background,
            )
            # Background mode returns {"message": "..."}, foreground returns project-index counts.
            if "message" in data:
                console.print(f"[green]{literal(data['message'])}[/green]")
            else:
                total_files = data.get("total_files", 0)
                enqueued_files = data.get("enqueued_files", 0)
                enqueued_batches = data.get("enqueued_batches", 0)
                deleted_files = data.get("deleted_files", 0)
                console.print(
                    f"[green]Indexed {enqueued_files}/{total_files} files[/green] "
                    f"(batches: {enqueued_batches}, deleted orphans: {deleted_files})"
                )
    except (ToolError, ValueError) as e:
        console.print(f"[red]Index failed: {literal(e)}[/red]")
        raise typer.Exit(1)


async def report_project_readiness(project: str) -> None:
    """Print the honest one-line index state for a project.

    Silent emptiness was the original failure (#1414): an agent read a project
    that looked finished and concluded it held nothing. A read that cannot be
    trusted has to say so, so this prints the state rather than nothing. The
    wording comes from `ProjectIndexReadiness.describe`, the same method
    `bm status` renders, so the two cannot drift.
    """
    # Deferred: ToolError lives in FastMCP's runtime, which must not load at CLI startup (#886).
    from fastmcp.exceptions import ToolError

    try:
        async with get_client(project_name=project) as client:
            project_item = await get_active_project(client, project, None)
            status = await ProjectClient(client).get_status(project_item.external_id)
    except (ToolError, ValueError) as e:
        # Trigger: readiness could not be read (project vanished, routing error).
        # Why: this is a reporting courtesy after work that already succeeded.
        # Outcome: say so and leave the caller's exit status alone.
        console.print(f"[yellow]Could not read index status: {literal(e)}[/yellow]")
        return
    # This path only runs after a local index pass, so the local command is the
    # one that can advance it.
    summary = escape(
        status.readiness.describe(
            project_item.name,
            index_command=shell_command("bm", "project", "index", project_item.name),
        )
    )
    console.print(f"[dim]{escape(project_item.name)}: {summary}[/dim]")


async def get_project_info(project: str):
    """Get project information via API endpoint."""
    # Deferred: ToolError lives in FastMCP's runtime, which must not load at CLI startup (#886).
    from fastmcp.exceptions import ToolError

    try:
        async with get_client(project_name=project) as client:
            project_item = await get_active_project(client, project, None)
            return await ProjectClient(client).get_info(project_item.external_id)
    except (ToolError, ValueError) as e:
        error_text = str(e)
        if "internal proxy error" in error_text.lower() and "not found in configuration" in (
            error_text.lower()
        ):
            console.print(
                "[red]Project info failed: cloud returned an internal configuration error for "
                "this project.[/red]"
            )
            console.print(
                "[yellow]This is a cloud backend issue for detailed info lookups. "
                "Use `bm project list --cloud` for project metadata until the service is updated."
                "[/yellow]"
            )
        else:
            console.print(f"[red]Project info failed: {literal(e)}[/red]")
        raise typer.Exit(1)


def run_schema_tool(call: Coroutine[Any, Any, Any]) -> Any:
    """Run a schema tool; nothing to report keeps the CLI's {"error": message} result.

    The MCP tools refuse "no schemas yet" and "no notes of this type" as NOT_FOUND.
    For the CLI that is not a failure: the command prints the message and exits 0.
    """
    # Deferred: refusals imports fastmcp, which must not load at CLI startup (#886).
    from basic_memory.mcp.refusals import Refusal

    try:
        return run_with_cleanup(call)
    except Refusal as refused:
        if refused.code != "NOT_FOUND":
            raise
        return {"error": refused.message}
