"""One-shot native PDF extraction process used by the async adapter.

Runs as ``python -m basic_memory.document_ingestion.pdf_inspector_worker`` with
PDF bytes on stdin and one validated JSON ``PdfInspectorOutput`` on stdout.
Resource limits are applied before any source bytes are read so a malformed
PDF cannot exhaust the parent process.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import sys

import pdf_inspector

from basic_memory.document_ingestion.pdf_inspector import (
    PDF_INSPECTOR_ENGINE,
    PdfInspectorOutput,
    PdfInspectorPdfType,
)
from basic_memory.schemas.document_page_map import DocumentPageMapV1, DocumentPageRangeV1
from basic_memory.document_ingestion.worker_limits import apply_cpu_limit, apply_memory_limit


def _normalized_pages(pages: list[int], *, page_count: int) -> tuple[int, ...]:
    """Validate pdf-inspector's document-level, one-indexed diagnostics."""
    unique_pages = tuple(sorted(set(pages)))
    if any(page < 1 or page > page_count for page in unique_pages):
        raise ValueError("pdf-inspector returned a diagnostic page outside the document")
    return unique_pages


def inspect_pdf_bytes(
    pdf_bytes: bytes,
    *,
    max_pages: int,
    max_output_bytes: int,
) -> PdfInspectorOutput:
    """Run classification and extraction in the isolated child process."""
    # The installed library version is part of the deterministic run identity:
    # upgrading pdf-inspector yields a new ingestion run rather than silently
    # rewriting an existing document's provenance.
    engine_version = importlib.metadata.version("pdf-inspector")

    classification = pdf_inspector.classify_pdf_bytes(pdf_bytes)
    if classification.page_count > max_pages:
        raise ValueError("PDF exceeds the configured extraction page limit")

    result = pdf_inspector.process_pdf_bytes(pdf_bytes)
    if result.page_count != classification.page_count:
        raise RuntimeError("pdf-inspector classification and extraction page counts differ")

    page_result = pdf_inspector.extract_pages_markdown_bytes(pdf_bytes)
    # Page markers and OCR provenance are keyed by page index, so a repeated,
    # skipped, or reordered entry would mislabel canonical Markdown even when
    # the entry count is right. Require exactly 0..page_count-1 in order.
    page_indexes = [page.page for page in page_result.pages]
    if page_indexes != list(range(result.page_count)):
        raise RuntimeError("pdf-inspector page entries do not cover 0..page_count-1 exactly")

    markdown_parts: list[str] = []
    for page in page_result.pages:
        page_number = page.page + 1
        if page.needs_ocr:
            markdown_parts.append(f"<!-- Page {page_number}: OCR required -->")
            continue
        markdown_parts.append(f"<!-- Page {page_number} -->\n\n{page.markdown.strip()}")
    markdown = "\n\n".join(markdown_parts).strip()
    # Canonical note assembly normalizes line endings and adds one final newline.
    # Record offsets against those stored body characters, not native bytes or
    # frontmatter. Separators belong to the preceding page; OCR markers retain
    # their physical page even when no text could be extracted.
    page_ranges: list[DocumentPageRangeV1] = []
    body_parts: list[str] = []
    offset = 0
    for index, part in enumerate(markdown_parts):
        normalized = part.replace("\r\n", "\n").replace("\r", "\n")
        normalized = (
            normalized + "\n\n" if index < len(markdown_parts) - 1 else normalized.rstrip() + "\n"
        )
        body_parts.append(normalized)
        page_ranges.append(
            DocumentPageRangeV1(page=index + 1, start=offset, end=offset + len(normalized))
        )
        offset += len(normalized)
    canonical_body = "".join(body_parts)
    page_map = DocumentPageMapV1(
        body_checksum="sha256:" + hashlib.sha256(canonical_body.encode("utf-8")).hexdigest(),
        body_length=len(canonical_body),
        pages=tuple(page_ranges),
    )
    if len(markdown.encode("utf-8")) > max_output_bytes:
        raise ValueError("PDF extraction exceeds the configured output byte limit")

    pages_needing_ocr = _normalized_pages(
        page_result.pages_needing_ocr,
        page_count=result.page_count,
    )
    flagged_pages = tuple(page.page + 1 for page in page_result.pages if page.needs_ocr)
    if flagged_pages != pages_needing_ocr:
        raise RuntimeError(
            "pdf-inspector per-page OCR flags disagree with document-level pages_needing_ocr"
        )
    return PdfInspectorOutput(
        engine=PDF_INSPECTOR_ENGINE,
        engine_version=engine_version,
        pdf_type=PdfInspectorPdfType(result.pdf_type),
        markdown=markdown,
        page_map=page_map,
        title=result.title,
        page_count=result.page_count,
        extracted_page_count=sum(not page.needs_ocr for page in page_result.pages),
        pages_needing_ocr=pages_needing_ocr,
        confidence=result.confidence,
        processing_time_ms=result.processing_time_ms,
        is_complex_layout=page_result.is_complex,
        pages_with_tables=_normalized_pages(
            page_result.pages_with_tables,
            page_count=result.page_count,
        ),
        pages_with_columns=_normalized_pages(
            page_result.pages_with_columns,
            page_count=result.page_count,
        ),
        has_encoding_issues=result.has_encoding_issues,
    )


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-pages", type=int, required=True)
    parser.add_argument("--max-output-bytes", type=int, required=True)
    parser.add_argument("--max-memory-bytes", type=int, required=True)
    parser.add_argument("--cpu-seconds", type=int, required=True)
    return parser.parse_args()


def main() -> None:
    """Read PDF bytes from stdin and emit one validated JSON result to stdout."""
    args = _parse_args()
    apply_memory_limit(args.max_memory_bytes)
    apply_cpu_limit(args.cpu_seconds)
    result = inspect_pdf_bytes(
        sys.stdin.buffer.read(),
        max_pages=args.max_pages,
        max_output_bytes=args.max_output_bytes,
    )
    payload = result.model_dump_json()
    # inspect_pdf_bytes bounds the Markdown body; metadata such as the PDF title
    # is untrusted too, so bound the whole envelope before it crosses the pipe.
    if len(payload.encode("utf-8")) > args.max_output_bytes:
        raise ValueError("PDF extraction result exceeds the configured output byte limit")
    sys.stdout.write(payload)


if __name__ == "__main__":
    main()
