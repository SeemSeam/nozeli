"""Service for file operations with checksum tracking."""

import asyncio
import hashlib
import os

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path, PurePath
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple, Union

import aiofiles

import yaml

import logfire
from basic_memory import file_utils

if TYPE_CHECKING:  # pragma: no cover
    from basic_memory.config import BasicMemoryConfig
from basic_memory.file_types import file_content_type
from basic_memory.file_utils import FileError, FileMetadata, ParseError
from basic_memory.markdown.markdown_processor import MarkdownProcessor
from basic_memory.models import Entity as EntityModel
from basic_memory.runtime.storage import RUNTIME_MARKDOWN_CONTENT_TYPE
from basic_memory.schemas import Entity as EntitySchema
from basic_memory.services.exceptions import FileOperationError
from basic_memory.utils import FilePath, resolve_path_within_root, validate_project_path
from basic_memory.yaml_policy import SimpleSafeDumper
from loguru import logger


@dataclass(frozen=True, slots=True)
class FrontmatterUpdateResult:
    """Exact persisted UTF-8 content and checksum from a frontmatter rewrite."""

    checksum: str
    content: str


@dataclass(frozen=True, slots=True)
class StoredFile:
    """File bytes and the checksum storage reports for exactly those bytes.

    Change detection compares indexed checksums against what storage reports, so the
    checksum is in storage's domain: SHA-256 of the bytes on a local filesystem, the
    object ETag on S3. Indexing must record the same domain or a file it already knows
    reads as changed (basic-memory-cloud#2350).
    """

    content: bytes
    checksum: str


def _directory_holds_a_file(directory: Path) -> bool:
    """Return whether a directory holds a file at any depth, stopping at the first."""
    return directory.is_dir() and any(entry.is_file() for entry in directory.rglob("*"))


class FileService:
    """Service for handling file operations with concurrency control.

    All paths are handled as Path objects internally. Strings are converted to
    Path objects when passed in. Relative paths are assumed to be relative to
    base_path.

    Features:
    - True async I/O with aiofiles (non-blocking)
    - Built-in concurrency limits (semaphore)
    - Consistent file writing with checksums
    - Frontmatter management
    - Atomic operations
    - Error handling
    """

    def __init__(
        self,
        base_path: Path,
        markdown_processor: Optional[MarkdownProcessor] = None,
        max_concurrent_files: int = 10,
        app_config: Optional["BasicMemoryConfig"] = None,
        *,
        local_filesystem: bool = True,
    ):
        # Object-store subclasses use a logical prefix, never a host directory.
        self.base_path = base_path.resolve() if local_filesystem else base_path
        self.local_project_path = self.base_path if local_filesystem else None
        self.markdown_processor = markdown_processor
        self.app_config = app_config
        # Semaphore to limit concurrent file operations
        # Prevents OOM on large projects by processing files in batches
        self._file_semaphore = asyncio.Semaphore(max_concurrent_files)

    def get_entity_path(self, entity: Union[EntityModel, EntitySchema]) -> Path:
        """Generate absolute filesystem path for entity.

        Args:
            entity: Entity model or schema with file_path attribute

        Returns:
            Absolute Path to the entity file
        """
        return self.base_path / entity.file_path

    def require_project_path(self, path: FilePath) -> None:
        """Require a project path, allowing absolute spellings within a local root.

        General directory creation also serves project setup, so containment is
        enforced explicitly at project-scoped import, materialization, and move sinks.
        Object storage accepts only relative keys and never resolves host symlinks.
        """
        relative = Path(path)
        if self.local_project_path is not None and relative.is_absolute():
            try:
                relative = resolve_path_within_root(relative, self.local_project_path).relative_to(
                    self.local_project_path
                )
            except ValueError:
                raise FileOperationError(f"Path '{path}' is outside the project") from None
        # Native POSIX storage treats colons literally; remote keys keep the
        # portable drive restriction and never use the host's path semantics.
        if not validate_project_path(
            relative.as_posix(),
            self.local_project_path,
            allow_literal_tilde=True,
            allow_literal_colon=self.local_project_path is not None and os.name != "nt",
        ):
            raise FileOperationError(f"Path '{path}' is outside the project")

    async def read_entity_content(self, entity: EntityModel) -> str:
        """Get entity's content without frontmatter or structured sections.

        Used to index for search. Returns raw content without frontmatter,
        observations, or relations.

        Args:
            entity: Entity to read content for

        Returns:
            Raw content string without metadata sections
        """
        logger.debug(f"Reading entity content, entity_id={entity.id}, permalink={entity.permalink}")

        if self.markdown_processor is None:
            raise ValueError("markdown_processor is required for read_entity_content")

        file_path = self.get_entity_path(entity)
        markdown = await self.markdown_processor.read_file(file_path)
        return markdown.content or ""

    async def delete_entity_file(self, entity: EntityModel) -> None:
        """Delete entity file from filesystem.

        Args:
            entity: Entity model whose file should be deleted

        Raises:
            FileOperationError: If deletion fails
        """
        path = self.get_entity_path(entity)
        await self.delete_file(path)

    async def exists(self, path: FilePath) -> bool:
        """Check if file exists at the provided path.

        If path is relative, it is assumed to be relative to base_path.

        Args:
            path: Path to check (Path or string)

        Returns:
            True if file exists, False otherwise

        Raises:
            FileOperationError: If check fails
        """
        try:
            # Convert string to Path if needed
            path_obj = self.base_path / path if isinstance(path, str) else path
            logger.debug(f"Checking file existence: path={path_obj}")
            if path_obj.is_absolute():
                return path_obj.exists()
            else:
                return (self.base_path / path_obj).exists()
        except Exception as e:
            logger.error("Failed to check file existence", path=str(path), error=str(e))
            raise FileOperationError(f"Failed to check file existence: {e}")

    async def directory_has_files(self, path: FilePath) -> bool:
        """Return whether a project directory holds at least one file, at any depth.

        Storage is the canonical record of which folders exist; the index can lag
        files written directly to disk. A directory with no files reads as absent,
        which is also the only answer object storage can give, where folders exist
        only as key prefixes.

        Raises:
            FileOperationError: the path resolves outside the project. Callers check
                the boundary first; this keeps the walk from ever becoming a probe of
                other directories on the server.
        """
        if not validate_project_path(str(path), self.base_path):
            raise FileOperationError(f"Directory '{path}' is outside the project")
        # The walk stops at the first file, but a deep tree of empty folders still
        # costs a scan, so it runs off the event loop.
        return await asyncio.to_thread(_directory_holds_a_file, self.base_path / path)

    def paths_share_storage_target(self, left: FilePath, right: FilePath) -> bool:
        """Return whether two project paths resolve to the same physical file.

        Distinguishes a genuine rename from a case-only rename on a
        case-insensitive filesystem (APFS/NTFS), where ``Notes/Foo.md`` and
        ``notes/foo.md`` are the same inode. Returns False when either path is
        absent (nothing shared to protect) or the check errors.
        """
        left_abs = self.base_path / left if isinstance(left, str) else left
        right_abs = self.base_path / right if isinstance(right, str) else right
        if not left_abs.exists() or not right_abs.exists():
            return False
        try:
            return left_abs.samefile(right_abs)
        except OSError:
            return False

    async def ensure_directory(self, path: FilePath) -> None:
        """Ensure directory exists, creating if necessary.

        Uses semaphore to control concurrency for directory creation operations.

        Args:
            path: Directory path to ensure (Path or string)

        Raises:
            FileOperationError: If directory creation fails
        """
        try:
            # Convert string to Path if needed
            path_obj = self.base_path / path if isinstance(path, str) else path
            full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj

            # Use semaphore for concurrency control
            async with self._file_semaphore:
                # Run blocking mkdir in thread pool
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None, lambda: full_path.mkdir(parents=True, exist_ok=True)
                )
        except Exception as e:  # pragma: no cover
            logger.error("Failed to create directory", path=str(path), error=str(e))
            raise FileOperationError(f"Failed to create directory {path}: {e}")

    async def write_file(self, path: FilePath, content: str) -> str:
        """Write content to file and return checksum.

        Handles both absolute and relative paths. Relative paths are resolved
        against base_path.

        If format_on_save is enabled in config, runs the configured formatter
        after writing and returns the checksum of the formatted content.

        Args:
            path: Where to write (Path or string)
            content: Content to write

        Returns:
            Checksum of written content (or formatted content if formatting enabled)

        Raises:
            FileOperationError: If write fails
        """
        # Convert string to Path if needed
        path_obj = self.base_path / path if isinstance(path, str) else path
        full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj

        try:
            with logfire.span(
                "file_service.write",
                domain="file_service",
                action="write",
                phase="write",
            ):
                await self.ensure_directory(full_path.parent)

                logger.debug(
                    "Writing file: "
                    f"path={path_obj}, "
                    f"content_length={len(content)}, "
                    f"is_markdown={full_path.suffix.lower() == '.md'}"
                )

                await file_utils.write_file_atomic(full_path, content)

                if self.app_config:
                    formatted_content = await file_utils.format_file(
                        full_path, self.app_config, is_markdown=self.is_markdown(path)
                    )
                    if formatted_content is not None:
                        pass  # pragma: no cover

                # Trigger: formatters and platform-specific text writers can change the
                # persisted bytes even when the logical content string is the same.
                # Why: sync and move detection compare against on-disk checksums, not
                #      the pre-write Python string.
                # Outcome: return the checksum of the actual stored file so callers do
                #          not record a hash that immediately disagrees with the file.
                checksum = await self.compute_checksum(full_path)
                logger.debug(f"File write completed path={full_path}, {checksum=}")
                return checksum

        except Exception as e:
            logger.exception("File write error", path=str(full_path), error=str(e))
            raise FileOperationError(f"Failed to write file: {e}")

    async def read_file_content(self, path: FilePath) -> str:
        """Read file content using true async I/O with aiofiles.

        Handles both absolute and relative paths. Relative paths are resolved
        against base_path.

        Args:
            path: Path to read (Path or string)

        Returns:
            File content as string

        Raises:
            FileOperationError: If read fails
        """
        # Convert string to Path if needed
        path_obj = self.base_path / path if isinstance(path, str) else path
        full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj

        try:
            logger.debug("Reading file content", operation="read_file_content", path=str(full_path))
            async with aiofiles.open(full_path, mode="r", encoding="utf-8") as f:
                content = await f.read()

            logger.debug(
                "File read completed",
                path=str(full_path),
                content_length=len(content),
            )
            return content

        except FileNotFoundError:
            # Preserve FileNotFoundError so callers (e.g. sync) can treat it as deletion.
            logger.warning("File not found", operation="read_file_content", path=str(full_path))
            raise
        except Exception as e:
            if isinstance(e, FileNotFoundError):
                logger.warning("File not found", operation="read_file", path=str(full_path))
                raise
            logger.exception("File read error", path=str(full_path), error=str(e))
            raise FileOperationError(f"Failed to read file: {e}")

    async def read_file_bytes(self, path: FilePath) -> bytes:
        """Read file content as bytes using true async I/O with aiofiles.

        This method reads files in binary mode, suitable for non-text files
        like images, PDFs, etc. For cloud compatibility with S3FileService.

        Args:
            path: Path to read (Path or string)

        Returns:
            File content as bytes

        Raises:
            FileOperationError: If read fails
        """
        # Convert string to Path if needed
        path_obj = self.base_path / path if isinstance(path, str) else path
        full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj

        try:
            logger.debug("Reading file bytes", operation="read_file_bytes", path=str(full_path))
            async with aiofiles.open(full_path, mode="rb") as f:
                content = await f.read()

            logger.debug(
                "File read completed",
                path=str(full_path),
                content_length=len(content),
            )
            return content

        except Exception as e:
            logger.exception("File read error", path=str(full_path), error=str(e))
            raise FileOperationError(f"Failed to read file: {e}") from e

    async def read_stored_file(self, path: FilePath) -> StoredFile:
        """Read file bytes with their storage checksum, the SHA-256 of the bytes locally."""
        content = await self.read_file_bytes(path)
        return StoredFile(content=content, checksum=await file_utils.compute_checksum(content))

    async def read_file(self, path: FilePath) -> Tuple[str, str]:
        """Read file and compute checksum using true async I/O.

        Uses aiofiles for non-blocking file reads.

        Handles both absolute and relative paths. Relative paths are resolved
        against base_path.

        Args:
            path: Path to read (Path or string)

        Returns:
            Tuple of (content, checksum)

        Raises:
            FileOperationError: If read fails
        """
        # Convert string to Path if needed
        path_obj = self.base_path / path if isinstance(path, str) else path
        full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj

        try:
            with logfire.span(
                "file_service.read",
                domain="file_service",
                action="read",
                phase="read",
            ):
                logger.debug("Reading file", operation="read_file", path=str(full_path))

                async with aiofiles.open(full_path, mode="r", encoding="utf-8") as f:
                    content = await f.read()

                # Trigger: text-mode reads normalize line endings on Windows, so the
                #          decoded string can differ from the bytes we just wrote.
                # Why: write_file/update_frontmatter now return the checksum of the
                #      persisted file, and read_file should report the same authority.
                # Outcome: callers get human-readable content plus the checksum for the
                #          exact bytes stored on disk.
                checksum = await self.compute_checksum(full_path)

                logger.debug(
                    "File read completed",
                    path=str(full_path),
                    checksum=checksum,
                    content_length=len(content),
                )
                return content, checksum

        except FileNotFoundError as e:
            logger.warning("File not found", operation="read_file", path=str(full_path))
            raise FileOperationError(f"Failed to read file: {e}") from e
        except Exception as e:
            logger.exception("File read error", path=str(full_path), error=str(e))
            raise FileOperationError(f"Failed to read file: {e}")

    async def delete_file(self, path: FilePath) -> None:
        """Delete file if it exists.

        Handles both absolute and relative paths. Relative paths are resolved
        against base_path.

        Args:
            path: Path to delete (Path or string)
        """
        # Convert string to Path if needed
        path_obj = self.base_path / path if isinstance(path, str) else path
        full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj
        full_path.unlink(missing_ok=True)

    async def move_file(self, source: FilePath, destination: FilePath) -> None:
        """Move/rename a file from source to destination.

        This method abstracts the underlying storage (filesystem vs cloud).
        Default implementation uses atomic filesystem rename, but cloud-backed
        implementations (e.g., S3) can override to copy+delete.

        Args:
            source: Source path (relative to base_path or absolute)
            destination: Destination path (relative to base_path or absolute)

        Raises:
            FileOperationError: If the move fails
        """
        self.require_project_path(source)
        self.require_project_path(destination)
        # Convert strings to Paths and resolve relative paths against base_path
        src_obj = self.base_path / source if isinstance(source, str) else source
        dst_obj = self.base_path / destination if isinstance(destination, str) else destination
        src_full = src_obj if src_obj.is_absolute() else self.base_path / src_obj
        dst_full = dst_obj if dst_obj.is_absolute() else self.base_path / dst_obj

        try:
            # Ensure destination directory exists
            await self.ensure_directory(dst_full.parent)

            # Use semaphore for concurrency control and run blocking rename in executor
            async with self._file_semaphore:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, lambda: src_full.rename(dst_full))
        except Exception as e:  # pragma: no cover
            logger.exception(
                "File move error",
                source=str(src_full),
                destination=str(dst_full),
                error=str(e),
            )
            raise FileOperationError(f"Failed to move file {source} -> {destination}: {e}")

    async def update_frontmatter_with_result(
        self, path: FilePath, updates: Dict[str, Any]
    ) -> FrontmatterUpdateResult:
        """Update frontmatter and return the exact final written markdown content.

        Only modifies the frontmatter section, leaving all content untouched.
        Creates frontmatter section if none exists.
        Returns both checksum and final content so callers do not need a reread.

        Uses aiofiles for true async I/O (non-blocking).

        Args:
            path: Path to markdown file (Path or string)
            updates: Dict of frontmatter fields to update

        Returns:
            Typed result containing checksum and final content

        Raises:
            FileOperationError: If file operations fail
        """
        # Convert string to Path if needed
        path_obj = self.base_path / path if isinstance(path, str) else path
        full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj

        try:
            # Read current content using aiofiles
            async with aiofiles.open(full_path, mode="r", encoding="utf-8") as f:
                content = await f.read()

            # Parse current frontmatter with proper error handling for malformed YAML
            current_fm = {}
            if file_utils.has_frontmatter(content):
                try:
                    current_fm = file_utils.parse_frontmatter(content)
                except ParseError as e:
                    # Trigger: a fenced frontmatter block cannot be parsed safely.
                    # Why: Markdown is authoritative, and a partial update cannot know
                    # which malformed metadata fields the user intended to preserve.
                    # Outcome: reject the rewrite before any bytes are changed.
                    raise FileOperationError(
                        f"Refusing to update malformed frontmatter in {full_path}: {e}"
                    ) from e
                content = file_utils.remove_frontmatter(content)

            # Update frontmatter
            new_fm = {**current_fm, **updates}

            # Write new file with updated frontmatter
            yaml_fm = yaml.dump(
                new_fm, Dumper=SimpleSafeDumper, sort_keys=False, allow_unicode=True
            )
            final_content = f"---\n{yaml_fm}---\n\n{content.strip()}"

            logger.debug(
                "Updating frontmatter", path=str(full_path), update_keys=list(updates.keys())
            )

            await file_utils.write_file_atomic(full_path, final_content)

            # Format file if configured
            if self.app_config:
                await file_utils.format_file(
                    full_path, self.app_config, is_markdown=self.is_markdown(path)
                )

            # Trigger: frontmatter normalization may persist bytes that differ from the
            # in-memory string because of formatter output or platform newline handling.
            # Why: generation publication must parse the same bytes whose checksum and
            #   note_content generation are claimed; an LF payload paired with CRLF disk
            #   bytes is not one coherent snapshot.
            # Outcome: one binary read supplies both the exact decoded payload and checksum.
            persisted_bytes = await self.read_file_bytes(full_path)
            return FrontmatterUpdateResult(
                checksum=await file_utils.compute_checksum(persisted_bytes),
                content=persisted_bytes.decode("utf-8"),
            )

        except FileOperationError:
            raise
        except Exception as e:  # pragma: no cover
            logger.error(
                "Failed to update frontmatter",
                path=str(full_path),
                error=str(e),
            )
            raise FileOperationError(f"Failed to update frontmatter: {e}")

    async def update_frontmatter(self, path: FilePath, updates: Dict[str, Any]) -> str:
        """Update frontmatter fields in a file while preserving all content."""
        result = await self.update_frontmatter_with_result(path, updates)
        return result.checksum

    async def compute_checksum(self, path: FilePath) -> str:
        """Compute checksum for a file using true async I/O.

        Uses aiofiles for non-blocking I/O with 64KB chunked reading.
        Semaphore limits concurrent file operations to prevent OOM.
        Memory usage is constant regardless of file size.

        Args:
            path: Path to the file (Path or string)

        Returns:
            SHA256 checksum hex string

        Raises:
            FileError: If checksum computation fails
        """
        # Convert string to Path if needed
        path_obj = self.base_path / path if isinstance(path, str) else path
        full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj

        # Semaphore controls concurrency - max N files processed at once
        async with self._file_semaphore:
            try:
                hasher = hashlib.sha256()
                chunk_size = 65536  # 64KB chunks

                # async I/O with aiofiles
                async with aiofiles.open(full_path, mode="rb") as f:
                    while chunk := await f.read(chunk_size):
                        hasher.update(chunk)

                return hasher.hexdigest()

            except Exception as e:  # pragma: no cover
                logger.error("Failed to compute checksum", path=str(full_path), error=str(e))
                raise FileError(f"Failed to compute checksum for {path}: {e}")

    async def get_file_metadata(self, path: FilePath) -> FileMetadata:
        """Return file metadata for a given path.

        This method is async to support cloud implementations (S3FileService)
        where file metadata requires async operations (head_object).

        Args:
            path: Path to the file (Path or string)

        Returns:
            FileMetadata with size, created_at, and modified_at
        """
        # Convert string to Path if needed
        path_obj = self.base_path / path if isinstance(path, str) else path
        full_path = path_obj if path_obj.is_absolute() else self.base_path / path_obj

        # Run blocking stat() in thread pool to maintain async compatibility
        loop = asyncio.get_event_loop()
        stat_result = await loop.run_in_executor(None, full_path.stat)

        return FileMetadata(
            size=stat_result.st_size,
            created_at=datetime.fromtimestamp(stat_result.st_ctime).astimezone(),
            modified_at=datetime.fromtimestamp(stat_result.st_mtime).astimezone(),
        )

    def content_type(self, path: FilePath) -> str:
        """Return content_type for a given path.

        Args:
            path: Path to the file (Path or string)

        Returns:
            MIME type of the file
        """
        # Supported types come from a fixed table, not the host's MIME database,
        # so the same file gets the same type locally and in Cloud.
        return file_content_type(PurePath(path).name)

    def is_markdown(self, path: FilePath) -> bool:
        """Check if a file is a markdown file.

        Args:
            path: Path to the file (Path or string)

        Returns:
            True if the file is a markdown file, False otherwise
        """
        return self.content_type(path) == RUNTIME_MARKDOWN_CONTENT_TYPE
