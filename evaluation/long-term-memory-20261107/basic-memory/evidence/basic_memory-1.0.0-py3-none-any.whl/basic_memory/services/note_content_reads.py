"""Runtime-neutral note-content read service facade."""

from __future__ import annotations

from collections.abc import Sequence
from contextlib import nullcontext
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from basic_memory import db
from basic_memory.indexing.note_content_read_repair_runner import (
    NoteContentReadRepairFileReader,
    NoteContentReadView,
    load_note_content_read_view_with_default_repositories,
    note_content_resource_from_read_view,
    note_content_response_payload_from_read_view,
    prepare_note_content_read_repair_with_default_repositories,
    run_note_content_read_repair_with_default_reconciler,
)
from basic_memory.models import Entity, NoteContent, Project
from basic_memory.read_cache import (
    ReadCacheChange,
    ReadCacheChangeRecorder,
    ReadCacheInvalidator,
    invalidate_recorded_change,
)
from basic_memory.runtime.note_content import (
    RuntimeNoteContentResource,
    RuntimeNoteContentResponsePayload,
)


@dataclass(frozen=True, slots=True)
class AcceptedNoteContent:
    """Current accepted Markdown for one project note."""

    external_id: str
    content: str


async def load_note_content_query_view(
    *,
    session_maker: async_sessionmaker[AsyncSession],
    project_external_id: str,
    entity_external_id: str,
) -> NoteContentReadView[Entity, NoteContent] | None:
    """Load one project-scoped note view from current DB state."""
    async with db.scoped_session(session_maker) as session:
        return await load_note_content_query_view_from_session(
            session=session,
            project_external_id=project_external_id,
            entity_external_id=entity_external_id,
        )


async def load_note_content_query_view_from_session(
    *,
    session: AsyncSession,
    project_external_id: str,
    entity_external_id: str,
) -> NoteContentReadView[Entity, NoteContent] | None:
    """Load one project-scoped note view using caller-owned session scope."""
    return await load_note_content_read_view_with_default_repositories(
        session,
        project_external_id=project_external_id,
        entity_external_id=entity_external_id,
    )


class NoteContentQueryService:
    """Load note-content rows and shape route-friendly read payloads."""

    def __init__(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        read_repair_file_reader: NoteContentReadRepairFileReader[Project, Entity] | None = None,
    ) -> None:
        self.session_maker = session_maker
        self.read_repair_file_reader = read_repair_file_reader

    async def get_note_entity_payload(
        self,
        *,
        project_external_id: str,
        entity_external_id: str,
        session: AsyncSession | None = None,
    ) -> RuntimeNoteContentResponsePayload | None:
        """Return the entity payload, enriching markdown notes from note_content."""
        if session is None:
            note_view = await load_note_content_query_view(
                session_maker=self.session_maker,
                project_external_id=project_external_id,
                entity_external_id=entity_external_id,
            )
        else:
            note_view = await load_note_content_query_view_from_session(
                session=session,
                project_external_id=project_external_id,
                entity_external_id=entity_external_id,
            )
        return note_content_response_payload_from_read_view(note_view)

    async def get_accepted_note_content_batch(
        self,
        *,
        project_id: int,
        entity_external_ids: Sequence[str],
        session: AsyncSession | None = None,
    ) -> list[AcceptedNoteContent]:
        """Load accepted Markdown for several project notes in one database query."""
        statement = select(NoteContent.external_id, NoteContent.markdown_content).where(
            NoteContent.project_id == project_id,
            NoteContent.external_id.in_(entity_external_ids),
        )
        if session is None:
            async with db.scoped_session(self.session_maker) as active_session:
                rows = (await active_session.execute(statement)).all()
        else:
            rows = (await session.execute(statement)).all()
        return [
            AcceptedNoteContent(external_id=external_id, content=content)
            for external_id, content in rows
        ]

    async def get_note_entity_payload_with_read_repair(
        self,
        *,
        project_external_id: str,
        entity_external_id: str,
        session: AsyncSession | None = None,
        source: str = "read_repair",
        read_cache: ReadCacheInvalidator | None = None,
    ) -> RuntimeNoteContentResponsePayload | None:
        """Return entity payload, repairing missing note_content when a reader exists."""
        payload = await self.get_note_entity_payload(
            project_external_id=project_external_id,
            entity_external_id=entity_external_id,
            session=session,
        )
        if payload is not None or self.read_repair_file_reader is None:
            return payload

        repaired = await self.reconcile_note_content_from_file(
            project_external_id=project_external_id,
            entity_external_id=entity_external_id,
            source=source,
            read_cache=read_cache,
        )
        if not repaired:
            return None
        # The repair commits through a separate scoped session, so reopen the read to
        # avoid stale snapshots in caller-owned transactions.
        return await self.get_note_entity_payload(
            project_external_id=project_external_id,
            entity_external_id=entity_external_id,
        )

    async def get_note_resource(
        self,
        *,
        project_external_id: str,
        entity_external_id: str,
        session: AsyncSession | None = None,
    ) -> RuntimeNoteContentResource | None:
        """Return full markdown content from note_content when available."""
        if session is None:
            note_view = await load_note_content_query_view(
                session_maker=self.session_maker,
                project_external_id=project_external_id,
                entity_external_id=entity_external_id,
            )
        else:
            note_view = await load_note_content_query_view_from_session(
                session=session,
                project_external_id=project_external_id,
                entity_external_id=entity_external_id,
            )
        if note_view is None:
            return None

        return note_content_resource_from_read_view(note_view)

    async def get_note_resource_with_read_repair(
        self,
        *,
        project_external_id: str,
        entity_external_id: str,
        session: AsyncSession | None = None,
        source: str = "read_repair",
        read_cache: ReadCacheInvalidator | None = None,
    ) -> RuntimeNoteContentResource | None:
        """Return markdown resource, repairing missing note_content when possible."""
        resource = await self.get_note_resource(
            project_external_id=project_external_id,
            entity_external_id=entity_external_id,
            session=session,
        )
        if resource is not None or self.read_repair_file_reader is None:
            return resource

        repaired = await self.reconcile_note_content_from_file(
            project_external_id=project_external_id,
            entity_external_id=entity_external_id,
            source=source,
            read_cache=read_cache,
        )
        if not repaired:
            return None
        # The repair commits through a separate scoped session, so reopen the read to
        # avoid stale snapshots in caller-owned transactions.
        return await self.get_note_resource(
            project_external_id=project_external_id,
            entity_external_id=entity_external_id,
        )

    async def reconcile_note_content_from_file(
        self,
        *,
        project_external_id: str,
        entity_external_id: str,
        source: str,
        read_cache: ReadCacheInvalidator | None = None,
    ) -> bool:
        """Repair a missing note_content row from the runtime's canonical file source."""
        async with db.scoped_session(self.session_maker) as session:
            repair_preflight = await prepare_note_content_read_repair_with_default_repositories(
                session,
                project_external_id=project_external_id,
                entity_external_id=entity_external_id,
            )
            if not repair_preflight.should_read_file:
                return repair_preflight.repaired

            repair_preflight.require_target()

        if self.read_repair_file_reader is None:
            raise RuntimeError("note-content read repair requires a file reader")

        # The repair runner owns the transaction that may create note_content.
        # Keep invalidation around that whole await so cancellation during commit
        # exit still advances the cache generation before it propagates.
        # A repair converges one note's stored content with its file: that note's
        # response and the content-wide reads change.
        repair_scope = (
            invalidate_recorded_change(read_cache, project_external_id)
            if read_cache is not None
            else nullcontext(ReadCacheChangeRecorder())
        )
        async with repair_scope as repair_change:
            repair_change.record(ReadCacheChange.note_content({entity_external_id}))
            repair_run = await run_note_content_read_repair_with_default_reconciler(
                repair_preflight,
                session_maker=self.session_maker,
                file_reader=self.read_repair_file_reader,
                source=source,
            )
        return repair_run.repaired
