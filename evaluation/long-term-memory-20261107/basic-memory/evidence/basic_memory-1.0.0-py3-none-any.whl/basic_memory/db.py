import asyncio
import os
import sys
from contextlib import asynccontextmanager, suppress
from enum import Enum, auto
from pathlib import Path
from typing import Any, AsyncGenerator, Optional

from basic_memory.config import BasicMemoryConfig, ConfigManager, DatabaseBackend
from alembic import command
from alembic.config import Config

from loguru import logger
from sqlalchemy import text, event
from sqlalchemy.ext.asyncio import (
    create_async_engine,
    async_sessionmaker,
    AsyncSession,
    AsyncEngine,
    async_scoped_session,
)
from sqlalchemy.pool import AsyncAdaptedQueuePool


# -----------------------------------------------------------------------------
# Windows event loop policy
# -----------------------------------------------------------------------------
def _install_event_loop_policy(policy: Any) -> None:
    """Install the Python 3.12-3.15 process-wide compatibility policy."""
    asyncio.set_event_loop_policy(policy)  # ty: ignore[deprecated]


# On Windows, the default ProactorEventLoop has known rough edges with aiosqlite
# during shutdown/teardown (threads posting results to a loop that's closing),
# which can manifest as:
# - "RuntimeError: Event loop is closed"
# - "IndexError: pop from an empty deque"
#
# The SelectorEventLoop doesn't support subprocess operations, so code that uses
# asyncio.create_subprocess_shell() (like sync_service._quick_count_files) must
# detect Windows and use fallback implementations.
if sys.platform == "win32":  # pragma: no cover
    # Constraint: Basic Memory supports Python 3.12-3.15, where the policy API
    # remains the only process-wide way to cover every independently owned loop
    # entrypoint. Replace this compatibility seam with loop factories before 3.16.
    # The factory is a Windows-only asyncio export, so resolve it only after the
    # runtime platform guard (also keeps all-platform static analysis portable).
    windows_selector_policy = getattr(asyncio, "WindowsSelectorEventLoopPolicy")
    _install_event_loop_policy(windows_selector_policy())


def maybe_install_uvloop(config: BasicMemoryConfig) -> bool:
    """Install the uvloop event-loop policy for the Postgres backend.

    Trigger: process entrypoint starting with database_backend == postgres,
    uvloop importable, and a non-Windows platform.
    Why: asyncpg engine teardown (engine.dispose()) races the stdlib asyncio
    loop shutdown and surfaces "IndexError: pop from an empty deque" from
    base_events._run_once (see #831/#877). uvloop's C scheduler has no
    self._ready.popleft() codepath, so that class of crash cannot fire under it.
    Outcome: Postgres deployments run on uvloop; SQLite users keep the default
    loop (no behavior change, smaller blast radius). Must run before the event
    loop is created, i.e. before asyncio.run().

    Returns:
        True if the uvloop policy was installed, False otherwise.
    """
    # uvloop is not available on Windows; the default loop already differs there.
    if sys.platform == "win32":  # pragma: no cover
        return False

    # Limit the change to the backend that actually hits the asyncpg dispose race.
    if config.database_backend != DatabaseBackend.POSTGRES:
        return False

    # Deferred import: uvloop is an optional, platform-gated dependency and the
    # default (SQLite) path must not require it to be installed.
    try:
        import uvloop
    except ImportError:  # pragma: no cover
        logger.warning("uvloop not available - using default event loop for Postgres backend")
        return False

    # Constraint: CLI commands and FastMCP/AnyIO own several separate loop
    # entrypoints. A single policy install keeps all of them on uvloop through
    # Python 3.15; migrate those entrypoints to loop factories before 3.16.
    _install_event_loop_policy(uvloop.EventLoopPolicy())
    logger.info("Installed uvloop event-loop policy for Postgres backend")
    return True


# Module level state
_engine: Optional[AsyncEngine] = None
_session_maker: Optional[async_sessionmaker[AsyncSession]] = None


class DatabaseType(Enum):
    """Types of supported databases."""

    MEMORY = auto()
    FILESYSTEM = auto()
    POSTGRES = auto()

    @classmethod
    def get_db_url(
        cls, db_path: Path, db_type: "DatabaseType", config: Optional[BasicMemoryConfig] = None
    ) -> str:
        """Get SQLAlchemy URL for database path.

        Args:
            db_path: Path to SQLite database file (ignored for Postgres)
            db_type: Type of database (MEMORY, FILESYSTEM, or POSTGRES)
            config: Optional config to check for database backend and URL

        Returns:
            SQLAlchemy connection URL
        """
        # Load config if not provided
        if config is None:
            config = ConfigManager().config

        # Handle explicit Postgres type
        if db_type == cls.POSTGRES:
            if not config.database_url:
                raise ValueError("DATABASE_URL must be set when using Postgres backend")
            logger.info(f"Using Postgres database: {config.database_url}")
            return config.database_url

        # Check if Postgres backend is configured (for backward compatibility)
        if config.database_backend == DatabaseBackend.POSTGRES:
            if not config.database_url:
                raise ValueError("DATABASE_URL must be set when using Postgres backend")
            logger.info(f"Using Postgres database: {config.database_url}")
            return config.database_url

        # SQLite databases
        if db_type == cls.MEMORY:
            logger.info("Using in-memory SQLite database")
            return "sqlite+aiosqlite://"

        return f"sqlite+aiosqlite:///{db_path}"  # pragma: no cover


def get_scoped_session_factory(
    session_maker: async_sessionmaker[AsyncSession],
) -> async_scoped_session[AsyncSession]:
    """Create a scoped session factory scoped to current task."""
    return async_scoped_session(session_maker, scopefunc=asyncio.current_task)


@asynccontextmanager
async def scoped_session(
    session_maker: async_sessionmaker[AsyncSession],
    session: AsyncSession | None = None,
) -> AsyncGenerator[AsyncSession, None]:
    """
    Get a scoped session with proper lifecycle management.

    This is the one shared session-scope seam for services and indexing code.
    It covers both real usage variants:

    - ``session`` provided: the caller-owned session is yielded unchanged and
      the caller keeps commit/rollback ownership (composed multi-step writes).
    - ``session`` omitted: a fresh task-scoped session is opened that commits
      on success, rolls back on error, and always closes.

    Args:
        session_maker: Session maker to create scoped sessions from
        session: Optional caller-owned session to reuse instead of opening one
    """
    # Trigger: the caller already owns a transaction and passes its session in.
    # Why: nested scopes must not commit or roll back mid-way through the
    # caller's composed write; transaction ownership stays with the opener.
    # Outcome: yield the session untouched and let the outermost scope finish it.
    if session is not None:
        yield session
        return

    factory = get_scoped_session_factory(session_maker)
    owned_session = factory()
    try:
        # Only enable foreign keys for SQLite (Postgres has them enabled by default)
        # Detect database type from session's bind (engine) dialect
        engine = owned_session.get_bind()
        dialect_name = engine.dialect.name

        if dialect_name == "sqlite":
            await owned_session.execute(text("PRAGMA foreign_keys=ON"))

        yield owned_session
        await owned_session.commit()
    except Exception:
        await owned_session.rollback()
        raise
    finally:
        await owned_session.close()
        await factory.remove()


_SQLITE_SYNCHRONOUS = {"OFF", "NORMAL", "FULL", "EXTRA"}


def _configure_sqlite_connection(
    dbapi_conn,
    enable_wal: bool = True,
    *,
    synchronous: str = "NORMAL",
    mmap_size: int = 0,
    wal_autocheckpoint: int = 1000,
    page_size: int = 0,
) -> None:
    """Configure a SQLite connection with WAL mode and tunable performance PRAGMAs.

    Args:
        dbapi_conn: Database API connection object
        enable_wal: Whether to enable WAL mode (should be False for in-memory databases)
        synchronous: PRAGMA synchronous level (OFF/NORMAL/FULL/EXTRA)
        mmap_size: PRAGMA mmap_size bytes (0 = disabled)
        wal_autocheckpoint: PRAGMA wal_autocheckpoint pages (0 = disabled; WAL only)
        page_size: PRAGMA page_size bytes (0 = leave default; only affects new DBs)
    """
    cursor = dbapi_conn.cursor()
    try:
        # page_size must be set before the database is written to take effect, so
        # do it first; it is a no-op on an already-populated DB.
        if page_size:
            cursor.execute(f"PRAGMA page_size={int(page_size)}")
        # Enable WAL mode for better concurrency (not supported for in-memory databases)
        if enable_wal:
            cursor.execute("PRAGMA journal_mode=WAL")
        # Set busy timeout to handle locked databases
        cursor.execute("PRAGMA busy_timeout=10000")  # 10 seconds
        # synchronous: OFF trades durability for write throughput. Safe here because
        # the markdown files are the source of truth and the index DB rebuilds from
        # them via sync — a crash means a re-sync, not data loss. Validate the token
        # since it is interpolated into the PRAGMA.
        sync = synchronous.upper() if synchronous.upper() in _SQLITE_SYNCHRONOUS else "NORMAL"
        cursor.execute(f"PRAGMA synchronous={sync}")
        cursor.execute("PRAGMA cache_size=-64000")  # 64MB cache
        cursor.execute("PRAGMA temp_store=MEMORY")
        # mmap_size: memory-map the DB for faster reads, including the lookups
        # inside writes (link/permalink resolution, FTS).
        if mmap_size:
            cursor.execute(f"PRAGMA mmap_size={int(mmap_size)}")
        # wal_autocheckpoint: checkpoint less often to avoid writer stalls under
        # sustained write bursts (WAL only).
        if enable_wal and wal_autocheckpoint:
            cursor.execute(f"PRAGMA wal_autocheckpoint={int(wal_autocheckpoint)}")
        # Windows-specific optimizations
        if os.name == "nt":
            cursor.execute("PRAGMA locking_mode=NORMAL")  # Ensure normal locking on Windows
    except Exception as e:
        # Log but don't fail - some PRAGMAs may not be supported
        logger.warning(f"Failed to configure SQLite connection: {e}")
    finally:
        cursor.close()


def _create_sqlite_engine(
    db_url: str, db_type: DatabaseType, config: Optional[BasicMemoryConfig] = None
) -> AsyncEngine:
    """Create SQLite async engine with appropriate configuration.

    Args:
        db_url: SQLite connection URL
        db_type: Database type (MEMORY or FILESYSTEM)
        config: Optional config supplying the tunable SQLite PRAGMAs

    Returns:
        Configured async engine for SQLite
    """
    # Configure connection args with Windows-specific settings
    connect_args: dict[str, bool | float] = {"check_same_thread": False}

    # Add Windows-specific parameters to improve reliability
    if os.name == "nt":  # Windows
        connect_args.update(
            {
                "timeout": 30.0,  # Increase timeout to 30 seconds for Windows
            }
        )

    if db_type == DatabaseType.MEMORY:
        # Trigger: an in-memory SQLite URL would default to StaticPool, which hands the
        # same DBAPI connection to every concurrently checked-out session.
        # Why: concurrent asyncio tasks then share one transaction scope — a rollback
        # issued by one session (scoped_session exception handling or the pool's
        # reset-on-return) silently destroys another session's uncommitted writes (#940).
        # Outcome: a single-connection blocking queue pool keeps the in-memory database
        # alive for the engine's lifetime while serializing sessions at transaction
        # granularity, restoring the isolation the repositories assume.
        engine = create_async_engine(
            db_url,
            connect_args=connect_args,
            poolclass=AsyncAdaptedQueuePool,
            pool_size=1,
            max_overflow=0,
        )
    elif os.name == "nt":
        # Windows NullPool storms SQLite with connections, while the default
        # pool's overflow still reproduced lock starvation in native CI (#1430).
        # Queue excess callers before SQLite instead of adding competing writers.
        engine = create_async_engine(
            db_url,
            connect_args=connect_args,
            poolclass=AsyncAdaptedQueuePool,
            pool_size=5,
            max_overflow=0,
        )
    else:
        engine = create_async_engine(db_url, connect_args=connect_args)

    # Enable WAL mode for better concurrency and reliability
    # Note: WAL mode is not supported for in-memory databases
    enable_wal = db_type != DatabaseType.MEMORY
    # Snapshot the tunable PRAGMAs once (config is process-stable) so the per-connect
    # listener doesn't re-read config on every pooled connection.
    synchronous = config.sqlite_synchronous if config else "NORMAL"
    mmap_size = config.sqlite_mmap_size if config else 0
    wal_autocheckpoint = config.sqlite_wal_autocheckpoint if config else 1000
    page_size = config.sqlite_page_size if config else 0

    @event.listens_for(engine.sync_engine, "connect")
    def enable_wal_mode(dbapi_conn, connection_record):
        """Apply WAL + tunable PRAGMAs on each connection."""
        _configure_sqlite_connection(
            dbapi_conn,
            enable_wal=enable_wal,
            synchronous=synchronous,
            mmap_size=mmap_size,
            wal_autocheckpoint=wal_autocheckpoint,
            page_size=page_size,
        )

    return engine


def _create_postgres_engine(db_url: str, config: BasicMemoryConfig) -> AsyncEngine:
    """Create Postgres async engine with appropriate configuration.

    Args:
        db_url: Postgres connection URL (postgresql+asyncpg://...)
        config: BasicMemoryConfig with pool settings

    Returns:
        Configured async engine for Postgres
    """
    # Connection pooling for direct (local / self-hosted) Postgres.
    #
    # Trigger: this is the default engine factory. The cloud overrides
    # get_engine_factory with its own pooled engine (basic_memory_cloud
    # tenant_engine_pool), so this path serves the LOCAL runtime — which has no
    # PgBouncer in front of Postgres.
    # Why: NullPool (a fresh connection per request) was assumed safe because a
    # pooler would sit in front, but locally there is none. Under concurrent
    # writes — plus each background materialization opening its own connection —
    # that stormed max_connections and collapsed (p99 478s, 21% write failures at
    # C=32; benchmarks/docs/write-load-benchmark.md).
    # Outcome: a real pool bounds in-use connections to db_pool_size (+
    # db_pool_overflow under load) and recycles them (Neon scale-to-zero).
    # statement_cache_size=0 stays so the engine also works behind a PgBouncer
    # transaction-mode pooler if a user runs one.
    engine = create_async_engine(
        db_url,
        echo=False,
        poolclass=AsyncAdaptedQueuePool,
        pool_size=config.db_pool_size,
        max_overflow=config.db_pool_overflow,
        pool_recycle=config.db_pool_recycle,
        connect_args={
            # Disable statement cache to avoid issues with prepared statements on reconnect
            "statement_cache_size": 0,
            # Allow 30s for commands (Neon cold start can take 2-5s, sometimes longer)
            "command_timeout": 30,
            # Allow 30s for initial connection (Neon wake-up time)
            "timeout": 30,
            "server_settings": {
                "application_name": "basic-memory",
                # Statement timeout for queries (30s to allow for cold start)
                "statement_timeout": "30s",
            },
        },
    )
    logger.debug(
        "Created Postgres engine with QueuePool "
        f"(pool_size={config.db_pool_size}, max_overflow={config.db_pool_overflow})"
    )

    return engine


def _create_engine_and_session(
    db_path: Path,
    db_type: DatabaseType = DatabaseType.FILESYSTEM,
    config: Optional[BasicMemoryConfig] = None,
) -> tuple[AsyncEngine, async_sessionmaker[AsyncSession]]:
    """Internal helper to create engine and session maker.

    Args:
        db_path: Path to database file (used for SQLite, ignored for Postgres)
        db_type: Type of database (MEMORY, FILESYSTEM, or POSTGRES)
        config: Optional explicit config. If not provided, reads from ConfigManager.
            Prefer passing explicitly from composition roots.

    Returns:
        Tuple of (engine, session_maker)
    """
    # Prefer explicit parameter; fall back to ConfigManager for backwards compatibility
    if config is None:
        config = ConfigManager().config
    db_url = DatabaseType.get_db_url(db_path, db_type, config)
    logger.debug(f"Creating engine for db_url: {db_url}")

    # Delegate to backend-specific engine creation
    # Check explicit POSTGRES type first, then config setting
    if db_type == DatabaseType.POSTGRES or config.database_backend == DatabaseBackend.POSTGRES:
        engine = _create_postgres_engine(db_url, config)
    else:
        engine = _create_sqlite_engine(db_url, db_type, config)

    session_maker = async_sessionmaker(engine, expire_on_commit=False)
    return engine, session_maker


async def get_or_create_db(
    db_path: Path,
    db_type: DatabaseType = DatabaseType.FILESYSTEM,
    ensure_migrations: bool = True,
    config: Optional[BasicMemoryConfig] = None,
) -> tuple[AsyncEngine, async_sessionmaker[AsyncSession]]:  # pragma: no cover
    """Get or create database engine and session maker.

    Args:
        db_path: Path to database file
        db_type: Type of database
        ensure_migrations: Whether to run migrations
        config: Optional explicit config. If not provided, reads from ConfigManager.
            Prefer passing explicitly from composition roots.
    """
    global _engine, _session_maker

    # Prefer explicit parameter; fall back to ConfigManager for backwards compatibility
    if config is None:
        config = ConfigManager().config

    if _engine is None:
        _engine, _session_maker = _create_engine_and_session(db_path, db_type, config)

        # Run migrations automatically unless explicitly disabled
        if ensure_migrations:
            await run_migrations(config, db_type)

    # These checks should never fail since we just created the engine and session maker
    # if they were None, but we'll check anyway for the type checker
    if _engine is None:
        logger.error("Failed to create database engine", db_path=str(db_path))
        raise RuntimeError("Database engine initialization failed")

    if _session_maker is None:
        logger.error("Failed to create session maker", db_path=str(db_path))
        raise RuntimeError("Session maker initialization failed")

    return _engine, _session_maker


async def shutdown_db() -> None:  # pragma: no cover
    """Clean up database connections."""
    global _engine, _session_maker

    if _engine:
        # Trigger: teardown can run while the surrounding task is being cancelled
        # (e.g. lifespan shutdown, unshielded CLI cleanup).
        # Why: a cancellation landing mid-dispose surfaces the asyncpg
        # "IndexError: pop from an empty deque" race (#831/#877); shielding lets
        # dispose finish atomically, and suppressing CancelledError keeps a
        # cancelled shutdown from re-raising the underlying race.
        # Outcome: connections always close cleanly even under cancellation.
        with suppress(asyncio.CancelledError):
            await asyncio.shield(_engine.dispose())
        _engine = None
        _session_maker = None


@asynccontextmanager
async def engine_session_factory(
    db_path: Path,
    db_type: DatabaseType = DatabaseType.MEMORY,
    config: Optional[BasicMemoryConfig] = None,
) -> AsyncGenerator[tuple[AsyncEngine, async_sessionmaker[AsyncSession]], None]:
    """Create engine and session factory.

    Note: This is primarily used for testing where we want a fresh database
    for each test. For production use, use get_or_create_db() instead.

    Args:
        db_path: Path to database file
        db_type: Type of database
        config: Optional explicit config. If not provided, reads from ConfigManager.
    """

    global _engine, _session_maker

    # Use the same helper function as production code.
    #
    # Keep local references so teardown can deterministically dispose the
    # specific engine created by this context manager, even if other code calls
    # shutdown_db() and mutates module-level globals mid-test.
    created_engine, created_session_maker = _create_engine_and_session(db_path, db_type, config)
    _engine, _session_maker = created_engine, created_session_maker

    try:
        # Verify that engine and session maker are initialized
        if created_engine is None:  # pragma: no cover
            logger.error("Database engine is None in engine_session_factory")
            raise RuntimeError("Database engine initialization failed")

        if created_session_maker is None:  # pragma: no cover
            logger.error("Session maker is None in engine_session_factory")
            raise RuntimeError("Session maker initialization failed")

        yield created_engine, created_session_maker
    finally:
        # Trigger: context-manager teardown can run while the surrounding task is
        # being cancelled (e.g. a test aborting mid-fixture).
        # Why: on the asyncpg backend a cancellation landing mid-dispose surfaces
        # the "IndexError: pop from an empty deque" race (#831/#877); shield the
        # dispose and suppress CancelledError to match the other dispose seams.
        # Outcome: the per-context engine always disposes cleanly under cancellation.
        with suppress(asyncio.CancelledError):
            await asyncio.shield(created_engine.dispose())

        # Only clear module-level globals if they still point to this context's
        # engine/session. This avoids clobbering newer globals from other callers.
        if _engine is created_engine:
            _engine = None
        if _session_maker is created_session_maker:
            _session_maker = None


async def run_migrations(
    app_config: BasicMemoryConfig, database_type=DatabaseType.FILESYSTEM
):  # pragma: no cover
    """Run any pending alembic migrations.

    Note: Alembic tracks which migrations have been applied via the alembic_version table,
    so it's safe to call this multiple times - it will only run pending migrations.
    """
    logger.info("Running database migrations...")
    temp_engine: AsyncEngine | None = None
    try:
        # Get the absolute path to the alembic directory relative to this file
        alembic_dir = Path(__file__).parent / "alembic"
        config = Config()

        # Set required Alembic config options programmatically
        config.set_main_option("script_location", str(alembic_dir))
        config.set_main_option(
            "file_template",
            "%%(year)d_%%(month).2d_%%(day).2d_%%(hour).2d%%(minute).2d-%%(rev)s_%%(slug)s",
        )
        config.set_main_option("timezone", "UTC")
        config.set_main_option("revision_environment", "false")

        # Get the correct database URL based on backend configuration
        # No URL conversion needed - env.py now handles both async and sync engines
        db_url = DatabaseType.get_db_url(app_config.database_path, database_type, app_config)
        config.set_main_option("sqlalchemy.url", db_url)

        command.upgrade(config, "head")
        logger.info("Migrations completed successfully")

        # Get session maker - ensure we don't trigger recursive migration calls
        if _session_maker is None:
            temp_engine, session_maker = _create_engine_and_session(
                app_config.database_path, database_type, app_config
            )
        else:
            session_maker = _session_maker

        # Import lazily because backend repositories import this module for session
        # management. Startup must still use the composition factory so configured
        # semantic-vector extensions are available during index initialization.
        from basic_memory.repository.search_repository import create_search_repository

        database_backend = (
            DatabaseBackend.POSTGRES
            if database_type == DatabaseType.POSTGRES
            else app_config.database_backend
        )
        search_repository = create_search_repository(
            session_maker=session_maker,
            project_id=1,
            app_config=app_config,
            database_backend=database_backend,
        )
        await search_repository.init_search_index()

    except Exception as e:  # pragma: no cover
        logger.error(f"Error running migrations: {e}")
        raise
    finally:
        # Trigger: run_migrations() created a temporary engine while module-level
        # session maker was not initialized.
        # Why: temporary aiosqlite worker threads can outlive CLI command execution
        # and block process shutdown if the engine is not disposed. On the asyncpg
        # backend a cancellation landing mid-dispose surfaces the same "IndexError:
        # pop from an empty deque" race as the other dispose seams (#831/#877), so
        # shield the dispose and suppress CancelledError to match them.
        # Outcome: always dispose temporary engines cleanly, even under cancellation.
        if temp_engine is not None:
            with suppress(asyncio.CancelledError):
                await asyncio.shield(temp_engine.dispose())
