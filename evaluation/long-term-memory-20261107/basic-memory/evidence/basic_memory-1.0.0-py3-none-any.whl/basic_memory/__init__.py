"""basic-memory - Local-first knowledge management combining Zettelkasten with knowledge graphs"""

# Package version - updated by release automation
__version__ = "1.0.0"

# API version for FastAPI - independent of package version
__api_version__ = "v2"
