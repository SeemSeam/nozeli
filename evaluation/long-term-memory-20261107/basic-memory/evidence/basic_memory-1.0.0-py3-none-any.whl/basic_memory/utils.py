"""Utility functions for basic-memory."""

import json
import os

import logging
import mimetypes
import re
import shlex
import sys
import unicodedata
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import override, Any, Protocol, Union, runtime_checkable, List, Optional

from loguru import logger
from unidecode import unidecode

from basic_memory import telemetry
from basic_memory.runtime.storage import RUNTIME_MARKDOWN_FILE_SUFFIXES


def normalize_project_path(path: str) -> str:
    """Normalize project path by stripping mount point prefix.

    In cloud deployments, the S3 bucket is mounted at /app/data. We strip this
    prefix from project paths to avoid leaking implementation details and to
    ensure paths match the actual S3 bucket structure.

    For local paths (including Windows paths), returns the path unchanged.

    Args:
        path: Project path (e.g., "/app/data/basic-memory-llc" or "C:\\Users\\...")

    Returns:
        Normalized path (e.g., "/basic-memory-llc" or "C:\\Users\\...")

    Examples:
        >>> normalize_project_path("/app/data/my-project")
        '/my-project'
        >>> normalize_project_path("/my-project")
        '/my-project'
        >>> normalize_project_path("app/data/my-project")
        '/my-project'
        >>> normalize_project_path("C:\\\\Users\\\\project")
        'C:\\\\Users\\\\project'
    """
    # Check if this is a Windows absolute path (e.g., C:\Users\...)
    # Windows paths have a drive letter followed by a colon
    if len(path) >= 2 and path[1] == ":":
        # Windows absolute path - return unchanged
        return path  # pragma: no cover

    # Handle both absolute and relative Unix paths
    normalized = path.lstrip("/")
    if normalized.startswith("app/data/"):
        normalized = normalized.removeprefix("app/data/")

    # Ensure leading slash for Unix absolute paths
    if not normalized.startswith("/"):
        normalized = "/" + normalized

    return normalized


@runtime_checkable
class PathLike(Protocol):
    """Protocol for objects that can be used as paths."""

    @override
    def __str__(self) -> str: ...


# In type annotations, use Union[Path, str] instead of FilePath for now
# This preserves compatibility with existing code while we migrate
FilePath = Union[Path, str]
WINDOWS_LOG_FILE_RETENTION = 5


def portable_path_key(path: str) -> str:
    """Compare paths the way case- and normalization-insensitive filesystems do.

    macOS and Windows treat 'Teams' and 'teams' as one folder, and macOS also folds
    Unicode normalization. Two paths with the same key would merge on such a
    filesystem, so the wiki projector and folder-case resolution on write both
    compare by this key.
    """
    return unicodedata.normalize("NFC", path).casefold()


def nfc_path(path: str) -> str:
    """Return a project-relative path in Unicode NFC form.

    macOS filesystems (APFS, HFS+) resolve the NFC and NFD spellings of a name
    to the same file but report whichever form is stored on disk, and file-sync
    tools rewrite that form (Syncthing keeps NFD names on macOS). Paths are
    identity keys, so on macOS every path entering the index is normalized to
    NFC; otherwise a renamed spelling rewrites the key or mints a twin (#1275).

    Linux and Windows (NTFS) filesystems keep NFC and NFD names as two distinct
    files, so there the path is returned unchanged instead of merging two files
    into one key.
    """
    if sys.platform != "darwin":
        return path
    return unicodedata.normalize("NFC", path)


def generate_permalink(file_path: Union[Path, str, PathLike], split_extension: bool = True) -> str:
    """Generate a stable permalink from a file path.

    Args:
        file_path: Original file path (str, Path, or PathLike)
        split_extension: Whether to split off and discard file extensions.
                        When True, uses mimetypes to detect real extensions.
                        When False, preserves all content including periods.

    Returns:
        Normalized permalink that matches validation rules. Converts spaces and underscores
        to hyphens for consistency. Preserves non-ASCII characters like Chinese.
        Preserves periods in version numbers (e.g., "2.0.0") when they're not real file extensions.

    Examples:
        >>> generate_permalink("docs/My Feature.md")
        'docs/my-feature'
        >>> generate_permalink("specs/API (v2).md")
        'specs/api-v2'
        >>> generate_permalink("design/unified_model_refactor.md")
        'design/unified-model-refactor'
        >>> generate_permalink("中文/测试文档.md")
        '中文/测试文档'
        >>> generate_permalink("Version 2.0.0")
        'version-2.0.0'
    """
    # Convert Path to string if needed
    # NFC so both spellings of a name produce one permalink (#1275)
    path_str = unicodedata.normalize("NFC", Path(str(file_path)).as_posix())

    # Only split extension if there's a real file extension
    # Use mimetypes to detect real extensions, avoiding misinterpreting periods in version numbers
    import mimetypes

    mime_type, _ = mimetypes.guess_type(path_str)
    has_real_extension = mime_type is not None

    if has_real_extension and split_extension:
        # Real file extension detected - split it off
        (base, extension) = os.path.splitext(path_str)
    else:
        # No real extension or split_extension=False - process the whole string
        base = path_str
        extension = ""

    # Check if we have CJK characters that should be preserved
    # CJK ranges: \u4e00-\u9fff (CJK Unified Ideographs), \u3000-\u303f (CJK symbols),
    # \u3400-\u4dbf (CJK Extension A), \uff00-\uffef (Fullwidth forms)
    has_cjk_chars = any(
        "\u4e00" <= char <= "\u9fff"
        or "\u3000" <= char <= "\u303f"
        or "\u3400" <= char <= "\u4dbf"
        or "\uff00" <= char <= "\uffef"
        for char in base
    )

    if has_cjk_chars:
        # For text with CJK characters, selectively transliterate only Latin accented chars
        result = ""
        for char in base:
            if (
                "\u4e00" <= char <= "\u9fff"
                or "\u3000" <= char <= "\u303f"
                or "\u3400" <= char <= "\u4dbf"
            ):
                # Preserve CJK ideographs and symbols
                result += char
            elif "\uff00" <= char <= "\uffef":
                # Remove Chinese fullwidth punctuation entirely (like ，！？)
                continue
            else:
                # Transliterate Latin accented characters to ASCII
                result += unidecode(char)

        # Insert hyphens between CJK and Latin character transitions
        # Match: CJK followed by Latin letter/digit, or Latin letter/digit followed by CJK
        result = re.sub(
            r"([\u4e00-\u9fff\u3000-\u303f\u3400-\u4dbf])([a-zA-Z0-9])", r"\1-\2", result
        )
        result = re.sub(
            r"([a-zA-Z0-9])([\u4e00-\u9fff\u3000-\u303f\u3400-\u4dbf])", r"\1-\2", result
        )

        # Insert dash between camelCase
        result = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", result)

        # Convert ASCII letters to lowercase, preserve CJK
        lower_text = "".join(c.lower() if c.isascii() and c.isalpha() else c for c in result)

        # Replace underscores with hyphens
        text_with_hyphens = lower_text.replace("_", "-")

        # Remove apostrophes entirely (don't replace with hyphens)
        text_no_apostrophes = text_with_hyphens.replace("'", "")

        # Replace unsafe chars with hyphens, but preserve CJK characters and periods
        clean_text = re.sub(
            r"[^a-z0-9\u4e00-\u9fff\u3000-\u303f\u3400-\u4dbf/\-\.]", "-", text_no_apostrophes
        )
    else:
        # Original ASCII-only processing for backward compatibility
        # Transliterate unicode to ascii
        ascii_text = unidecode(base)

        # Insert dash between camelCase
        ascii_text = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", ascii_text)

        # Convert to lowercase
        lower_text = ascii_text.lower()

        # replace underscores with hyphens
        text_with_hyphens = lower_text.replace("_", "-")

        # Remove apostrophes entirely (don't replace with hyphens)
        text_no_apostrophes = text_with_hyphens.replace("'", "")

        # Replace remaining invalid chars with hyphens, preserving periods
        clean_text = re.sub(r"[^a-z0-9/\-\.]", "-", text_no_apostrophes)

    # Collapse multiple hyphens
    clean_text = re.sub(r"-+", "-", clean_text)

    # Clean each path segment
    segments = clean_text.split("/")
    clean_segments = [s.strip("-") for s in segments]

    return_val = "/".join(clean_segments)

    # Append file extension back, if necessary
    if not split_extension and extension:  # pragma: no cover
        return_val += extension  # pragma: no cover

    return return_val


def normalize_project_reference(identifier: str) -> str:
    """Normalize project-prefixed references.

    Converts project namespace syntax ("project::note") to path syntax ("project/note").
    Leaves non-namespaced identifiers unchanged.
    """
    if "::" not in identifier:
        return identifier

    project, remainder = identifier.split("::", 1)
    remainder = remainder.lstrip("/")
    return f"{project}/{remainder}"


def build_canonical_permalink(
    project_permalink: Optional[str],
    file_path: Union[Path, str, PathLike],
    include_project: bool = True,
    *,
    workspace_permalink: Optional[str] = None,
) -> str:
    """Build a canonical permalink, optionally prefixed with workspace/project slugs.

    Args:
        project_permalink: URL-friendly project identifier (slug). If None, no prefix is added.
        file_path: Original file path or permalink-like string.
        include_project: When True, prefix with project slug.
        workspace_permalink: Optional URL-friendly workspace identifier. When provided,
            prefix the project-qualified permalink with this workspace slug.

    Returns:
        Canonical permalink string.
    """
    normalized_path = generate_permalink(file_path)
    normalized_workspace = generate_permalink(workspace_permalink) if workspace_permalink else None

    if normalized_workspace:
        if not project_permalink:
            raise ValueError("workspace_permalink requires project_permalink")

        normalized_project = generate_permalink(project_permalink)
        workspace_project_prefix = f"{normalized_workspace}/{normalized_project}"
        if normalized_path == workspace_project_prefix or normalized_path.startswith(
            f"{workspace_project_prefix}/"
        ):
            return normalized_path

        if normalized_path == normalized_project or normalized_path.startswith(
            f"{normalized_project}/"
        ):
            project_path = normalized_path
        else:
            project_path = f"{normalized_project}/{normalized_path}"

        return f"{normalized_workspace}/{project_path}"

    if not include_project or not project_permalink:
        return normalized_path

    normalized_project = generate_permalink(project_permalink)
    if normalized_path == normalized_project or normalized_path.startswith(
        f"{normalized_project}/"
    ):
        project_path = normalized_path
    else:
        project_path = f"{normalized_project}/{normalized_path}"

    return project_path


def build_qualified_permalink_reference(
    project_permalink: Optional[str],
    identifier: Union[Path, str, PathLike],
    include_project: bool = True,
    *,
    workspace_permalink: Optional[str] = None,
) -> str:
    """Add workspace/project route prefixes while preserving lookup syntax.

    Unlike ``build_canonical_permalink()``, this helper does not run the identifier
    through permalink generation. It is for inbound references that may contain
    lookup-only syntax such as ``.md`` extensions or ``*`` glob patterns.
    """
    normalized_path = normalize_project_reference(str(identifier)).strip("/")
    normalized_workspace = generate_permalink(workspace_permalink) if workspace_permalink else None
    normalized_project = generate_permalink(project_permalink) if project_permalink else None

    if normalized_workspace:
        if not normalized_project:
            raise ValueError("workspace_permalink requires project_permalink")

        workspace_project_prefix = f"{normalized_workspace}/{normalized_project}"
        if not normalized_path:
            return workspace_project_prefix
        if normalized_path == workspace_project_prefix or normalized_path.startswith(
            f"{workspace_project_prefix}/"
        ):
            return normalized_path
        if normalized_path == normalized_project or normalized_path.startswith(
            f"{normalized_project}/"
        ):
            return f"{normalized_workspace}/{normalized_path}"
        return f"{workspace_project_prefix}/{normalized_path}"

    if not include_project or not normalized_project:
        return normalized_path

    if not normalized_path:
        return normalized_project
    if normalized_path == normalized_project or normalized_path.startswith(
        f"{normalized_project}/"
    ):
        return normalized_path
    return f"{normalized_project}/{normalized_path}"


def own_project_remainder(
    identifier: str,
    project_permalink: Optional[str],
    *,
    workspace_permalink: Optional[str] = None,
) -> Optional[str]:
    """Return an identifier without this project's routing prefix, or None.

    Routed identifiers arrive qualified as `<workspace>/<project>/…` on
    workspace-scoped routes and `<project>/…` otherwise. Permalink candidates
    strip those prefixes, but title and file-path lookups need the
    project-relative remainder too: a title, or a resource whose permalink is
    NULL, can only match there (#1626, #1629). Prefixes match by permalink, as
    routing does, so `TEST-PROJECT/…` names `test-project`.
    """
    if not project_permalink:
        return None
    normalized_project = generate_permalink(project_permalink)
    prefixes = [f"{normalized_project}/"]
    if workspace_permalink:
        prefixes.insert(0, f"{generate_permalink(workspace_permalink)}/{normalized_project}/")
    normalized_identifier = generate_permalink(identifier)
    for prefix in prefixes:
        if normalized_identifier.startswith(prefix):
            remainder = identifier.split("/", prefix.count("/"))[-1]
            return remainder or None
    return None


def has_non_markdown_file_extension(path: str) -> bool:
    """Return whether a path ends in a real file extension that is not Markdown.

    Uses the same mimetypes test as generate_permalink, so version-like titles
    (`Release 2.0`) are not mistaken for files.
    """
    suffix = PurePosixPath(path).suffix.casefold()
    if not suffix or suffix in RUNTIME_MARKDOWN_FILE_SUFFIXES:
        return False
    return mimetypes.guess_type(path)[0] is not None


def build_permalink_resolution_candidates(
    identifier: Union[Path, str, PathLike],
    project_permalink: Optional[str],
    include_project: bool = True,
    *,
    workspace_permalink: Optional[str] = None,
) -> list[str]:
    """Return permalink candidates from most caller-specific to broadest legacy form.

    The first candidate preserves the normalized identifier the caller supplied. Follow-up
    candidates add the active workspace/project route and legacy project/path forms so
    all resolver callers share the same compatibility behavior.
    """
    exact_path = normalize_project_reference(str(identifier)).strip("/")

    # Trigger: the identifier names a file with a real, non-Markdown extension
    #   (`notes/foo.txt`, `assets/doc.pdf`).
    # Why: resource entities carry no permalink, so dropping the extension could
    #   only ever match the same-stem Markdown note, which is the wrong file (#1629).
    # Outcome: the extension stays; callers reach the file through their exact
    #   file-path lookups instead.
    if has_non_markdown_file_extension(exact_path):
        return list(
            dict.fromkeys([exact_path, generate_permalink(exact_path, split_extension=False)])
        )

    normalized_path = generate_permalink(exact_path).strip("/")
    normalized_project = generate_permalink(project_permalink) if project_permalink else None
    normalized_workspace = generate_permalink(workspace_permalink) if workspace_permalink else None
    candidates: list[str] = []

    def add_candidate(value: str | None) -> None:
        if value and value not in candidates:
            candidates.append(value)

    def add_remainder(prefix: str, *, requalify_with: str | None = None) -> None:
        # Trigger: a routing prefix is stripped to reach a shorter stored permalink.
        # Why: a permalink set explicitly in frontmatter is stored verbatim, so
        #   `ses_AbCd` never equals its slug `ses-ab-cd`; stripping only the
        #   normalized path left such notes unreachable by memory:// URL (#1549).
        # Outcome: each remainder is tried in the caller's own spelling first, then
        #   as its slug, optionally under a legacy `project/` qualifier.
        remainders = [normalized_path.removeprefix(f"{prefix}/")]
        if exact_path.startswith(f"{prefix}/"):
            remainders.insert(0, exact_path.removeprefix(f"{prefix}/"))
        for remainder in remainders:
            add_candidate(f"{requalify_with}/{remainder}" if requalify_with else remainder)

    add_candidate(exact_path)
    add_candidate(normalized_path)
    if not normalized_project:
        return candidates

    workspace_project_prefix = (
        f"{normalized_workspace}/{normalized_project}" if normalized_workspace else None
    )
    workspace_qualified = False
    if workspace_project_prefix:
        add_candidate(
            build_canonical_permalink(
                normalized_project,
                normalized_path,
                include_project=include_project,
                workspace_permalink=normalized_workspace,
            )
        )
        if normalized_path == workspace_project_prefix:
            workspace_qualified = True
            add_candidate(normalized_project)
        elif normalized_path.startswith(f"{workspace_project_prefix}/"):
            workspace_qualified = True
            add_remainder(workspace_project_prefix, requalify_with=normalized_project)
            add_remainder(workspace_project_prefix)

    if workspace_project_prefix and not include_project and not workspace_qualified:
        # Trigger: short lookup in a workspace where new canonical links omit project prefixes.
        # Why: older rows in that same workspace may still be stored as `project/path`.
        # Outcome: try the project-prefixed legacy form after the workspace-qualified form.
        add_candidate(
            build_canonical_permalink(
                normalized_project,
                normalized_path,
                include_project=True,
            )
        )

    if include_project and not workspace_qualified:
        add_candidate(
            build_canonical_permalink(
                normalized_project,
                normalized_path,
                include_project=True,
            )
        )
        if normalized_path == normalized_project:
            return candidates
        if normalized_path.startswith(f"{normalized_project}/"):
            add_remainder(normalized_project)

    if not include_project and normalized_path.startswith(f"{normalized_project}/"):
        # Trigger: caller supplied `project/path` while legacy short permalinks are stored.
        # Why: routing uses the project prefix, but strict lookup still needs the short row.
        # Outcome: try `path` after the exact project-qualified candidate.
        add_remainder(normalized_project)

    return candidates


def setup_logging(
    log_level: str = "INFO",
    log_to_file: bool = False,
    log_to_stdout: bool = False,
    structured_context: bool = False,
) -> None:
    """Configure logging with explicit settings.

    This function provides a simple, explicit interface for configuring logging.
    Each entry point (CLI, MCP, API) should call this with appropriate settings.

    Args:
        log_level: DEBUG, INFO, WARNING, ERROR
        log_to_file: Write to <basic-memory data dir>/basic-memory.log with rotation
            (honors BASIC_MEMORY_CONFIG_DIR)
        log_to_stdout: Write to stderr (for Docker/cloud deployments)
        structured_context: Bind tenant_id, fly_region, etc. for cloud observability
    """
    # Remove default handler and any existing handlers
    logger.remove()

    # In test mode, only log to stdout regardless of settings
    env = os.getenv("BASIC_MEMORY_ENV", "dev")
    if env == "test":
        logger.add(sys.stderr, level=log_level, backtrace=True, diagnose=True, colorize=True)
        return

    # Trigger: a traceback is logged while a request is being handled, for example by the
    #   API's catch-all exception handler.
    # Why: diagnose=True calls repr() on every value named in every frame of the traceback,
    #   synchronously. Each ASGI middleware frame holds `scope`, and under FastAPI 0.139
    #   repr(scope) is about 190 MB (its "fastapi" entry carries the route's dependency
    #   tree), so one unhandled exception costs seconds of CPU on the event loop.
    # Outcome: the long-lived sinks keep the full traceback (backtrace=True) and drop the
    #   per-frame value dump. Test mode above keeps diagnose=True.
    # Add file handler with rotation
    if log_to_file:
        # Trigger: Windows does not allow renaming an open file held by another process.
        # Why: multiple basic-memory processes can share the same log directory at once.
        # Outcome: use per-process log files on Windows so log rotation stays local.
        log_filename = f"basic-memory-{os.getpid()}.log" if os.name == "nt" else "basic-memory.log"
        # Deferred import: basic_memory.config imports from this module at load time,
        # so resolving the data dir via a top-level import would cycle.
        from basic_memory.config import resolve_data_dir

        log_path = resolve_data_dir() / log_filename
        log_path.parent.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            _cleanup_windows_log_files(log_path.parent, log_path.name)
        # Keep logging synchronous (enqueue=False) to avoid background logging threads.
        # Background threads are a common source of "hang on exit" issues in CLI/test runs.
        logger.add(
            str(log_path),
            level=log_level,
            rotation="10 MB",
            retention=5,
            backtrace=True,
            diagnose=False,
            enqueue=False,
            colorize=False,
        )

    # Add stdout handler (for Docker/cloud)
    if log_to_stdout:
        logger.add(sys.stderr, level=log_level, backtrace=True, diagnose=False, colorize=True)

    # Add Logfire sink when telemetry bootstrap enabled it for this process.
    # logfire.loguru_handler() sets no diagnose, so loguru's default (True) would bring
    # back the per-frame repr() cost on every process that ships logs to Logfire.
    logfire_handler = telemetry.get_logfire_handler()
    if logfire_handler is not None:
        logger.add(**logfire_handler, diagnose=False)

    # Bind structured context for cloud observability
    if structured_context:
        logger.configure(
            extra={
                "tenant_id": os.getenv("BASIC_MEMORY_TENANT_ID", "local"),
                "fly_app_name": os.getenv("FLY_APP_NAME", "local"),
                "fly_machine_id": os.getenv("FLY_MACHINE_ID", "local"),
                "fly_region": os.getenv("FLY_REGION", "local"),
            }
        )

    # Reduce noise from third-party libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("watchfiles.main").setLevel(logging.WARNING)


def _cleanup_windows_log_files(log_dir: Path, current_log_name: str) -> None:
    """Trim stale per-process Windows log files so the directory stays bounded."""
    stale_logs = [
        path
        for path in log_dir.glob("basic-memory-*.log*")
        if path.is_file() and path.name != current_log_name
    ]

    if len(stale_logs) <= WINDOWS_LOG_FILE_RETENTION - 1:
        return

    # Trigger: per-process log filenames avoid Windows rename contention but fragment retention.
    # Why: loguru retention applies per sink, not across the whole basic-memory log directory.
    # Outcome: keep only the newest stale PID logs so repeated CLI/server launches stay bounded.
    def _mtime(path: Path) -> float:
        try:
            return path.stat().st_mtime
        except OSError:
            # Another launch pruned it between the glob above and this read. Sorting it last means it lands in
            # the delete slice, where unlink() is already guarded against the same race.
            return -1.0

    stale_logs.sort(key=_mtime, reverse=True)
    for stale_log in stale_logs[WINDOWS_LOG_FILE_RETENTION - 1 :]:
        try:
            stale_log.unlink()
        except OSError:
            logger.debug("Failed to delete stale Windows log file: {path}", path=stale_log)


def parse_tags(tags: Union[List[str], str, None]) -> List[str]:
    """Parse tags from various input formats into a consistent list.

    Args:
        tags: Can be a list of strings, a comma-separated string, or None

    Returns:
        A list of tag strings, or an empty list if no tags

    Note:
        This function strips leading '#' characters from tags to prevent
        their accumulation when tags are processed multiple times.
    """
    if tags is None:
        return []

    # Process list of tags
    if isinstance(tags, list):
        # Trigger: a list element may itself be a comma-separated string (e.g. typer collects
        #   `--tags "a,b"` into the one-element list `["a,b"]`).
        # Why: keep the CLI list path and the MCP bare-string path on a single source of truth so
        #   `--tags "a,b"`, `--tags a --tags b`, and `tags="a,b"` all converge to the same tags.
        # Outcome: flatten by splitting each element on commas before stripping '#' / whitespace.
        # Skip None entries (e.g. a YAML `tags: [alpha, null]`) so they are not revived as
        # the literal tag "None" by str(raw); the old list branch ignored such falsy entries.
        return [
            tag.strip().lstrip("#")
            for raw in tags
            if raw is not None
            for tag in str(raw).split(",")
            if tag and tag.strip()
        ]

    # Process string input
    if isinstance(tags, str):
        # Check if it's a JSON array string (common issue from AI assistants)
        import json

        if tags.strip().startswith("[") and tags.strip().endswith("]"):
            try:
                # Try to parse as JSON array
                parsed_json = json.loads(tags)
                if isinstance(parsed_json, list):
                    # Recursively parse the JSON array as a list
                    return parse_tags(parsed_json)
            except json.JSONDecodeError:
                # Not valid JSON, fall through to comma-separated parsing
                pass

        # Split by comma, strip whitespace, then strip leading '#' characters
        return [tag.strip().lstrip("#") for tag in tags.split(",") if tag and tag.strip()]

    # For any other type, try to convert to string and parse
    try:  # pragma: no cover
        return parse_tags(str(tags))
    except (ValueError, TypeError):  # pragma: no cover
        logger.warning(f"Couldn't parse tags from input of type {type(tags)}: {tags}")
        return []


def parse_str_list(v: Any) -> List[str]:
    """Parse a list of plain strings from various input formats.

    Like parse_tags but without stripping '#' — correct for type/category params
    where the value is a literal identifier, not a hashtag.

    Handles the four input shapes that MCP clients commonly produce:
    - None → []
    - "note,task" → ["note", "task"] (comma-split string)
    - '["note","task"]' → ["note", "task"] (JSON array string)
    - ["note,task"] → ["note", "task"] (list with comma-string element)

    Non-str/list/None values are returned unchanged so Pydantic can reject them
    with a clear validation error instead of silently coercing.
    """
    if v is None:
        return []

    if isinstance(v, list):
        # Trigger: a list element is not a string (e.g. [42] or ["note", 42]).
        # Why: str(raw) would silently convert 42 → "42" and let invalid caller data pass
        #   Pydantic validation as a junk filter, producing a silent no-result search.
        # Outcome: return the list unchanged so Pydantic rejects it with a clear error.
        if not all(isinstance(raw, str) for raw in v if raw is not None):
            return v  # type: ignore[return-value]

        # Trigger: a list element may itself be a comma-separated string (e.g. some MCP clients
        #   serialise `["note,task"]` when the caller passed `note_types="note,task"`).
        # Outcome: flatten each element by splitting on commas and stripping whitespace.
        return [
            item.strip()
            for raw in v
            if raw is not None
            for item in raw.split(",")
            if item and item.strip()
        ]

    if isinstance(v, str):
        # Trigger: MCP clients sometimes send a JSON array string like '["note","task"]'.
        # Outcome: parse it as JSON first, then recurse to handle the resulting list.
        stripped = v.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            try:
                parsed_json = json.loads(stripped)
                if isinstance(parsed_json, list):
                    return parse_str_list(parsed_json)
            except json.JSONDecodeError:
                pass

        # Plain comma-separated string: "note,task" → ["note", "task"]
        return [item.strip() for item in v.split(",") if item and item.strip()]

    # Non-str/list/None — return unchanged so Pydantic rejects with a clear error.
    return v  # type: ignore[return-value]


def coerce_list(v: Any) -> Any:
    """Coerce string input to list for MCP clients that serialize lists as strings."""
    if v is None:
        return v
    if isinstance(v, str):
        try:
            parsed = json.loads(v)
            if isinstance(parsed, list):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
        # Single string value — wrap in a list
        return [v]
    return v


def coerce_dict(v: Any) -> Any:
    """Coerce string input to dict for MCP clients that serialize dicts as strings."""
    if v is None:
        return v
    if isinstance(v, str):
        try:
            parsed = json.loads(v)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
    return v


def normalize_newlines(multiline: str) -> str:
    """Replace any \r\n, \r, or \n with the native newline.

    Args:
        multiline: String containing any mixture of newlines.

    Returns:
        A string with normalized newlines native to the platform.
    """
    return re.sub(r"\r\n?|\n", os.linesep, multiline)


def normalize_file_path_for_comparison(file_path: str) -> str:
    """Normalize a file path for conflict detection.

    This function normalizes file paths to help detect potential conflicts:
    - Converts to lowercase for case-insensitive comparison
    - Normalizes Unicode characters
    - Converts backslashes to forward slashes for cross-platform consistency

    Args:
        file_path: The file path to normalize

    Returns:
        Normalized file path for comparison purposes
    """
    from pathlib import PureWindowsPath

    # Use PureWindowsPath to ensure backslashes are treated as separators
    # regardless of current platform, then convert to POSIX-style
    normalized = PureWindowsPath(file_path).as_posix().lower()

    # Normalize Unicode characters (NFD normalization)
    normalized = unicodedata.normalize("NFD", normalized)

    return normalized


def detect_potential_file_conflicts(file_path: str, existing_paths: List[str]) -> List[str]:
    """Detect potential conflicts between a file path and existing paths.

    This function checks for various types of conflicts:
    - Case sensitivity differences
    - Unicode normalization differences
    - Path separator differences
    - Permalink generation conflicts

    Args:
        file_path: The file path to check
        existing_paths: List of existing file paths to check against

    Returns:
        List of existing paths that might conflict with the given file path
    """
    conflicts = []

    # Normalize the input file path
    normalized_input = normalize_file_path_for_comparison(file_path)
    input_permalink = generate_permalink(file_path)

    for existing_path in existing_paths:
        # Skip identical paths
        if existing_path == file_path:
            continue

        # Check for case-insensitive path conflicts
        normalized_existing = normalize_file_path_for_comparison(existing_path)
        if normalized_input == normalized_existing:
            conflicts.append(existing_path)
            continue

        # Check for permalink conflicts
        existing_permalink = generate_permalink(existing_path)
        if input_permalink == existing_permalink:
            conflicts.append(existing_path)
            continue

    return conflicts


def resolve_directory_casing(directory: str, existing_directories: List[str]) -> str:
    """Resolve a requested directory to the casing of existing folders (#1326).

    LLM callers guess plausible-but-wrong casing ("schemas" beside an existing
    "Schemas/"), and case-sensitive storage backends then grow case-duplicate
    sibling folders. Each path segment resolves against the folders that exist
    under the already-resolved parent:

    - Exact match wins: the requested segment casing is kept unchanged.
    - Unique match by portable_path_key (casefold plus Unicode NFC, #1796): the
      existing folder's spelling is adopted, so 'teams' and an NFD-spelled
      'café' land in the folder a case-insensitive filesystem would merge them into.
    - No match: the segment is kept as given (a new folder).
    - Multiple case-variant folders exist: ambiguous, the segment is kept as
      given (today's exact behavior).

    Args:
        directory: Requested directory path relative to the project root
            ("" means the root itself).
        existing_directories: Known project folders derived from indexed entity
            file paths (see EntityRepository.get_distinct_directories).

    Returns:
        The directory path with each segment resolved to existing casing.
    """
    if not directory:
        return directory

    existing = set(existing_directories)
    resolved_prefix = ""
    for segment in directory.split("/"):
        candidate = f"{resolved_prefix}/{segment}" if resolved_prefix else segment
        if candidate in existing:
            resolved_prefix = candidate
            continue
        candidate_key = portable_path_key(candidate)
        # Candidates are constrained to children of the already-resolved parent:
        # once a parent segment stays ambiguous (kept as requested), a deeper
        # existing folder under a *different* parent casing must not be spliced in.
        matches = [
            existing_directory
            for existing_directory in existing
            if portable_path_key(existing_directory) == candidate_key
            and existing_directory.rpartition("/")[0] == resolved_prefix
        ]
        resolved_prefix = matches[0] if len(matches) == 1 else candidate
    return resolved_prefix


def resolve_path_within_root(path: str | Path, root: Path, *, allow_root: bool = True) -> Path:
    """Resolve a local path beneath its root without rewriting filename spelling."""
    try:
        resolved_root = root.resolve()
        resolved = (resolved_root / path).resolve()
    except (OSError, RuntimeError) as error:
        # Python 3.12 reports symlink loops as RuntimeError rather than OSError.
        raise ValueError(f"Cannot resolve path '{path}' within root '{root}'") from error
    if not resolved.is_relative_to(resolved_root) or (not allow_root and resolved == resolved_root):
        raise ValueError(f"Path '{path}' is outside the permitted root '{root}'")
    return resolved


def valid_project_path_value(
    path: str, *, allow_literal_tilde: bool = False, allow_literal_colon: bool = False
) -> bool:
    """Ensure project path is valid."""
    # Allow empty strings as they resolve to the project root
    if not path:
        return True

    # Check for tilde (home directory expansion)
    if not allow_literal_tilde and "~" in path:
        return False

    # Check for ".." as a path segment (path traversal), not as a substring.
    # Filenames like "hi-everyone..md" are legitimate and must not be blocked.
    # Also block segments like ".. " and ".. ." because Windows normalizes
    # trailing dots and spaces away, making them equivalent to "..".
    segments = path.replace("\\", "/").split("/")
    if any(
        seg == ".." or (len(seg) > 2 and seg[:2] == ".." and all(c in ". " for c in seg[2:]))
        for seg in segments
    ):
        return False

    # Check for Windows-style leading backslash
    if path.startswith("\\"):
        return False

    # Block absolute paths (Unix-style starting with / or Windows-style with drive letters)
    if path.startswith("/") or (not allow_literal_colon and len(path) >= 2 and path[1] == ":"):
        return False

    # Path consumers preserve filename spelling, so control-only names need
    # the same validation as names containing other characters.
    if any(ord(c) < 32 and c not in [" ", "\t"] for c in path):
        return False

    return True


def validate_project_path(
    path: str,
    project_path: Path | None,
    *,
    allow_literal_tilde: bool = False,
    allow_literal_colon: bool = False,
) -> bool:
    """Validate a relative path, resolving symlinks only for a local storage root.

    Pass None for remote/object storage. Its logical namespace must never be
    interpreted against the filesystem of the API or MCP process.
    """

    if not valid_project_path_value(
        path, allow_literal_tilde=allow_literal_tilde, allow_literal_colon=allow_literal_colon
    ):
        return False

    if project_path is None:
        return True

    try:
        resolve_path_within_root(path, project_path)
        return True
    except ValueError:
        return False


def ensure_timezone_aware(dt: datetime, cloud_mode: bool | None = None) -> datetime:
    """Ensure a datetime is timezone-aware.

    If the datetime is naive, convert it to timezone-aware. The interpretation
    depends on cloud_mode:
    - In cloud mode (PostgreSQL/asyncpg): naive datetimes are interpreted as UTC
    - In local mode (SQLite): naive datetimes are interpreted as local time

    asyncpg uses binary protocol which returns timestamps in UTC but as naive
    datetimes. In cloud deployments, cloud_mode=True handles this correctly.

    Args:
        dt: The datetime to ensure is timezone-aware
        cloud_mode: Optional explicit cloud_mode setting. If None, inferred from
            configured database backend (Postgres => UTC semantics).

    Returns:
        A timezone-aware datetime
    """
    if dt.tzinfo is None:
        # Determine cloud_mode: use explicit parameter if provided, otherwise infer from config.
        if cloud_mode is None:
            from basic_memory.config import ConfigManager, DatabaseBackend

            cloud_mode = ConfigManager().config.database_backend == DatabaseBackend.POSTGRES

        if cloud_mode:
            # Cloud/PostgreSQL mode: naive datetimes from asyncpg are already UTC
            return dt.replace(tzinfo=timezone.utc)
        else:
            # Local/SQLite mode: naive datetimes are in local time
            return dt.astimezone()
    else:
        # Already timezone-aware
        return dt


def shell_command(*parts: str) -> str:
    """Render a command line for display, with every argument shell-quoted.

    Printed commands are copy-pasted and run, so an argument holding a space or a
    shell metacharacter has to survive that round trip. Built by interpolation, a
    project named ``My Notes`` renders as ``bm project add My Notes --cloud``,
    which the CLI parses as project ``My`` with positional path ``Notes`` -- so
    the remedy runs, succeeds, and acts on a project the user never named. That
    is worse than a remedy that fails, because nothing signals the mistake.

    Quoting is POSIX (``shlex``), which is also what the repo's own docs and
    examples assume; a cmd.exe user pasting this may need to adjust quoting, but
    unquoted output is wrong on every platform.
    """
    return shlex.join(parts)
