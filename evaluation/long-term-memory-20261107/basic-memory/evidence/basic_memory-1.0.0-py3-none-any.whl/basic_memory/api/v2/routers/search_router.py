"""V2 router for search operations.

This router uses external_id UUIDs for stable, API-friendly routing.
V1 uses string-based project names which are less efficient and less stable.
"""

import asyncio

from fastapi import APIRouter, Path, Response

import logfire
from basic_memory import db
from basic_memory.api.v2.utils import (
    load_temporal_metadata,
    search_error_boundary,
    to_search_results,
)
from basic_memory.read_cache import ReadCacheOperation
from basic_memory.read_cache.policy import SEARCH_READ_CACHE_TTL_SECONDS
from basic_memory.read_cache.routes import cached_read, content_group
from basic_memory.deps import (
    EntityServiceV2ExternalDep,
    MemoryTimeIndexRepositoryV2ExternalDep,
    ProjectExternalIdPathDep,
    SearchReindexSchedulerDep,
    SearchServiceV2ExternalDep,
    SessionMakerDep,
)
from basic_memory.repository.metadata_filters import parse_metadata_filters
from basic_memory.repository.search_index_row import SearchIndexRow
from basic_memory.schemas.search import SearchQuery, SearchResponse, SearchRetrievalMode
from basic_memory.services.search_service import SearchService
from basic_memory.services.search_guidance import unspaced_script_query_hint

# App registration mounts this router at /v2/projects/{project_id}.
router = APIRouter(tags=["search"])


async def _search_with_exact_count(
    search_service: SearchService,
    query: SearchQuery,
    *,
    limit: int,
    offset: int,
) -> tuple[list[SearchIndexRow], int]:
    """Run the page query and its exact count together, as one owned unit of work.

    Trigger: either query fails while the other is still running.
    Why: asyncio.gather propagates the first failure but leaves its sibling
         running with no owner — a count kept querying after its request had
         already answered 400, then raised an exception nobody retrieved.
    Outcome: a TaskGroup cancels the sibling and waits for it before anything
             leaves this function. The first failure is re-raised bare, not as an
             ExceptionGroup, so search_error_boundary maps it to the same status
             as before.
    """
    try:
        async with asyncio.TaskGroup() as task_group:
            results_task = task_group.create_task(
                search_service.search(query, limit=limit, offset=offset)
            )
            total_task = task_group.create_task(search_service.count(query))
    except ExceptionGroup as group:
        raise group.exceptions[0]
    return results_task.result(), total_task.result()


# QUERY only: a search is a safe, cacheable read with a body (RFC 9110 draft).
# OpenAPI cannot describe QUERY, so the route stays out of the schema.
@router.api_route(
    "/search/",
    methods=["QUERY"],
    response_model=SearchResponse,
    include_in_schema=False,
    dependencies=[
        cached_read(
            ReadCacheOperation.search,
            group=content_group,
            ttl_seconds=SEARCH_READ_CACHE_TTL_SECONDS,
            hit_headers={"Accept-Query": "application/json"},
        )
    ],
)
async def search(
    query: SearchQuery,
    search_service: SearchServiceV2ExternalDep,
    entity_service: EntityServiceV2ExternalDep,
    temporal_repository: MemoryTimeIndexRepositoryV2ExternalDep,
    session_maker: SessionMakerDep,
    response: Response,
    internal_project_id: ProjectExternalIdPathDep,
    project_id: str = Path(..., description="Project external UUID"),
    page: int = 1,
    page_size: int = 10,
) -> SearchResponse:
    """Search across all knowledge and documents in a project.

    V2 uses external_id UUIDs for stable API references.

    Args:
        project_id: Project external UUID from URL path
        query: Search query parameters (text, filters, etc.)
        search_service: Search service scoped to project
        entity_service: Entity service scoped to project
        temporal_repository: Valid-time projection, read to explain temporal matches
        session_maker: Session factory for the temporal hydration read
        page: Page number for pagination
        page_size: Number of results per page

    Returns:
        SearchResponse with paginated search results
    """
    response.headers["Accept-Query"] = "application/json"
    # Read from the request rather than from the parsed filter: this is a plain field
    # check that cannot raise, and reaching the hydration step below already proves
    # the service accepted and executed the filter.
    temporal_requested = query.has_temporal_filter()
    with logfire.span(
        "api.request.search",
        entrypoint="api",
        domain="search",
        action="search",
        page=page,
        page_size=page_size,
        retrieval_mode=query.retrieval_mode.value,
        has_query=bool(
            (query.text and query.text.strip())
            or query.title
            or query.permalink
            or query.permalink_match
        ),
        has_filters=bool(
            query.note_types
            or query.entity_types
            or query.categories
            or query.metadata_filters
            or query.file_path_prefix
            or temporal_requested
        ),
        has_temporal_filter=temporal_requested,
    ):
        offset = (page - 1) * page_size
        # A malformed filter is the caller's mistake, known before any query
        # runs. Refusing it here answers 400 without scheduling the search
        # and count queries that would each fail on the same parse.
        if query.metadata_filters:
            with search_error_boundary():
                parse_metadata_filters(query.metadata_filters)
        exact_count_available = query.retrieval_mode == SearchRetrievalMode.FTS
        with search_error_boundary():
            with logfire.span(
                "api.search.search.execute_query",
                domain="search",
                action="search",
                phase="execute_query",
                page=page,
                page_size=page_size,
            ):
                if exact_count_available:
                    results, total = await _search_with_exact_count(
                        search_service, query, limit=page_size, offset=offset
                    )
                else:
                    results = await search_service.search(query, limit=page_size + 1, offset=offset)
                    total = 0

        with logfire.span(
            "api.search.search.paginate_results",
            domain="search",
            action="search",
            phase="paginate_results",
            result_count=len(results),
        ):
            if exact_count_available:
                has_more = offset + len(results) < total
            else:
                # Trigger: semantic modes would need another vector/hybrid retrieval to count.
                # Why: search requests should not pay for a second semantic pass.
                # Outcome: preserve probe pagination and report a lower bound, marked
                #   inexact: a row returned at this offset proves the ranking holds at
                #   least offset + len(results) rows. An empty page proves nothing about
                #   the offset it skipped, so it reports 0.
                has_more = len(results) > page_size
                if has_more:
                    results = results[:page_size]
                total = offset + len(results) if results else 0

        with logfire.span(
            "api.search.search.hydrate_results",
            domain="search",
            action="search",
            phase="hydrate_results",
            result_count=len(results),
        ):
            # Trigger: the caller asked a valid-time question.
            # Why: the assertions explain *why* each hit matched, but loading them
            #   costs a query, and a search with no temporal filter has nothing to
            #   explain -- so ordinary searches stay exactly as expensive as before.
            # Outcome: temporal metadata rides along only on temporal searches.
            temporal_by_source = {}
            if temporal_requested:
                async with db.scoped_session(session_maker) as session:
                    temporal_by_source = await load_temporal_metadata(
                        temporal_repository, session, results
                    )
            search_results = await to_search_results(
                entity_service,
                results,
                temporal_by_source=temporal_by_source,
                project_external_ids={internal_project_id: project_id},
            )
        with logfire.span(
            "api.search.search.build_response",
            domain="search",
            action="search",
            phase="build_response",
            result_count=len(search_results),
        ):
            result = SearchResponse(
                results=search_results,
                current_page=page,
                page_size=page_size,
                total=total,
                total_is_exact=exact_count_available,
                has_more=has_more,
                # A later empty page is pagination, not evidence of a compound miss.
                # Guidance adds no retrieval pass and makes no index-completeness claim.
                query_hint=unspaced_script_query_hint(query)
                if page == 1 and not search_results and total == 0
                else None,
                # None, not False, when nothing was asked: an ordinary search
                # payload stays exactly what it was before valid time existed.
                temporal_applied=True if temporal_requested else None,
            )
            return result


@router.post("/search/reindex")
async def reindex(
    search_reindex_scheduler: SearchReindexSchedulerDep,
    project_id: ProjectExternalIdPathDep,
):
    """Recreate and populate the search index for a project.

    This is a background operation that rebuilds the search index
    from scratch. Useful after bulk updates or if the index becomes
    corrupted.

    Args:
        project_id: Project external UUID from URL path
        search_reindex_scheduler: Search reindex scheduler for background work

    Returns:
        Status message indicating reindex has been initiated
    """
    search_reindex_scheduler.schedule_search_reindex(project_id=project_id)
    return {"status": "ok", "message": "Reindex initiated"}
